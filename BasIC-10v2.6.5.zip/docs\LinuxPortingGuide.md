# Basic-10 Linux Porting Guide

This document outlines the requirements, challenges, and recommended approach for porting Basic-10 to Linux.

## Current Architecture

Basic-10 is built with a clean separation between the compiler core and the UI:

```
BasicToMips/
├── src/                    # Compiler Core (platform-independent)
│   ├── Lexer/             # Tokenization
│   ├── Parser/            # Syntax analysis
│   ├── AST/               # Abstract syntax tree
│   ├── CodeGen/           # MIPS code generation
│   ├── Analysis/          # Static analysis
│   ├── IC10/              # IC10 parser/decompiler
│   ├── Preprocessing/     # Preprocessor
│   ├── Refactoring/       # Code refactoring
│   └── Shared/            # Shared utilities
├── Simulator/             # IC10 Simulator (platform-independent)
├── Data/                  # Device database (JSON, platform-independent)
├── Services/              # HTTP API server (mostly platform-independent)
├── UI/                    # WPF User Interface (Windows-only)
└── Editor/                # Editor components (WPF-dependent)
```

## Platform Analysis

### ✅ Platform-Independent Components (Ready for Linux)

| Component | Location | Files | Notes |
|-----------|----------|-------|-------|
| Lexer | `src/Lexer/` | 3 | Token, TokenType, Lexer |
| Parser | `src/Parser/` | 1 | Full BASIC parser |
| AST | `src/AST/` | 1 | All AST node types |
| Code Generator | `src/CodeGen/` | 3 | MipsGenerator, RegisterAllocator, CodeEmitter |
| Static Analyzer | `src/Analysis/` | 2 | StaticAnalyzer, CodeFormatter |
| IC10 Tools | `src/IC10/` | 2 | IC10Parser, IC10Decompiler |
| Preprocessor | `src/Preprocessing/` | 1 | Macro/include handling |
| Language Detector | `src/Shared/` | 2 | Auto-detect BASIC vs IC10 |
| IC10 Simulator | `Simulator/` | 1 | Full instruction simulation |
| Device Database | `Data/` | JSON | 1500+ device definitions |
| HTTP API | `Services/` | 1* | MCP integration server |

*EditorBridgeService.cs uses `System.Windows.Threading.Dispatcher` for UI marshaling - needs abstraction.

**Total: ~17 C# files that work on Linux without modification**

### ❌ Windows-Only Components (Require Replacement)

| Component | Location | Files | Windows Dependency |
|-----------|----------|-------|-------------------|
| Main Window | `UI/` | 26 .cs | WPF (System.Windows) |
| XAML Views | `UI/` | 19 .xaml | WPF XAML |
| Code Editor | `Editor/` | ~5 | AvalonEdit (WPF) |
| Clipboard | `UI/ClipboardHelper.cs` | 1 | System.Windows.Clipboard |
| File Dialogs | Various | - | Microsoft.Win32.OpenFileDialog |
| WebView2 | Wiki browser | 1 | Microsoft.Web.WebView2 |

## Dependencies

### Current Windows Dependencies

```xml
<TargetFramework>net8.0-windows</TargetFramework>
<UseWPF>true</UseWPF>
<UseWindowsForms>true</UseWindowsForms>
<RuntimeIdentifier>win-x64</RuntimeIdentifier>

<PackageReference Include="AvalonEdit" Version="6.3.0.90" />
<PackageReference Include="Microsoft.Web.WebView2" Version="1.0.2903.40" />
```

### Linux-Compatible Alternatives

| Windows | Linux Alternative | Compatibility |
|---------|-------------------|---------------|
| WPF | **Avalonia UI** | XAML syntax ~90% compatible |
| AvalonEdit | **AvaloniaEdit** | Same API, direct port |
| WebView2 | CefGlue / WebView | Different API |
| System.Windows.Clipboard | TextCopy NuGet | Cross-platform |
| Microsoft.Win32.OpenFileDialog | Avalonia.Dialogs | Cross-platform |

## Recommended Porting Strategy

### Option 1: Avalonia UI (Recommended)

**Pros:**
- XAML syntax nearly identical to WPF
- AvaloniaEdit exists with same API as AvalonEdit
- Single codebase for Windows, Linux, macOS
- Active community and good documentation
- .NET 8 support

**Cons:**
- Still requires UI rewrite (though much is adaptable)
- Some WPF features not available
- Learning curve for differences

**Estimated Effort:** 2-4 weeks for experienced developer

### Option 2: CLI-Only Version

**Pros:**
- Trivial to implement (compiler core is ready)
- Works everywhere .NET runs
- Could be done in 1-2 days

**Cons:**
- No GUI features (editor, simulator visualization, etc.)
- Less user-friendly

**Estimated Effort:** 1-2 days

### Option 3: Web-Based (Blazor/Electron)

**Pros:**
- Runs everywhere with a browser
- Could use Monaco Editor (VS Code's editor)

**Cons:**
- Complete rewrite of UI
- Different development paradigm
- Electron apps are heavy

**Estimated Effort:** 4-8 weeks

## Implementation Plan for Avalonia Port

### Phase 1: Project Setup
1. Create new Avalonia project targeting `net8.0`
2. Add shared project reference for compiler core
3. Configure for Linux + Windows builds

### Phase 2: Core UI Migration
1. Port MainWindow.xaml → Avalonia XAML
2. Replace AvalonEdit → AvaloniaEdit
3. Implement cross-platform clipboard (TextCopy)
4. Implement cross-platform file dialogs

### Phase 3: Feature Parity
1. Port all dialog windows
2. Port simulator visualization
3. Port device database browser
4. Implement settings persistence (use cross-platform paths)

### Phase 4: Platform-Specific Polish
1. Linux file path handling
2. Linux font fallbacks
3. Testing on major distros (Ubuntu, Fedora, Arch)

## File Path Considerations

```csharp
// Windows
%LOCALAPPDATA%\BasicToMips\settings.json
C:\Users\Name\Documents\Basic-10\

// Linux
~/.config/BasicToMips/settings.json
~/Documents/Basic-10/

// Cross-platform solution
Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)
```

## Building with WSL

### Prerequisites
```bash
# Install .NET 8 SDK
wget https://dot.net/v1/dotnet-install.sh
chmod +x dotnet-install.sh
./dotnet-install.sh --channel 8.0

# Add to PATH
export DOTNET_ROOT=$HOME/.dotnet
export PATH=$PATH:$DOTNET_ROOT
```

### Building Compiler Core Only
```bash
# Create a minimal .csproj for just the compiler
cd /mnt/c/Development/Stationeers\ Stuff/BASICtoMIPS_ByDogTired

# The src/ folder can be built as a class library on Linux
dotnet new classlib -n BasicToMips.Core -f net8.0
# Copy src/ files and build
```

### Testing Compiler Core
```bash
# Once isolated, the compiler core should build cleanly
dotnet build BasicToMips.Core.csproj
dotnet test  # if tests are added
```

## Quick Win: CLI Compiler

A command-line compiler could be created immediately:

```csharp
// Program.cs for CLI version
using BasicToMips;

if (args.Length < 1) {
    Console.WriteLine("Usage: basic10 <input.bas> [-o output.ic10]");
    return 1;
}

var source = File.ReadAllText(args[0]);
var lexer = new Lexer(source);
var parser = new Parser(lexer.Tokenize());
var ast = parser.Parse();
var generator = new MipsGenerator();
var ic10 = generator.Generate(ast);

var output = args.Length > 2 ? args[2] : Path.ChangeExtension(args[0], ".ic10");
File.WriteAllText(output, ic10);
Console.WriteLine($"Compiled to {output}");
return 0;
```

## Conclusion

The Basic-10 compiler has excellent architecture for cross-platform support:

- **Compiler core is 100% platform-independent** - zero Windows dependencies
- **UI is cleanly separated** - can be replaced without touching compiler
- **Avalonia UI is the best path forward** - minimal rewrite, maximum compatibility

The recommended approach is:
1. **Short term:** Create CLI version for Linux users (1-2 days)
2. **Long term:** Port UI to Avalonia for full cross-platform support (2-4 weeks)

---

*Document created: December 2025*
*Basic-10 Version: 2.6.0*
