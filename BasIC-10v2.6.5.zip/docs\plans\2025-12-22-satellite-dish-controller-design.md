# Satellite Dish Controller System Design

**Date:** 2025-12-22
**Status:** Design Complete
**Purpose:** Complete replacement for communications computer trader interface

---

## Overview

A modular IC10-based system to fully replace the communications computer for satellite dish operations. Provides manual positioning, auto-tracking, contact management, and trader communication.

---

## System Modes

| Mode | Value | Behavior |
|------|-------|----------|
| Manual | 1 | Keypad/fine-tune controls position |
| Hold | 2 | Dish stays at current position |
| Auto | 3 | Dish tracks selected contact |

**Mode Selection:** Three square buttons (Manual/Hold/Auto) with corresponding label diode indicators. Button color changes to indicate active mode.

**Fine-tune:** Only active in Manual mode.

---

## Auto-Tracking Algorithm

Uses **ContactDegreeOffset + Gradient Ascent**:

1. Read `ContactDegreeOffset` to know how close we are
2. Adjust H or V in current direction
3. Wait for dish to reach commanded position (compare actual vs commanded, use `Idle` as failback)
4. Check if offset improved
5. If worse, reverse direction
6. Alternate H/V adjustments until offset < threshold
7. Enter LOCKED state when aligned

**States:**
- IDLE: Mode != 3 or no contacts
- WAITING: Dish moving to commanded position
- TRACK_H: Adjusting Horizontal
- TRACK_V: Adjusting Vertical
- LOCKED: ContactDegreeOffset < threshold

**Signal Lost:** Hold position until signal returns.

---

## Contact Slot Management

Contacts persist in display slots until their timer expires (no shifting when other contacts leave).

**Memory Layout (Contact Slots chip):**
- Address 0-7: ContactReferenceId for slots 1-8
- When new contact appears, assign to first empty slot
- Clear slot when ContactLifetime = 0

---

## Complete Device List

### Dish
| Type | Name |
|------|------|
| StructureLargeSatelliteDish | "Large Dish 1" |

### Mode Control
| Type | Name |
|------|------|
| ModularDeviceSquareButton | "Manual" |
| ModularDeviceSquareButton | "Hold" |
| ModularDeviceSquareButton | "Auto" |
| ModularDeviceLabelDiode2 | "MANUAL" |
| ModularDeviceLabelDiode2 | "HOLD" |
| ModularDeviceLabelDiode2 | "AUTO" |

### Power
| Type | Name |
|------|------|
| ModularDeviceFlipCoverSwitch | "Power" |
| ModularDeviceLabelDiode2 | "POWER" |

### Keypad Input
| Type | Name |
|------|------|
| ModularDeviceRoundButton | "Num 0" |
| ModularDeviceRoundButton | "Num 1" |
| ModularDeviceRoundButton | "Num 2" |
| ModularDeviceRoundButton | "Num 3" |
| ModularDeviceRoundButton | "Num 4" |
| ModularDeviceRoundButton | "Num 5" |
| ModularDeviceRoundButton | "Num 6" |
| ModularDeviceRoundButton | "Num 7" |
| ModularDeviceRoundButton | "Num 8" |
| ModularDeviceRoundButton | "Num 9" |
| ModularDeviceSquareButton | "Select H" |
| ModularDeviceSquareButton | "Select V" |
| ModularDeviceSquareButton | "Enter" |
| ModularDeviceSquareButton | "Clear" |
| ModularDeviceRoundButton | "H+" |
| ModularDeviceRoundButton | "H-" |
| ModularDeviceRoundButton | "V+" |
| ModularDeviceRoundButton | "V-" |
| ModularDeviceDial | "Step Size" |
| ModularDeviceLEDdisplay3 | "Input H" |
| ModularDeviceLEDdisplay3 | "Input V" |
| ModularDeviceLEDdisplay3 | "Actual H" |
| ModularDeviceLEDdisplay3 | "Actual V" |
| ModularDeviceLEDdisplay2 | "Step" |
| ModularDeviceLabelDiode2 | "H ACTIVE" |
| ModularDeviceLabelDiode2 | "V ACTIVE" |

### Contact List (8 Contacts)
| Type | Name |
|------|------|
| ModularDeviceLEDdisplay3 | "Contact 1 Hash" |
| ModularDeviceLEDdisplay3 | "Contact 2 Hash" |
| ModularDeviceLEDdisplay3 | "Contact 3 Hash" |
| ModularDeviceLEDdisplay3 | "Contact 4 Hash" |
| ModularDeviceLEDdisplay3 | "Contact 5 Hash" |
| ModularDeviceLEDdisplay3 | "Contact 6 Hash" |
| ModularDeviceLEDdisplay3 | "Contact 7 Hash" |
| ModularDeviceLEDdisplay3 | "Contact 8 Hash" |
| ModularDeviceLEDdisplay2 | "Contact 1 Signal" |
| ModularDeviceLEDdisplay2 | "Contact 2 Signal" |
| ModularDeviceLEDdisplay2 | "Contact 3 Signal" |
| ModularDeviceLEDdisplay2 | "Contact 4 Signal" |
| ModularDeviceLEDdisplay2 | "Contact 5 Signal" |
| ModularDeviceLEDdisplay2 | "Contact 6 Signal" |
| ModularDeviceLEDdisplay2 | "Contact 7 Signal" |
| ModularDeviceLEDdisplay2 | "Contact 8 Signal" |
| ModularDeviceLEDdisplay2 | "Contact 1 Time" |
| ModularDeviceLEDdisplay2 | "Contact 2 Time" |
| ModularDeviceLEDdisplay2 | "Contact 3 Time" |
| ModularDeviceLEDdisplay2 | "Contact 4 Time" |
| ModularDeviceLEDdisplay2 | "Contact 5 Time" |
| ModularDeviceLEDdisplay2 | "Contact 6 Time" |
| ModularDeviceLEDdisplay2 | "Contact 7 Time" |
| ModularDeviceLEDdisplay2 | "Contact 8 Time" |
| ModularDeviceDial | "Contact Select" |
| ModularDeviceRoundButton | "Call Trader" |

### Trader Filters
| Type | Name | Hash |
|------|------|------|
| ModularDeviceRoundButton | "Any" | 0 (no filter) |
| ModularDeviceRoundButton | "Rare" | 649254485 |
| ModularDeviceRoundButton | "Genetics" | -188927486 |
| ModularDeviceRoundButton | "Ore" | -1374574351 |
| ModularDeviceRoundButton | "Alloy" | 54412100 |
| ModularDeviceRoundButton | "Food" | -82964957 |
| ModularDeviceRoundButton | "Hydro" | -1077922067 |
| ModularDeviceRoundButton | "Gas" | -470575659 |
| ModularDeviceRoundButton | "Construct" | 175935584 |
| ModularDeviceRoundButton | "Liquid" | 135244511 |
| ModularDeviceRoundButton | "Hardware" | 1325142661 |
| ModularDeviceRoundButton | "Consumable" | -1650376125 |
| ModularDeviceRoundButton | "Appliance" | -1590718013 |

### Presets
| Type | Name |
|------|------|
| ModularDeviceRoundButton | "Save 1" |
| ModularDeviceRoundButton | "Save 2" |
| ModularDeviceRoundButton | "Save 3" |
| ModularDeviceRoundButton | "Save 4" |
| ModularDeviceRoundButton | "Save 5" |
| ModularDeviceRoundButton | "Save 6" |
| ModularDeviceRoundButton | "Recall 1" |
| ModularDeviceRoundButton | "Recall 2" |
| ModularDeviceRoundButton | "Recall 3" |
| ModularDeviceRoundButton | "Recall 4" |
| ModularDeviceRoundButton | "Recall 5" |
| ModularDeviceRoundButton | "Recall 6" |
| ModularDeviceLEDdisplay2 | "Preset" |

### Status Displays
| Type | Name |
|------|------|
| ModularDeviceLEDdisplay2 | "Signal" |
| ModularDeviceLEDdisplay2 | "Interrogation" |
| ModularDeviceLEDdisplay2 | "Power Required" |
| ModularDeviceLEDdisplay2 | "ContactCount" |
| ModularDeviceLEDdisplay3 | "MinWatts" |
| ModularDeviceLEDdisplay3 | "WattsReaching" |
| ModularDeviceLEDdisplay3 | "ContactType" |
| ModularDeviceLEDdisplay2 | "SizeX" |
| ModularDeviceLEDdisplay2 | "SizeZ" |

### Status Indicators
| Type | Name |
|------|------|
| ModularDeviceLabelDiode2 | "ERROR" |
| ModularDeviceLabelDiode2 | "LOCKED" |
| ModularDeviceLabelDiode2 | "SIGNAL" |
| ModularDeviceLabelDiode2 | "TRACKING" |

### Sliders
| Type | Name |
|------|------|
| ModularDeviceSliderDiode2 | "Signal Bar" |
| ModularDeviceSliderDiode2 | "Interrogation Bar" |

### Memory
| Type | Name | Purpose |
|------|------|---------|
| StructureLogicMemory | "Presets" | 6 H/V pairs (addresses 0-11) |
| StructureLogicMemory | "Contact Slots" | 8 ReferenceIds (addresses 0-7) |

---

## IC Module Breakdown

| IC Name | Function | Lines (est) |
|---------|----------|-------------|
| Mode Control | Mode buttons, indicators, button colors | ~30 |
| Position Control | Manual positioning, mode logic, fine-tune | ~40 |
| Auto Track | Gradient ascent tracking, state machine | ~80 |
| Keypad Input | Numeric entry, H/V selection, Enter/Clear | ~60 |
| Contact Slot Manager | Assign/clear contact slots, persistence | ~50 |
| Contact Hash Display | Hash for contacts 1-8 | ~40 |
| Contact Signal Display | Signal for contacts 1-8 | ~40 |
| Contact Time Display | Lifetime for contacts 1-8 | ~40 |
| Filter Control | 13 filter buttons, set FilterValue | ~45 |
| Status Display | All status displays, sliders, indicators | ~60 |
| Preset Save | Save buttons, write to memory | ~35 |
| Preset Recall | Recall buttons, read from memory | ~65 |

**Total: 12 ICs**

---

## Memory Layouts

### Presets Memory (d0 on Preset Save/Recall ICs)
| Address | Content |
|---------|---------|
| 0 | Preset 1 Horizontal |
| 1 | Preset 1 Vertical |
| 2 | Preset 2 Horizontal |
| 3 | Preset 2 Vertical |
| 4 | Preset 3 Horizontal |
| 5 | Preset 3 Vertical |
| 6 | Preset 4 Horizontal |
| 7 | Preset 4 Vertical |
| 8 | Preset 5 Horizontal |
| 9 | Preset 5 Vertical |
| 10 | Preset 6 Horizontal |
| 11 | Preset 6 Vertical |

### Contact Slots Memory (d0 on Slot Manager IC)
| Address | Content |
|---------|---------|
| 0 | Slot 1 ContactReferenceId |
| 1 | Slot 2 ContactReferenceId |
| 2 | Slot 3 ContactReferenceId |
| 3 | Slot 4 ContactReferenceId |
| 4 | Slot 5 ContactReferenceId |
| 5 | Slot 6 ContactReferenceId |
| 6 | Slot 7 ContactReferenceId |
| 7 | Slot 8 ContactReferenceId |

---

## Device Totals

| Category | Count |
|----------|-------|
| Buttons (Round) | 35 |
| Buttons (Square) | 8 |
| Dials | 2 |
| Displays (Small) | 17 |
| Displays (Large) | 14 |
| Indicators | 10 |
| Sliders | 2 |
| Switches | 1 |
| Memory | 2 |
| Dish | 1 |
| **Total** | **92** |

---

## Logic Extended Properties Used

| Property | Value | Purpose |
|----------|-------|---------|
| ContactIndex | 1000 | Select contact |
| ContactCount | 1001 | Total contacts |
| ContactLifetime | 1011 | Time remaining |
| ContactDegreeOffset | 1012 | Tracking alignment |
| ContactResolved | 1013 | Locked status |
| ContactResolutionProgress | 1015 | Interrogation progress |
| ContactMinWattsContact | 1017 | Power needed |
| ContactTraderHash | 1019 | Trader type |
| ContactReferenceId | 1020 | Unique ID for slot tracking |
| DishWattageOnContact | 1030 | Power reaching contact |

---

## Vanilla Properties Used

| Property | Purpose |
|----------|---------|
| On | Dish power |
| Horizontal | Dish position |
| Vertical | Dish position |
| Idle | Movement complete check |
| SignalStrength | Signal level |
| Error | Error state |
| Activate | Interrogate/Call trader |
| SizeX | Landing pad requirement |
| SizeZ | Landing pad requirement |

---

## Implementation Order

1. Mode Control IC
2. Position Control IC (Manual mode only first)
3. Keypad Input IC
4. Status Display IC
5. Contact Slot Manager IC
6. Contact Display ICs (Hash, Signal, Time)
7. Filter Control IC
8. Auto Track IC
9. Preset Save/Recall ICs
10. Integration testing
