# Greenhouse Atmosphere Controller Design

**Date:** 2025-12-25
**Status:** In Progress - Design Phase
**Theme:** NASA Mission Control style with abundant displays/monitors

---

## Overview

A modular greenhouse atmosphere controller that monitors pressure and gas composition, adjusting via turbo volume pumps and digital valves. Designed for expandability as new gas lines are added.

---

## System Architecture

### IC Modules

| IC Name | Purpose |
|---------|---------|
| Master Controller | Mode control, presets, safety logic, overall displays |
| O2 Controller | Oxygen monitoring, valve control, O2 display cluster |
| N2 Controller | Nitrogen monitoring, valve control, N2 display cluster |
| CO2 Controller | Carbon Dioxide monitoring, valve control, CO2 display cluster |
| (Future gas ICs) | Same pattern for H2O, Pollutant, N2O, etc. |
| Preset Library | Stores plant atmosphere data, handles preset selection UI |
| Safety Monitor | Dedicated safety checks, emergency responses, alarms |
| Lighting Controller | Grow light cycle timing, window shutter control, blackout mode |
| Preset Display | Displays active preset name (3-5 letter abbreviation) |

### Shared Memory Layout

- **Memory 1 "Gas Targets":** Address 0=O2%, 1=N2%, 2=CO2%, 3=H2O%, etc.
- **Memory 2 "System State":** Address 0=Mode, 1=Active Preset, 2=Pressure Target, 3=Alarm State
- **Memory 3 "Preset Data":** Stores preset values (or hardcoded per plant)

### Communication Flow

- Master writes mode/targets → Gas ICs read and act
- Gas ICs write status → Safety Monitor reads
- Preset IC writes targets → Gas ICs respond

---

## Target Configuration

- **Approach:** Percentage + Total Pressure
- Set total pressure target (e.g., 101kPa)
- Set percentage for each gas
- Controller calculates partial pressures

---

## Sensors

- Multi-zone gas sensors throughout greenhouse
- All named the same (e.g., "Greenhouse Sensor")
- Enables batch read with automatic averaging across zones

---

## Gas Control Hardware

### Per Gas Line
- **Digital Valve:** ON/OFF control only (gate)
- **Turbo Volume Pump:** Variable rate control (0-100%, where 100% = 100L/tick)
- **Exhaust:** Shared exhaust pump to filtration system

### Control Sequence

**Injection Stop Sequence:**
1. Close digital valve (stops new gas entering pipe)
2. Pump continues at current rate (clears pipe to room)
3. Short delay (pipe clearing time, ~2-5 ticks based on pipe length)
4. Stop pump
5. Enter equalization period

**Injection Start Sequence:**
1. Open digital valve (gas fills pipe)
2. Short delay (pipe filling time)
3. Start pump at calculated rate
4. Begin monitoring

### Conservative Pump Rate Strategy

| Distance from Target | Pump Setting | Action |
|---------------------|--------------|--------|
| >15% off | Medium (30-50%) | Active correction |
| 10-15% off | Low-Medium (20-30%) | Moderate injection |
| 5-10% off | Low (10-20%) | Gentle injection |
| 2-5% off | Minimal (5-10%) | Trickle injection |
| <2% off | Stop (0%) | Close valve, equalize |

### Equalization Behavior

- After any injection, mandatory wait period before re-measuring
- Configurable wait (e.g., "Equalize Time" dial, 10-60 ticks)
- During wait: valve closed, pump off, status shows "EQUALIZING"
- Prevents overshoot → undershoot oscillation
- Gases enter at one end of room, need time to mix

### Overshoot Protection

- If any gas exceeds target +5% after injection, immediately stop that gas
- Flag warning, wait for natural consumption or exhaust

---

## Per-Gas Display Cluster

Each gas (O2, N2, CO2, etc.) gets identical panel layout. Replace "O2" with gas name.

### Displays (ModularDeviceLEDdisplay3)

| Name | Purpose |
|------|---------|
| "O2 CURRENT" | Current gas percentage |
| "O2 TARGET" | Target gas percentage |
| "O2 PARTIAL" | Partial pressure in kPa |
| "O2 FLOW" | Current flow rate |

### Slider Bars (ModularDeviceSliderDiode2 - larger version)

| Name | Purpose |
|------|---------|
| "O2 TARGET BAR" | Visual target ratio (0-1 mapped) |
| "O2 ACTUAL BAR" | Visual current ratio (0-1 mapped) |

### Status LEDs (ModularDeviceLabelDiode2)

| Name | Color | Purpose |
|------|-------|---------|
| "O2 OK" | Green | Within tolerance |
| "O2 LOW" | Yellow | Below target |
| "O2 HIGH" | Yellow | Above target |
| "O2 VALVE" | Blue | Valve open indicator |
| "O2 TREND UP" | White | Ratio rising |
| "O2 TREND DOWN" | White | Ratio falling |
| "O2 STABLE" | Green | Ratio stable |

### Controls

| Name | Type | Purpose |
|------|------|---------|
| "O2 Tune" | Dial | Fine-tune adjustment (±5% from preset) |
| "O2 Override" | FlipCoverSwitch | Manual override enable |

---

## Master Controller Panel

### Pressure & Environment Displays

| Name | Type | Purpose |
|------|------|---------|
| "TOTAL PRESSURE" | LEDdisplay3 | Current total kPa |
| "TARGET PRESSURE" | LEDdisplay3 | Target total kPa |
| "TEMPERATURE" | LEDdisplay3 | Current temp |
| "PRESSURE BAR" | SliderDiode2 | Visual pressure level |

### System Status Displays

| Name | Type | Purpose |
|------|------|---------|
| "ACTIVE PRESET" | LEDdisplay3 | Current preset number |
| "SENSOR COUNT" | LEDdisplay2 | Active sensors responding |
| "HEALTH RATING" | LEDdisplay2 | Atmosphere health 0-100 |
| "CYCLE COUNT" | LEDdisplay3 | Total adjustments made |
| "PRESET TIME" | LEDdisplay3 | Time in current preset |

### Status LEDs (LabelDiode2)

| Name | Color | Mode | Purpose |
|------|-------|------|---------|
| "POWER" | Green | 0 | System powered |
| "AUTO" | Green | 0 | Auto mode active |
| "MANUAL" | Yellow | 0 | Manual mode active |
| "HOLD" | Blue | 0 | Hold mode active |
| "CONFIRM PENDING" | Yellow | 1 | Awaiting preset confirm |
| "EXHAUST ACTIVE" | Red | 1 | Exhaust pump running |
| "VALVE ACTIVITY" | Blue | 1 | Any valve open |
| "MASTER WARNING" | Red | 1 | Any gas out of tolerance |
| "OVERPRESSURE" | Red | 1 | Pressure too high |
| "UNDERPRESSURE" | Red | 1 | Pressure too low |
| "O2 CRITICAL" | Red | 1 | Oxygen dangerously low |
| "ERROR" | Red | 1 | System fault |

### Trend LEDs

| Name | Color | Purpose |
|------|-------|---------|
| "PRESSURE UP" | White | Pressure rising |
| "PRESSURE DOWN" | White | Pressure falling |
| "PRESSURE STABLE" | Green | Pressure stable |
| "TEMP UP" | White | Temp rising |
| "TEMP DOWN" | White | Temp falling |
| "TEMP STABLE" | Green | Temp stable |

### Controls

| Name | Type | Purpose |
|------|------|---------|
| "Power" | FlipCoverSwitch | Master power |
| "Emergency Vent" | FlipCoverSwitch | Emergency exhaust |
| "Auto" | SquareButton | Set auto mode |
| "Manual" | SquareButton | Set manual mode |
| "Hold" | SquareButton | Set hold mode |
| "Pressure +" | RoundButton | Manual pressure increase |
| "Pressure -" | RoundButton | Manual pressure decrease |
| "Exhaust Enable" | FlipCoverSwitch | Enable exhaust system |
| "System Reset" | SquareButton | Reset faults |
| "Silence Alarm" | RoundButton | Mute audible alarm |
| "Confirm Preset" | SquareButton | Confirm pending preset |

---

## Preset System

### Structure

- Button per plant type (RoundButton) with confirmation before applying
- LED indicator per plant showing "selected/pending" state
- "Confirm Preset" button on master panel applies the change

### Preset Data Per Plant

- Target Pressure (kPa)
- O2 %
- N2 %
- CO2 %
- H2O % (future)
- Pollutant % (future)
- Temp Min (K or C)
- Temp Max (K or C)

### Storage

- Hardcoded presets for all game plants (values don't change)
- 2-3 "Custom" slots stored in memory for user-defined mixes

---

## Plant Atmosphere Data (Extracted from Wiki)

### Standard Plants (Most Common Requirements)

| Plant | Temp Range | Optimal Temp | Pressure | Optimal Press | CO2 Req | Gas Exchange |
|-------|-----------|--------------|----------|---------------|---------|--------------|
| Wheat | 0-50°C | 20-30°C | 50-99 kPa | 50-99 kPa | 0.1 mol | Consumes CO2, produces O2 @ 0.072 mol/min |
| Corn | 0-50°C | 20-30°C | 25-200 kPa | 50-100 kPa | 0.1 mol | Consumes CO2, produces O2 @ 0.072 mol/min |
| Tomato | 0-50°C | 20-30°C | 25-200 kPa | 50-100 kPa | 1% min | Consumes CO2, produces O2 @ 0.144 mol/min |
| Potato | 0-50°C | 20-30°C | 25-200 kPa | 50-100 kPa | 0.1 mol | Consumes CO2, produces O2 @ 0.072 mol/min |
| Soybean | 0-50°C | 20-30°C | 25-200 kPa | 50-100 kPa | 0.1 mol | Consumes CO2, produces O2 @ 0.072 mol/min |
| Rice | 0-50°C | 20-30°C | 25-200 kPa | 50-100 kPa | 0.1 mol | Consumes CO2, produces O2 @ 0.072 mol/min |
| Pumpkin | 0-50°C | 20-30°C | 25-200 kPa | 50-100 kPa | 0.1 mol | Consumes CO2, produces O2 @ 0.072 mol/min |
| Switch Grass | 0-50°C | 20-30°C | 25-200 kPa | 50-100 kPa | 0.1 mol | Consumes CO2, produces O2 @ 0.072 mol/min |

### High CO2 Plants (Require 7.7 kPa minimum CO2)

| Plant | Temp Range | Optimal Temp | Pressure | Optimal Press | CO2 Req | Gas Exchange |
|-------|-----------|--------------|----------|---------------|---------|--------------|
| Tropical Lily | 0-50°C | 20-30°C | 25-200 kPa | 50-100 kPa | 7.7 kPa | Consumes CO2, produces O2 @ 0.24 mol/min (66% higher) |
| Peace Lily | 0-50°C | 20-30°C | 25-200 kPa | 50-100 kPa | 7.7 kPa | Consumes CO2, produces O2 @ 0.24 mol/min (66% higher) |
| Flower | 0-50°C | 20-30°C | 25-200 kPa | 50-100 kPa | 7.7 kPa | Consumes CO2, produces O2 |

### Special Temperature Plants

| Plant | Temp Range | Optimal Temp | Pressure | Optimal Press | CO2 Req | Gas Exchange |
|-------|-----------|--------------|----------|---------------|---------|--------------|
| Cocoa | 0-50°C | **30-40°C** | 25-200 kPa | 50-100 kPa | 0.1 mol | Consumes CO2, produces O2 @ 0.072 mol/min |

### Narrow Pressure Range Plants

| Plant | Temp Range | Optimal Temp | Pressure | Optimal Press | CO2 Req | Gas Exchange |
|-------|-----------|--------------|----------|---------------|---------|--------------|
| Fern | 0-50°C | 20-30°C | **51-97 kPa** | 51-97 kPa | 0.1 mol | Produces O2 @ 17.3 mol/hr (HIGHEST) |
| Darga Fern | 0-50°C | 20-30°C | 25-200 kPa | 50-100 kPa | 0.1 mol | Produces O2 @ 0.51 mol/min (very high) |

### Inverted Gas Exchange (SPECIAL HANDLING REQUIRED)

| Plant | Temp Range | Optimal Temp | Pressure | Optimal Press | Gas Exchange |
|-------|-----------|--------------|----------|---------------|--------------|
| **Mushroom** | 0-50°C | 20-30°C | 25-200 kPa | 50-100 kPa | **CONSUMES O2, PRODUCES CO2** @ 0.072 mol/min |
| **Alien Mushroom** | 0-50°C | 20-30°C | 25-200 kPa | 50-100 kPa | **CONSUMES N2O, PRODUCES N2 + O2** |

### Additional Requirements (All Plants)

- **Water Temperature:** 5-60°C to avoid damage
- **Water Consumption:** ~0.043 mol/hr
- **Pollutants:** Must stay under 1 kPa partial pressure
- **Light:** Grow lights or sunlight required (except Mushroom - NO grow lights/sunlight)
- **Temperature Damage:** Plants die after 5 minutes outside range

### Preset Categories

Based on the data above, plants can be grouped into these preset categories:

1. **Standard (20-30°C, 50-100 kPa, low CO2):** Wheat, Corn, Potato, Soybean, Rice, Pumpkin, Switch Grass
2. **High CO2 (20-30°C, 50-100 kPa, 7.7 kPa CO2):** Tropical Lily, Peace Lily, Flower
3. **Warm Climate (30-40°C, 50-100 kPa, low CO2):** Cocoa
4. **Narrow Pressure (20-30°C, 51-97 kPa, low CO2):** Fern
5. **Mushroom (20-30°C, 50-100 kPa, O2 consumer):** Mushroom (requires opposite gas management!)
6. **Custom 1-3:** User-defined presets stored in memory

**Note:** Mushrooms require INVERSE gas control - they consume O2 and produce CO2. The controller must handle this special case by adjusting O2 down and allowing CO2 to rise.

---

## Preset Panel Layout (Finalized)

### Plant Preset Buttons (RoundButton) - 16 Total

**Row 1 - Standard Crops:**
| Button | Plant | Preset # | LED Name |
|--------|-------|----------|----------|
| "Wheat" | Wheat | 1 | "WHEAT SEL" |
| "Corn" | Corn | 2 | "CORN SEL" |
| "Potato" | Potato | 3 | "POTATO SEL" |
| "Tomato" | Tomato | 4 | "TOMATO SEL" |

**Row 2 - Standard Crops (continued):**
| Button | Plant | Preset # | LED Name |
|--------|-------|----------|----------|
| "Soybean" | Soybean | 5 | "SOYBEAN SEL" |
| "Rice" | Rice | 6 | "RICE SEL" |
| "Pumpkin" | Pumpkin | 7 | "PUMPKIN SEL" |
| "Switchgrass" | Switch Grass | 8 | "SWITCHGRASS SEL" |

**Row 3 - High CO2 & Special:**
| Button | Plant | Preset # | LED Name |
|--------|-------|----------|----------|
| "Tropical Lily" | Tropical Lily | 9 | "TROPLILY SEL" |
| "Peace Lily" | Peace Lily | 10 | "PEACELILY SEL" |
| "Flower" | Flower | 11 | "FLOWER SEL" |
| "Cocoa" | Cocoa | 12 | "COCOA SEL" |

**Row 4 - Ferns & Fungi:**
| Button | Plant | Preset # | LED Name |
|--------|-------|----------|----------|
| "Fern" | Fern | 13 | "FERN SEL" |
| "Darga Fern" | Darga Fern | 14 | "DARGAFERN SEL" |
| "Mushroom" | Mushroom | 15 | "MUSHROOM SEL" |
| "Sugarcane" | Sugarcane | 16 | "SUGARCANE SEL" |

**Row 5 - Custom Presets:**
| Button | Purpose | Preset # | LED Name |
|--------|---------|----------|----------|
| "Custom 1" | User-defined | 17 | "CUSTOM1 SEL" |
| "Custom 2" | User-defined | 18 | "CUSTOM2 SEL" |
| "Custom 3" | User-defined | 19 | "CUSTOM3 SEL" |
| (Reserved) | Future expansion | 20 | - |

### Preset LED Indicators (LabelDiode2)

Each preset button has a paired LED that shows:
- **OFF:** Not selected
- **Mode 0 (Solid):** Currently active preset
- **Mode 1 (Blink):** Pending confirmation

### Preset Values Table (Hardcoded)

| # | Plant | Press (kPa) | O2 % | N2 % | CO2 % | Temp Min | Temp Max | Special |
|---|-------|-------------|------|------|-------|----------|----------|---------|
| 1 | Wheat | 75 | 21 | 77 | 2 | 20 | 30 | - |
| 2 | Corn | 75 | 21 | 77 | 2 | 20 | 30 | - |
| 3 | Potato | 75 | 21 | 77 | 2 | 20 | 30 | - |
| 4 | Tomato | 75 | 21 | 77 | 2 | 20 | 30 | - |
| 5 | Soybean | 75 | 21 | 77 | 2 | 20 | 30 | - |
| 6 | Rice | 75 | 21 | 77 | 2 | 20 | 30 | - |
| 7 | Pumpkin | 75 | 21 | 77 | 2 | 20 | 30 | - |
| 8 | Switch Grass | 75 | 21 | 77 | 2 | 20 | 30 | - |
| 9 | Tropical Lily | 85 | 15 | 75 | 10 | 20 | 30 | High CO2 |
| 10 | Peace Lily | 85 | 15 | 75 | 10 | 20 | 30 | High CO2 |
| 11 | Flower | 85 | 15 | 75 | 10 | 20 | 30 | High CO2 |
| 12 | Cocoa | 75 | 21 | 77 | 2 | 30 | 40 | Warm |
| 13 | Fern | 75 | 21 | 77 | 2 | 20 | 30 | Narrow P |
| 14 | Darga Fern | 75 | 21 | 77 | 2 | 20 | 30 | High O2 prod |
| 15 | Mushroom | 75 | 10 | 85 | 5 | 20 | 30 | INVERTED |
| 16 | Sugarcane | 75 | 21 | 77 | 2 | 20 | 30 | - |
| 17-19 | Custom | Memory | Memory | Memory | Memory | Memory | Memory | User |

**Note on Preset 15 (Mushroom):** This preset runs in INVERTED mode. The controller will:
- Target LOW O2 (10%) instead of high
- Allow CO2 to accumulate (5%) instead of removing
- O2 injection is disabled, CO2 exhaust is reduced

---

## Safety System (Tiered Response)

### Tier 1 - Minor (Auto-Correct)

| Condition | Response |
|-----------|----------|
| Gas 2-5% off target | Adjust valve, status LED yellow |
| Pressure ±5kPa | Adjust inflow/exhaust |
| Temp ±5° off range | Signal heating/cooling |

### Tier 2 - Major (Auto-Protect)

| Condition | Response |
|-----------|----------|
| Gas 5-15% off target | Aggressive valve action, warning LED |
| Pressure ±15kPa | Force exhaust or emergency inject |
| Overpressure >120kPa | Auto-vent to safe level |
| O2 < 16% | Emergency O2 injection |

### Tier 3 - Critical (Emergency)

| Condition | Response |
|-----------|----------|
| Pressure >150kPa | Emergency full vent, alarm |
| Pressure <50kPa | Seal all valves, alarm |
| O2 < 10% | Max O2 injection, alarm |
| Multiple failures | System shutdown, alarm |

### Alarm Behavior

- Visual: All warning LEDs flash (Mode 1)
- Audible: Speaker/alarm device activated (if connected)
- "Silence Alarm" mutes audio but keeps visual
- "System Reset" clears fault state after condition resolved

---

## Remaining Design Tasks

1. ~~Extract plant atmosphere data from game files~~ ✓ DONE
2. ~~Finalize preset button count and layout~~ ✓ DONE (16 plants + 3 custom = 19 presets)
3. Determine equalization timing constants (suggest 30-60 ticks default)
4. Design IC interconnect wiring diagram (can be done during implementation)
5. Estimate total device count (can be done during implementation)

---

## Implementation Order

1. ~~Master Controller IC~~ ✓ DONE (105 lines) - Saved as "Greenhouse Master Controller"
2. ~~O2 Controller IC~~ ✓ DONE (127 lines) - Saved as "Greenhouse O2 Controller"
3. ~~N2 Controller IC~~ ✓ DONE (125 lines) - Saved as "Greenhouse N2 Controller"
4. ~~CO2 Controller IC~~ ✓ DONE (127 lines) - Saved as "Greenhouse CO2 Controller"
5. ~~Preset Library IC~~ ✓ DONE (112 lines) - Saved as "Greenhouse Preset Library"
6. ~~Safety Monitor IC~~ ✓ DONE (96 lines) - Saved as "Greenhouse Safety Monitor"
7. Integration testing (ready for in-game testing)
8. Future gas ICs as lines are added (H2O, Pollutant, N2O)

---

## Implementation Summary

### Completed Scripts (Saved to Stationeers scripts folder)

| Script | IC10 Lines | Purpose |
|--------|------------|---------|
| Greenhouse Master Controller | 107 | Mode control, sensor averaging, pressure/temp displays, preset number display |
| Greenhouse O2 Controller | 123 | O2 valve/pump control, O2 display cluster, pump rate dial, auto/manual modes |
| Greenhouse N2 Controller | 123 | N2 valve/pump control, N2 display cluster, pump rate dial, auto/manual modes |
| Greenhouse CO2 Controller | 123 | CO2 valve/pump control, CO2 display cluster, pump rate dial, auto/manual modes |
| Greenhouse Preset Library | 121 | 19 plant preset buttons (inc. Darga Fern, Sugarcane), confirmation system, writes targets to memory |
| Greenhouse Safety Monitor | 96 | Tiered safety (minor/major/critical), emergency vent, alarms |
| Greenhouse Lighting Controller | 99 | Grow light cycle timing, window shutter control, auto/manual blackout |
| Greenhouse Preset Display | 67 | Displays active preset name (3-5 letter abbreviation) on LEDdisplay3 |

### Shared Memory Layout (as implemented)

**"System State" Memory:**
- Address 0: Current mode (1=AUTO, 2=MANUAL, 3=HOLD)
- Address 2: Target pressure (kPa)
- Address 3: Alarm state (0=OK, 1=Active)

**"Gas Targets" Memory:**
- Address 0: O2 target %
- Address 1: N2 target %
- Address 2: CO2 target %
- (Future: Address 3=H2O%, etc.)

---

## In-Game Setup Guide

### Required IC Housings (8 total)

| IC Housing Name | Script to Load |
|-----------------|----------------|
| "Master IC" | Greenhouse Master Controller |
| "O2 IC" | Greenhouse O2 Controller |
| "N2 IC" | Greenhouse N2 Controller |
| "CO2 IC" | Greenhouse CO2 Controller |
| "Preset IC" | Greenhouse Preset Library |
| "Safety IC" | Greenhouse Safety Monitor |
| "Lighting IC" | Greenhouse Lighting Controller |
| "Display IC" | Greenhouse Preset Display |

### Memory Devices (3 total) - PIN WIRING REQUIRED

**Important:** Memory devices must be wired directly to IC Housing pins (d0-d2), not just placed on the network. See Phase 2 of Setup Guide for pin wiring table.

| Device Type | Name | Purpose |
|-------------|------|---------|
| StructureLogicMemory | "System State" | Mode, active preset, alarm state |
| StructureLogicMemory | "Gas Targets" | O2/N2/CO2 target percentages |
| StructureLogicMemory | "Custom Presets" | User-defined preset values |

### Sensors

| Device Type | Name | Quantity |
|-------------|------|----------|
| StructureGasSensor | "Greenhouse Sensor" | Multiple (place throughout greenhouse) |

### Gas Control Hardware

| Device Type | Name | Purpose |
|-------------|------|---------|
| StructureDigitalValve | "O2 Valve" | O2 line gate |
| StructureTurboVolumePump | "O2 Pump" | O2 injection rate |
| StructureDigitalValve | "N2 Valve" | N2 line gate |
| StructureTurboVolumePump | "N2 Pump" | N2 injection rate |
| StructureDigitalValve | "CO2 Valve" | CO2 line gate |
| StructureTurboVolumePump | "CO2 Pump" | CO2 injection rate |
| StructureDigitalValve | "Exhaust Valve" | Exhaust line gate |
| StructureTurboVolumePump | "Exhaust Pump" | Exhaust/vent rate |

### Master Panel Controls

| Device Type | Name | Purpose |
|-------------|------|---------|
| ModularDeviceFlipCoverSwitch | "Power" | Master power |
| ModularDeviceSquareButton | "Auto" | Set AUTO mode |
| ModularDeviceSquareButton | "Manual" | Set MANUAL mode |
| ModularDeviceSquareButton | "Hold" | Set HOLD mode |
| ModularDeviceFlipCoverSwitch | "Exhaust Enable" | Enable exhaust system |
| ModularDeviceFlipCoverSwitch | "Emergency Vent" | Emergency exhaust |
| ModularDeviceSquareButton | "System Reset" | Clear faults |
| ModularDeviceRoundButton | "Silence Alarm" | Mute audio alarm |
| ModularDeviceSquareButton | "Confirm Preset" | Confirm pending preset |

### Master Panel Displays

| Device Type | Name |
|-------------|------|
| ModularDeviceLEDdisplay3 | "TOTAL PRESSURE" |
| ModularDeviceLEDdisplay3 | "TARGET PRESSURE" |
| ModularDeviceLEDdisplay3 | "TEMPERATURE" |
| ModularDeviceLEDdisplay3 | "ACTIVE PRESET" |
| ModularDeviceLEDdisplay2 | "HEALTH RATING" |
| ModularDeviceSliderDiode2 | "PRESSURE BAR" |

### Master Panel Status LEDs (ModularDeviceLabelDiode2)

| Name | Color | Purpose |
|------|-------|---------|
| "POWER" | Green | System powered |
| "AUTO" | Green | Auto mode active |
| "MANUAL" | Yellow | Manual mode active |
| "HOLD" | Blue | Hold mode active |
| "CONFIRM PENDING" | Yellow | Awaiting preset confirm |
| "EXHAUST ACTIVE" | Red | Exhaust running |
| "MASTER WARNING" | Red | Any alarm active |
| "OVERPRESSURE" | Red | Pressure too high |
| "UNDERPRESSURE" | Red | Pressure too low |
| "O2 CRITICAL" | Red | O2 dangerously low |
| "ERROR" | Red | Critical fault |
| "PRESSURE UP" | White | Pressure rising |
| "PRESSURE DOWN" | White | Pressure falling |
| "PRESSURE STABLE" | Green | Pressure stable |

### Per-Gas Display Cluster (repeat for O2, N2, CO2)

| Device Type | Name Pattern |
|-------------|--------------|
| ModularDeviceLEDdisplay3 | "[GAS] CURRENT" |
| ModularDeviceLEDdisplay3 | "[GAS] TARGET" |
| ModularDeviceLEDdisplay3 | "[GAS] PARTIAL" |
| ModularDeviceLEDdisplay3 | "[GAS] FLOW" |
| ModularDeviceSliderDiode2 | "[GAS] TARGET BAR" |
| ModularDeviceSliderDiode2 | "[GAS] ACTUAL BAR" |
| ModularDeviceLabelDiode2 | "[GAS] OK" |
| ModularDeviceLabelDiode2 | "[GAS] LOW" |
| ModularDeviceLabelDiode2 | "[GAS] HIGH" |
| ModularDeviceLabelDiode2 | "[GAS] VALVE" |
| ModularDeviceLabelDiode2 | "[GAS] TREND UP" |
| ModularDeviceLabelDiode2 | "[GAS] TREND DOWN" |
| ModularDeviceLabelDiode2 | "[GAS] STABLE" |
| ModularDeviceDial | "[GAS] Tune" |
| ModularDeviceDial | "[GAS] Pump Rate" |
| ModularDeviceFlipCoverSwitch | "[GAS] Override" |

**Example:** For O2, names are "O2 CURRENT", "O2 TARGET", "O2 Tune", "O2 Pump Rate", etc.

**Pump Rate Dial (1-100 range, set in-game):**
- 100 = full calculated pump rate
- 50 = half speed (default)
- 10 = very gentle, 10% of calculated rate
- Allows per-gas tuning for large rooms with slow equalization

**Slider Diode Value Ranges (Setting 0-1):**
| Gas | Mapping | Full Scale |
|-----|---------|------------|
| Pressure | value / 150 | 0-150 kPa |
| O2 | value / 50 | 0-50% |
| N2 | value / 100 | 0-100% |
| CO2 | value / 20 | 0-20% |

### Preset Buttons (ModularDeviceRoundButton)

| Name | Preset # |
|------|----------|
| "Wheat" | 1 |
| "Corn" | 2 |
| "Potato" | 3 |
| "Tomato" | 4 |
| "Soybean" | 5 |
| "Rice" | 6 |
| "Pumpkin" | 7 |
| "Switchgrass" | 8 |
| "Tropical Lily" | 9 |
| "Peace Lily" | 10 |
| "Flower" | 11 |
| "Cocoa" | 12 |
| "Fern" | 13 |
| "Darga Fern" | 14 |
| "Mushroom" | 15 |
| "Sugarcane" | 16 |
| "Custom 1" | 17 |
| "Custom 2" | 18 |
| "Custom 3" | 19 |

### Alarm Device

| Device Type | Name |
|-------------|------|
| StructureSpeaker | "Greenhouse Alarm" |

---

## Step-by-Step Setup Guide

### Device Count Summary

| Category | Device Type | Quantity |
|----------|-------------|----------|
| **IC Housings** | StructureCircuitHousing | 8 |
| **Memory** | StructureLogicMemory | 3 |
| **Gas Sensors** | StructureGasSensor | 2-6 |
| **Daylight Sensor** | StructureDaylightSensor | 1 |
| **Valves** | StructureDigitalValve | 4 |
| **Pumps** | StructureTurboVolumePump | 4 |
| **Shutter Controller** | StructureCompositeWindowShutterController | 1 |
| **Grow Lights** | StructureGrowLight | Multiple |
| **Large Displays** | ModularDeviceLEDdisplay3 | 17 |
| **Small Displays** | ModularDeviceLEDdisplay2 | 4 |
| **Slider Bars** | ModularDeviceSliderDiode2 | 7 |
| **Status LEDs** | ModularDeviceLabelDiode2 | 31 |
| **Dials** | ModularDeviceDial | 7 |
| **Square Buttons** | ModularDeviceSquareButton | 5 |
| **Round Buttons** | ModularDeviceRoundButton | 20 |
| **Flip Switches** | ModularDeviceFlipCoverSwitch | 11 |
| **Speaker** | StructureSpeaker | 1 (optional) |

**Totals:**
- **Structures:** 8 IC + 3 Memory + 2-6 Sensors + 1 Daylight + 4 Valves + 4 Pumps + 1 Shutter Ctrl + Grow Lights + 1 Speaker = **25-29+ structures**
- **Modular Devices:** 17 + 4 + 7 + 31 + 7 + 5 + 20 + 11 = **102 modular devices**
- **Grand Total:** ~127-131+ devices (plus grow lights)

---

### Phase 1: IC Housings (8 total)

Place 8 IC Housings on your network. Label and load scripts:

**StructureCircuitHousing:**
- "Master IC" → Greenhouse Master Controller
- "O2 IC" → Greenhouse O2 Controller
- "N2 IC" → Greenhouse N2 Controller
- "CO2 IC" → Greenhouse CO2 Controller
- "Preset IC" → Greenhouse Preset Library
- "Safety IC" → Greenhouse Safety Monitor
- "Lighting IC" → Greenhouse Lighting Controller
- "Display IC" → Greenhouse Preset Display

---

### Phase 2: Memory Devices (3 total) - IMPORTANT: PIN WIRING REQUIRED

Place 3 Logic Memory devices. **Memory devices must be wired directly to IC Housing pins (d0-d2), not just on the same network.**

**StructureLogicMemory:**
- "System State" - Mode, active preset, alarm state
- "Gas Targets" - O2/N2/CO2 target percentages
- "Custom Presets" - User-defined preset values (Preset IC only)

#### IC Pin Wiring

Each IC Housing needs memory devices wired to specific pins:

**Master IC:**
- d0 = "System State"

**O2 IC / N2 IC / CO2 IC:**
- d0 = "System State"
- d1 = "Gas Targets"

**Preset IC:**
- d0 = "System State"
- d1 = "Gas Targets"
- d2 = "Custom Presets"

**Safety IC / Lighting IC / Display IC:**
- d0 = "System State"

**Why pin wiring?** IC10's memory read/write instructions (`get`/`put`) require device pins, not network names. The scripts use `d0.Memory[address]` syntax which only works with directly wired devices.

**Wiring Tip:** Use cables to connect multiple IC Housings to the same memory device. For example, all 8 ICs can share a single "System State" memory on their d0 pins.

---

### Phase 3: Sensors

Place Gas Sensors throughout the greenhouse. **All must have the same name:**

**StructureGasSensor:**
- "Greenhouse Sensor" (place 2-6 depending on room size)

**Tip:** Spread sensors evenly - the system averages all readings for accuracy.

---

### Phase 4: Gas Control Hardware

#### 4a. Oxygen Line
**StructureDigitalValve:**
- "O2 Valve"

**StructureTurboVolumePump:**
- "O2 Pump"

Connect: O2 Tank → O2 Valve → O2 Pump → Greenhouse

#### 4b. Nitrogen Line
**StructureDigitalValve:**
- "N2 Valve"

**StructureTurboVolumePump:**
- "N2 Pump"

Connect: N2 Tank → N2 Valve → N2 Pump → Greenhouse

#### 4c. Carbon Dioxide Line
**StructureDigitalValve:**
- "CO2 Valve"

**StructureTurboVolumePump:**
- "CO2 Pump"

Connect: CO2 Tank → CO2 Valve → CO2 Pump → Greenhouse

#### 4d. Exhaust Line
**StructureDigitalValve:**
- "Exhaust Valve"

**StructureTurboVolumePump:**
- "Exhaust Pump"

Connect: Greenhouse → Exhaust Valve → Exhaust Pump → Filtration/Vent

---

### Phase 5: Master Panel Controls

**ModularDeviceFlipCoverSwitch:**
- "Power"
- "Exhaust Enable"
- "Emergency Vent"

**ModularDeviceSquareButton:**
- "Auto"
- "Manual"
- "Hold"
- "System Reset"
- "Confirm Preset"

**ModularDeviceRoundButton:**
- "Silence Alarm"

---

### Phase 6: Master Panel Displays

**ModularDeviceLEDdisplay3:**
- "TOTAL PRESSURE"
- "TARGET PRESSURE"
- "TEMPERATURE"
- "ACTIVE PRESET"
- "PRESET NAME"

**ModularDeviceLEDdisplay2:**
- "PRESET"
- "HEALTH RATING"

**ModularDeviceSliderDiode2:**
- "PRESSURE BAR"

**Note:** "PRESET NAME" shows 3-5 letter abbreviation (controlled by Preset Display IC), "PRESET" shows the preset number (controlled by Master Controller).

---

### Phase 7: Master Panel Status LEDs

**ModularDeviceLabelDiode2 (Green):**
- "POWER"
- "AUTO"
- "PRESSURE STABLE"

**ModularDeviceLabelDiode2 (Yellow):**
- "MANUAL"
- "CONFIRM PENDING"

**ModularDeviceLabelDiode2 (Blue):**
- "HOLD"

**ModularDeviceLabelDiode2 (White):**
- "PRESSURE UP"
- "PRESSURE DOWN"

**ModularDeviceLabelDiode2 (Red):**
- "EXHAUST ACTIVE"
- "MASTER WARNING"
- "OVERPRESSURE"
- "UNDERPRESSURE"
- "ERROR"

---

### Phase 8: O2 Display Cluster

**ModularDeviceLEDdisplay3:**
- "O2 CURRENT"
- "O2 TARGET"
- "O2 PARTIAL"
- "O2 FLOW"

**ModularDeviceSliderDiode2:**
- "O2 TARGET BAR"
- "O2 ACTUAL BAR"

**ModularDeviceLabelDiode2:**
- "O2 OK"
- "O2 LOW"
- "O2 HIGH"
- "O2 VALVE"

**ModularDeviceDial:**
- "O2 Tune" (0-100, 50 = no offset)
- "O2 Pump Rate" (1-100, controls aggressiveness)

**ModularDeviceFlipCoverSwitch:**
- "O2 Override"

---

### Phase 9: N2 Display Cluster

**ModularDeviceLEDdisplay3:**
- "N2 CURRENT"
- "N2 TARGET"
- "N2 PARTIAL"
- "N2 FLOW"

**ModularDeviceSliderDiode2:**
- "N2 TARGET BAR"
- "N2 ACTUAL BAR"

**ModularDeviceLabelDiode2:**
- "N2 OK"
- "N2 LOW"
- "N2 HIGH"
- "N2 VALVE"

**ModularDeviceDial:**
- "N2 Tune" (0-100, 50 = no offset)
- "N2 Pump Rate" (1-100, controls aggressiveness)

**ModularDeviceFlipCoverSwitch:**
- "N2 Override"

---

### Phase 10: CO2 Display Cluster

**ModularDeviceLEDdisplay3:**
- "CO2 CURRENT"
- "CO2 TARGET"
- "CO2 PARTIAL"
- "CO2 FLOW"

**ModularDeviceSliderDiode2:**
- "CO2 TARGET BAR"
- "CO2 ACTUAL BAR"

**ModularDeviceLabelDiode2:**
- "CO2 OK"
- "CO2 LOW"
- "CO2 HIGH"
- "CO2 VALVE"

**ModularDeviceDial:**
- "CO2 Tune" (0-100, 50 = no offset)
- "CO2 Pump Rate" (1-100, controls aggressiveness)

**ModularDeviceFlipCoverSwitch:**
- "CO2 Override"

---

### Phase 11: Preset Buttons

**ModularDeviceRoundButton:**
- "Wheat" (#1)
- "Corn" (#2)
- "Potato" (#3)
- "Tomato" (#4)
- "Soybean" (#5)
- "Rice" (#6)
- "Pumpkin" (#7)
- "Switchgrass" (#8)
- "Tropical Lily" (#9)
- "Peace Lily" (#10)
- "Flower" (#11)
- "Cocoa" (#12)
- "Fern" (#13)
- "Darga Fern" (#14)
- "Mushroom" (#15)
- "Sugarcane" (#16)
- "Custom 1" (#17)
- "Custom 2" (#18)
- "Custom 3" (#19)

---

### Phase 12: Alarm (Optional)

**StructureSpeaker:**
- "Greenhouse Alarm"

---

### Phase 13: Lighting Controller

#### Sensors & Controllers

**StructureDaylightSensor:**
- "Greenhouse Daylight"

**StructureCompositeWindowShutterController:**
- "Greenhouse Shutters"

#### Grow Lights (batch controlled - all same name)

**StructureGrowLight:**
- "Greenhouse Light" (place as many as needed)

#### Controls

**ModularDeviceDial:**
- "Light Hours" (set range 0-24 in-game)

**ModularDeviceFlipCoverSwitch:**
- "Blackout Mode"
- "Shutter Override"
- "Shutters Open"
- "Lights Override"
- "Lights On"

#### Indicators

**ModularDeviceLabelDiode2 (Green):**
- "LIGHTS ON"

**ModularDeviceLabelDiode2 (Blue):**
- "LIGHTS OFF"

**ModularDeviceLabelDiode2 (White):**
- "SHUTTERS OPEN"

**ModularDeviceLabelDiode2 (Yellow):**
- "SHUTTERS CLOSED"

**ModularDeviceLabelDiode2 (Red):**
- "BLACKOUT MODE"

**ModularDeviceLabelDiode2 (Orange):**
- "DAYLIGHT"

#### Displays

**ModularDeviceLEDdisplay2:**
- "LIGHT HOURS"
- "CYCLE TIME"

**Note:** LED colors are set programmatically by the script.

---

### Phase 14: Initial Configuration

1. **Turn on "Power" switch**
2. **Press "Auto" button** to enter automatic mode
3. **Select a plant preset** (e.g., press "Wheat" button)
4. **Press "Confirm Preset"** to apply
5. **Adjust pump rate dials** if needed:
   - Start at 50 (half speed)
   - Lower if gases overshoot targets
   - Raise if adjustment is too slow
6. **Set "Light Hours" dial** to desired value (e.g., 16 for most plants)
7. **Monitor displays** - system should begin regulating

**Lighting Notes:**
- Shutters auto-close during daylight, open at night
- Grow lights cycle based on "Light Hours" setting
- Mushroom preset (#15) auto-enables blackout mode
- Use override switches for manual control when needed

---

### Troubleshooting

**No readings:**
- Check all devices are on same network

**Gases overshooting:**
- Lower pump rate dials (try 20-30)

**Adjustment too slow:**
- Raise pump rate dials (try 70-80)

**"ERROR" LED on:**
- Check sensor connections, press "System Reset"

**Preset not applying:**
- Press "Confirm Preset" after selecting plant

**Wrong gas ratios:**
- Verify memory devices are named correctly

**Mode/preset not syncing:**
- Check memory devices are wired to correct IC pins (see Phase 2)

**IC shows no errors but nothing works:**
- Memory must be on d0/d1/d2 pins, not just network

---

## Notes

- All scripts will be new tabs - never overwrite existing scripts
- Use ModularDeviceSliderDiode2 (larger version) for all slider bars
- **SliderDiode2 Setting range is 0-1, not 0-100** - values must be normalized
- Valve closes before pump stops (clears pipe segment)
- Room equalization time needed due to gases entering at one end
- 100L/tick at 100% pump rate can rapidly overshoot - use conservative rates
