# Claude Code Hooks Setup Guide

A guide for setting up Claude Code hooks to improve your development workflow. This covers the basics and includes ready-to-use hooks for context preservation across compactions.

## What Are Hooks?

Hooks are scripts that run automatically when Claude Code does certain things:
- **Before/after tool calls** (reading files, running commands, etc.)
- **When sessions start or end**
- **Before context compaction** (when Claude's memory gets full and needs to compress)

Think of them like Git hooks, but for Claude Code.

## Quick Reference: Hook Events

| Event | When It Fires | Common Uses |
|-------|---------------|-------------|
| `PreToolUse` | Before any tool runs | Block dangerous commands, log actions |
| `PostToolUse` | After any tool completes | Auto-format code, cleanup |
| `SessionStart` | Session begins/resumes | Load context, set environment |
| `SessionEnd` | Session ends | Save state, cleanup |
| `PreCompact` | Before memory compression | **Save work state** |
| `UserPromptSubmit` | Before processing your message | Add context, validate input |
| `Stop` | When Claude finishes responding | Detect if task is complete |

## File Locations

Claude Code looks for settings in these locations (in order of priority):

```
~/.claude/settings.json           # Global (all projects)
your-project/.claude/settings.json      # Project (shared with team)
your-project/.claude/settings.local.json  # Local (your machine only, gitignored)
```

Hooks scripts go in:
```
your-project/.claude/hooks/       # Project hooks
~/.claude/hooks/                  # Global hooks
```

## Basic Hook Setup

### Step 1: Create the hooks directory

```bash
mkdir -p .claude/hooks
```

### Step 2: Create a hook script

Example: Log all bash commands to a file

```bash
# .claude/hooks/log-commands.sh
#!/bin/bash
INPUT=$(cat)  # Read the hook input from stdin
COMMAND=$(echo "$INPUT" | jq -r '.tool_input.command // "unknown"')
echo "$(date): $COMMAND" >> ~/.claude/command-log.txt
exit 0
```

### Step 3: Configure the hook in settings

Add to your `.claude/settings.local.json`:

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          {
            "type": "command",
            "command": "bash \"$CLAUDE_PROJECT_DIR/.claude/hooks/log-commands.sh\"",
            "timeout": 10
          }
        ]
      }
    ]
  }
}
```

### Step 4: Reload hooks

Run `/hooks` in Claude Code to see your registered hooks. You may need to restart the session for changes to take effect.

## Context Preservation Hooks (Ready to Use)

These hooks save your work state before context compaction and restore it after. This helps Claude remember what you were working on.

### Pre-Compact Hook (saves state)

Create `.claude/hooks/pre-compact-save.sh`:

```bash
#!/bin/bash
# Saves context state before auto-compaction

set -e
INPUT=$(cat)
TRIGGER=$(echo "$INPUT" | jq -r '.trigger // "unknown"')

PROJECT_DIR="${CLAUDE_PROJECT_DIR:-$(pwd)}"
STATE_FILE="$PROJECT_DIR/.claude/context-state.json"
TIMESTAMP=$(date -Iseconds)

# Get git info
GIT_BRANCH=$(git -C "$PROJECT_DIR" rev-parse --abbrev-ref HEAD 2>/dev/null || echo "unknown")
GIT_COMMIT=$(git -C "$PROJECT_DIR" rev-parse --short HEAD 2>/dev/null || echo "unknown")
GIT_STATUS=$(git -C "$PROJECT_DIR" status --short 2>/dev/null | head -20 || echo "")

# Get recent files (modified in last hour)
RECENT_FILES=$(find "$PROJECT_DIR" -type f \( -name "*.cs" -o -name "*.js" -o -name "*.py" -o -name "*.ts" \) -mmin -60 2>/dev/null | head -10 | tr '\n' ',' || echo "")

# Try to read current todos
TODOS_DIR="$HOME/.claude/todos"
CURRENT_TODOS="[]"
if [ -d "$TODOS_DIR" ]; then
    LATEST_TODO=$(ls -t "$TODOS_DIR"/*.json 2>/dev/null | head -1)
    if [ -n "$LATEST_TODO" ] && [ -f "$LATEST_TODO" ]; then
        CURRENT_TODOS=$(cat "$LATEST_TODO" 2>/dev/null || echo "[]")
    fi
fi

# Save state
cat > "$STATE_FILE" << EOF
{
  "saved_at": "$TIMESTAMP",
  "trigger": "$TRIGGER",
  "git": {
    "branch": "$GIT_BRANCH",
    "commit": "$GIT_COMMIT",
    "pending_changes": $(echo "$GIT_STATUS" | jq -R -s 'split("\n") | map(select(length > 0))')
  },
  "recent_files": $(echo "$RECENT_FILES" | tr ',' '\n' | jq -R -s 'split("\n") | map(select(length > 0))'),
  "todos": $CURRENT_TODOS
}
EOF

echo "Context saved before $TRIGGER compaction" >&2
exit 0
```

### Session Start Hook (restores state)

Create `.claude/hooks/session-start-restore.sh`:

```bash
#!/bin/bash
# Restores context after compaction

set -e
INPUT=$(cat)
SOURCE=$(echo "$INPUT" | jq -r '.source // "unknown"')

PROJECT_DIR="${CLAUDE_PROJECT_DIR:-$(pwd)}"
STATE_FILE="$PROJECT_DIR/.claude/context-state.json"

# Only restore if resuming from compaction
if [ "$SOURCE" != "compact" ]; then
    echo "Session started ($SOURCE). Project: $(basename "$PROJECT_DIR")"
    exit 0
fi

if [ ! -f "$STATE_FILE" ]; then
    echo "No saved context found after compaction."
    exit 0
fi

STATE=$(cat "$STATE_FILE")
SAVED_AT=$(echo "$STATE" | jq -r '.saved_at')
GIT_BRANCH=$(echo "$STATE" | jq -r '.git.branch')
TODOS=$(echo "$STATE" | jq -r '.todos')

# Format output
cat << EOF
=== CONTEXT RESTORED AFTER COMPACTION ===
Saved: $SAVED_AT
Branch: $GIT_BRANCH

Resume your previous work. Full state in .claude/context-state.json
==========================================
EOF

exit 0
```

### Configure Both Hooks

Add to `.claude/settings.local.json`:

```json
{
  "hooks": {
    "PreCompact": [
      {
        "matcher": "auto|manual",
        "hooks": [
          {
            "type": "command",
            "command": "bash \"$CLAUDE_PROJECT_DIR/.claude/hooks/pre-compact-save.sh\"",
            "timeout": 30
          }
        ]
      }
    ],
    "SessionStart": [
      {
        "matcher": "compact|startup|resume",
        "hooks": [
          {
            "type": "command",
            "command": "bash \"$CLAUDE_PROJECT_DIR/.claude/hooks/session-start-restore.sh\"",
            "timeout": 30
          }
        ]
      }
    ]
  }
}
```

## Hook Input/Output

### Input (stdin)

Hooks receive JSON on stdin with context about what triggered them:

```json
{
  "session_id": "abc123",
  "cwd": "/path/to/project",
  "hook_event_name": "PreToolUse",
  "tool_name": "Bash",
  "tool_input": {
    "command": "npm test"
  }
}
```

### Output (exit codes)

- **Exit 0**: Success, allow the action
- **Exit 2**: Block the action (shows stderr to user)
- **Other**: Non-blocking error

### Output (stdout)

For some hooks, stdout content becomes additional context for Claude. For example, `SessionStart` stdout is shown to Claude at the start of the session.

## Environment Variables

Available in all hooks:

| Variable | Description |
|----------|-------------|
| `$CLAUDE_PROJECT_DIR` | Absolute path to project root |
| `$CLAUDE_ENV_FILE` | File to write env vars (SessionStart only) |

## Common Patterns

### Block Dangerous Commands

```bash
#!/bin/bash
# .claude/hooks/block-dangerous.sh
INPUT=$(cat)
COMMAND=$(echo "$INPUT" | jq -r '.tool_input.command // ""')

# Block rm -rf on important dirs
if echo "$COMMAND" | grep -qE 'rm\s+-rf\s+(/|~|/home)'; then
    echo "Blocked dangerous rm command" >&2
    exit 2
fi

exit 0
```

### Auto-Format After Edits

```bash
#!/bin/bash
# .claude/hooks/auto-format.sh
INPUT=$(cat)
FILE=$(echo "$INPUT" | jq -r '.tool_input.file_path // ""')

# Run prettier on JS/TS files
if [[ "$FILE" =~ \.(js|ts|jsx|tsx)$ ]]; then
    npx prettier --write "$FILE" 2>/dev/null || true
fi

exit 0
```

### Add Context Based on Keywords

```bash
#!/bin/bash
# .claude/hooks/inject-context.sh
INPUT=$(cat)
PROMPT=$(echo "$INPUT" | jq -r '.prompt // ""')

# If user mentions "database", add schema context
if echo "$PROMPT" | grep -qi "database\|sql\|schema"; then
    echo "Database schema is in src/db/schema.sql"
    echo "Migration files are in src/db/migrations/"
fi

exit 0
```

## Debugging Hooks

1. **Check hook registration**: Run `/hooks` in Claude Code
2. **Test manually**:
   ```bash
   echo '{"source":"compact"}' | bash .claude/hooks/session-start-restore.sh
   ```
3. **Check stderr**: Hook errors go to stderr and may be shown in Claude Code
4. **Add logging**: Write to a log file in your hook for debugging

## Tips

1. **Start simple**: Begin with one hook and verify it works before adding more
2. **Use `jq`**: It's essential for parsing JSON input - install it if you don't have it
3. **Handle errors gracefully**: Use `|| true` or `2>/dev/null` for commands that might fail
4. **Keep hooks fast**: They run synchronously and can slow down Claude Code
5. **Test exit codes**: Make sure blocking hooks (exit 2) only block when intended

## Windows Notes

On Windows, hooks run in Git Bash. Make sure:
- Git Bash is installed (comes with Git for Windows)
- Scripts have `#!/bin/bash` shebang
- Use forward slashes in paths within scripts
- `jq` is installed and in PATH (download from https://jqlang.github.io/jq/)

## Resources

- Official docs: https://docs.anthropic.com/en/docs/claude-code/hooks
- `/hooks` command in Claude Code to manage hooks interactively
