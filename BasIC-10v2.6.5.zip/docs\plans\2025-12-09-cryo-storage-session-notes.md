# Europa Cryogenic Storage Facility - Session Notes
**Date:** 2025-12-09
**Status:** In Progress

## Project Overview
7 identical rooms for storing all game gases as liquids on Europa. Each room is network-isolated, uses identical device names, and runs the same master scripts configured for the specific gas.

**Purpose:** YouTube showcase - NASA-style control panels, maximum visual impact

## Completed Scripts (8 total)

### 1. Cryo - Gas Selector (Phase 1 - Info Panel)
- Dial-based gas info display (reference only)
- Reads from GasType InfoDial, writes to info memory chips
- Device: ModularDeviceDial "GasType InfoDial"

### 2. Cryo - Gas Selector Buttons (67 lines)
- Button-based gas selection for actual chamber control
- Edge detection for 7 momentary buttons
- Safety lockout: ModularDeviceSwitch "Unlock Chamber Select"
- Buttons: ModularDeviceSquareButton "Set Oxygen/CO2/Nitrogen/N2O/Volatiles/Pollutant/Water"
- Warning light: ModularDeviceLightSmall "Gas Selector Warning"
- Writes to: "Chamber Gas ID" memory

### 3. Cryo - Gas Selector Display (60 lines)
- Reads gasID from memory, controls indicator lights and gas name display
- Indicator lights: ModularDeviceLightSmall "Oxygen/Nitrogen/Volatiles/CO2/Pollutant/N2O/Water Active"
- Gas display: ModularDeviceLEDdisplay3 "Selected Gas" (Mode 10 - octet ASCII)

### 4. Cryo - Gas Parameters (76 lines)
- Reads Chamber Gas ID, writes all chamber parameters
- Writes to: Chamber Min/Max/Target Temp, Chamber Min/Max/Target Press, Chamber Gas Name

### 5. Cryo - Display Controller (35 lines)
- Info panel displays (from dial-based memory)
- Chamber displays (from button-based memory + live sensor)
- Chamber Volume hardcoded: 216,000L (27 cubes x 8000L)
- Displays: MinTemperature/MaxTemperature/MinPressure/MaxPressure Display2, GasType Display2
- Chamber: Chamber Temperature/Pressure, Chamber Set Temperature/Pressure, Chamber/Fluid/Gas Volume

### 6. Cryo - Display Controller 2 (32 lines)
- 14 gas/liquid ratio sliders
- Device: ModularDeviceSliderDiode2
- Gas sliders: O2/N2/VOL/CO2/POL/N2O/H2O Gas Slider
- Liquid sliders: O2/N2/VOL/CO2/POL/N2O/H2O Liquid Slider
- Properties: RatioOxygen/Nitrogen/Volatiles/CarbonDioxide/Pollutant/NitrousOxide/Steam (gas)
- Properties: RatioLiquidOxygen/Nitrogen/Volatiles/CarbonDioxide/Pollutant/NitrousOxide, RatioWater (liquid)

### 7. Cryo - Display Controller 3 (31 lines)
- Pipe analyzer displays (6 total)
- Sensors: StructurePipeAnalyzer
  - "Cooling Loop Sensor Interior" - inside cooling loop, should be empty when inactive
  - "Cooling Loop Sensor Exterior" - outside loop, always has pressure
  - "Chamber Exhaust Sensor" - on exhaust piping
- Displays (ModularDeviceLEDdisplay2):
  - Interior Loop Temp/Press
  - Exterior Loop Temp/Press
  - Exhaust Temp/Press

### 8. Cryo - Status Controller (44 lines)
- Emergency button: ModularDeviceEmergencyButton3x3 "EMERGENCY"
- Alarm override: ModularDeviceSwitch "Alarm Override" (RED when ON, GREEN when OFF)
- Main light: ModularDeviceLightLarge "Main Status Light"
- Console alarm: ModularDeviceAlarm "Console Alarm"
- Status: 0=OK (green), 1=Warning (yellow), 2=Emergency (red)
- Warning triggered by: Chamber Purge Active = 1

### 9. Cryo - Purge Controller (27 lines)
- Purge button: ModularDeviceSquareButton "PURGE CHAMBER" (RED when active, GREEN when idle)
- Vent: StructurePoweredVentLarge "Chamber Exhaust"
- Auto-stops when TotalMoles < 1
- Also used for pressure control (dual purpose)

## Gas ID Mapping
| ID | Gas | Target K | Min Press Pa | Max Press Pa | Gas Name Code |
|----|-----|----------|--------------|--------------|---------------|
| 0 | O2 | 130 | 7000 | 6000000 | 20274 |
| 1 | N2 | 150 | 7000 | 6000000 | 20018 |
| 2 | VOL | 140 | 7000 | 6000000 | 5656396 |
| 3 | CO2 | 240 | 517000 | 6000000 | 4411186 |
| 4 | POL | 350 | 1800000 | 6000000 | 5263180 |
| 5 | N2O | 350 | 800000 | 2000000 | 5124687 |
| 6 | H2O | 400 | 7000 | 6000000 | 4731471 |
| -1 | --- | - | - | - | 2960685 |

## Memory Chips
### Phase 1 (Info Panel - dial-based)
- Gas ID Memory, Min Temp Memory, Max Temp Memory, Target Temp Memory
- Min Press Memory, Max Press Memory, Gas Name Memory

### Phase 2 (Chamber Control - button-based)
- Chamber Gas ID, Chamber Min Temp, Chamber Max Temp, Chamber Target Temp
- Chamber Min Press, Chamber Max Press, Chamber Target Press, Chamber Gas Name
- Chamber Purge Active, Chamber Status

## Key Devices
### Chamber
- StructureGasSensor "Chamber Gas Sensor"
- StructurePoweredVentLarge "Chamber Exhaust" (purge AND pressure control)

### Pipe Analyzers
- StructurePipeAnalyzer "Cooling Loop Sensor Interior"
- StructurePipeAnalyzer "Cooling Loop Sensor Exterior"
- StructurePipeAnalyzer "Chamber Exhaust Sensor"

### Controls
- ModularDeviceSwitch "Unlock Chamber Select"
- ModularDeviceSwitch "Alarm Override"
- ModularDeviceSquareButton "PURGE CHAMBER"
- ModularDeviceEmergencyButton3x3 "EMERGENCY"

## Pending Tasks
1. **Build Temperature Controller** - cooling logic, uses pipe sensors
2. **Build Pressure Controller** - uses Chamber Exhaust vent (coordinate with purge)
3. **Build Safety Monitor** - pipe liquid detection, redundant monitoring
4. **Add liquid detection indicators** - 3 lights for 3 pipe networks
5. **Control Room Integration**

## Safety Requirements
- Liquid detected in ANY gas pipe analyzer = Warning (yellow) status
- Illuminate indicator showing WHICH pipe network has liquid
- Pressure relief: Auto-vent at 7.5 MPa, stop at 6 MPa
- Wall burst pressure: 8.0 MPa

## Display Modes Reference
- Mode 3: Temperature (Kelvin)
- Mode 10: Octet ASCII (text)
- Mode 12: Liters
- Mode 13: Moles
- Mode 14: Pressure (Pa)

## Color Values
- 0 = Blue
- 2 = Green
- 4 = Red
- 5 = Yellow

## Ratio Properties for Water
- RatioSteam = gaseous water (steam)
- RatioWater = liquid water

## Notes
- Pressure displays expect Pa, sensor returns kPa (multiply by 1000)
- Chamber volume: 216,000L (27 cubes x 8000L) - hardcoded
- Edge detection: Use `IF currBtn = 1 THEN IF prevBtn = 0 THEN` pattern
- Button/switch colors should only update when state changes (avoid flicker)
