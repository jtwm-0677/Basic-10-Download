# Basic-10 In-Game Editor - Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Build a standalone IMGUI-based BASIC code editor that replaces the vanilla IC10 chip editor in Stationeers.

**Architecture:** MonoBehaviour window rendered via OnGUI(), with separate classes for text buffer management, syntax highlighting, and script file I/O. The editor intercepts `InputSourceCode.ShowInputPanel` via Harmony patch and renders our custom editor instead.

**Tech Stack:** Unity IMGUI, BepInEx 5.4, Harmony 2, Basic10.Core compiler

---

## Phase 1: Core Infrastructure

### Task 1.1: Create Editor Window Shell

**Files:**
- Create: `.worktrees/multi-platform/Basic10.GameMod/Editor/EditorWindow.cs`

**Step 1: Create the editor window MonoBehaviour**

```csharp
using UnityEngine;

namespace Basic10.GameMod.Editor;

/// <summary>
/// Main IMGUI editor window for BASIC code editing.
/// Attached to a persistent GameObject when activated.
/// </summary>
public class EditorWindow : MonoBehaviour
{
    private static EditorWindow? _instance;
    private static GameObject? _hostObject;

    private bool _isVisible;
    private Rect _windowRect;
    private string _sourceCode = "";

    // Current chip being edited
    private object? _targetChip;
    private System.Action<string>? _onSave;
    private System.Action? _onCancel;

    public static bool IsOpen => _instance != null && _instance._isVisible;

    /// <summary>
    /// Show the editor with the given source code.
    /// </summary>
    public static void Show(string initialCode, object targetChip,
        System.Action<string> onSave, System.Action onCancel)
    {
        EnsureInstance();
        _instance!._sourceCode = initialCode ?? "";
        _instance._targetChip = targetChip;
        _instance._onSave = onSave;
        _instance._onCancel = onCancel;
        _instance._isVisible = true;

        Basic10Plugin.Log.LogInfo("Basic-10 Editor opened");
    }

    /// <summary>
    /// Hide the editor without saving.
    /// </summary>
    public static void Hide()
    {
        if (_instance != null)
        {
            _instance._isVisible = false;
        }
    }

    private static void EnsureInstance()
    {
        if (_instance != null) return;

        _hostObject = new GameObject("Basic10_EditorWindow");
        DontDestroyOnLoad(_hostObject);
        _instance = _hostObject.AddComponent<EditorWindow>();
    }

    private void Awake()
    {
        // Center window on screen
        var screenW = Screen.width;
        var screenH = Screen.height;
        var winW = Mathf.Min(1200, screenW - 100);
        var winH = Mathf.Min(800, screenH - 100);
        _windowRect = new Rect((screenW - winW) / 2, (screenH - winH) / 2, winW, winH);
    }

    private void OnGUI()
    {
        if (!_isVisible) return;

        // Lock game input while editor is open
        GUI.FocusControl("Basic10Editor");

        // Draw window
        _windowRect = GUI.Window(
            id: 98765, // Unique ID
            clientRect: _windowRect,
            func: DrawWindow,
            text: "Basic-10 Editor",
            style: GUI.skin.window
        );
    }

    private void DrawWindow(int windowId)
    {
        // Toolbar
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Save", GUILayout.Width(80)))
        {
            HandleSave();
        }
        if (GUILayout.Button("Compile", GUILayout.Width(80)))
        {
            HandleCompile();
        }
        GUILayout.FlexibleSpace();
        if (GUILayout.Button("Cancel", GUILayout.Width(80)))
        {
            HandleCancel();
        }
        GUILayout.EndHorizontal();

        GUILayout.Space(10);

        // Main editor area (placeholder)
        GUI.SetNextControlName("Basic10Editor");
        _sourceCode = GUILayout.TextArea(_sourceCode, GUILayout.ExpandHeight(true));

        // Status bar
        GUILayout.BeginHorizontal();
        var lineCount = _sourceCode.Split('\n').Length;
        GUILayout.Label($"Lines: {lineCount}");
        GUILayout.FlexibleSpace();
        GUILayout.Label($"Size: {_sourceCode.Length} chars");
        GUILayout.EndHorizontal();

        // Make window draggable
        GUI.DragWindow(new Rect(0, 0, _windowRect.width, 25));
    }

    private void HandleSave()
    {
        _onSave?.Invoke(_sourceCode);
        _isVisible = false;
        Basic10Plugin.Log.LogInfo("Basic-10 Editor: Save requested");
    }

    private void HandleCompile()
    {
        // TODO: Preview compilation without saving
        Basic10Plugin.Log.LogInfo("Basic-10 Editor: Compile requested");
    }

    private void HandleCancel()
    {
        _onCancel?.Invoke();
        _isVisible = false;
        Basic10Plugin.Log.LogInfo("Basic-10 Editor: Cancelled");
    }

    private void OnDestroy()
    {
        _instance = null;
    }
}
```

**Step 2: Build to verify no compilation errors**

Run: `dotnet build .worktrees/multi-platform/Basic10.GameMod/Basic10.GameMod.csproj`
Expected: Build succeeded

**Step 3: Commit**

```bash
git add .worktrees/multi-platform/Basic10.GameMod/Editor/EditorWindow.cs
git commit -m "feat(gamemod): add IMGUI editor window shell"
```

---

### Task 1.2: Patch Game to Intercept Editor Opening

**Files:**
- Modify: `.worktrees/multi-platform/Basic10.GameMod/EditorPatches.cs`

**Step 1: Add patch for InputSourceCode.ShowInputPanel**

Add the following patch class inside `EditorPatches.cs`:

```csharp
/// <summary>
/// Patch InputSourceCode.ShowInputPanel to show our editor instead.
/// </summary>
[HarmonyPatch]
public static class ShowInputPanelPatch
{
    // Find the method dynamically since it may vary by game version
    static MethodBase? TargetMethod()
    {
        var inputSourceType = typeof(ProgrammableChip).Assembly.GetType("Assets.Scripts.UI.InputSourceCode");
        if (inputSourceType == null)
        {
            Basic10Plugin.Log.LogWarning("InputSourceCode type not found");
            return null;
        }

        var method = inputSourceType.GetMethod("ShowInputPanel",
            BindingFlags.Public | BindingFlags.Static);
        if (method == null)
        {
            Basic10Plugin.Log.LogWarning("ShowInputPanel method not found");
        }
        return method;
    }

    static bool Prefix(ProgrammableChip chip)
    {
        try
        {
            // Get current source code from chip
            var currentCode = chip.SourceCode ?? "";

            // Check if we have stored BASIC source
            var basicSource = ChipStorage.LoadBasicSource(chip);
            if (!string.IsNullOrEmpty(basicSource))
            {
                currentCode = basicSource;
            }

            // Show our editor
            Editor.EditorWindow.Show(
                initialCode: currentCode,
                targetChip: chip,
                onSave: (code) => SaveToChip(chip, code),
                onCancel: () => { /* Nothing to do */ }
            );

            // Skip original method
            return false;
        }
        catch (Exception ex)
        {
            Basic10Plugin.Log.LogError($"Failed to open Basic-10 editor: {ex}");
            // Fall through to original editor
            return true;
        }
    }

    private static void SaveToChip(ProgrammableChip chip, string code)
    {
        try
        {
            // If it's BASIC, compile first
            if (IsBasicCode(code))
            {
                var result = _compiler.Compile(code);

                if (!result.Success)
                {
                    ShowCompilationError(result.Errors);
                    return;
                }

                // Save BASIC source for future editing
                ChipStorage.SaveBasicSource(chip, code);

                // Set compiled IC10 code
                chip.SetSourceCode(result.IC10Code);
                Basic10Plugin.Log.LogInfo($"Saved BASIC code: {result.LineCount} IC10 lines");
            }
            else
            {
                // Raw IC10 - save directly
                chip.SetSourceCode(code);
                Basic10Plugin.Log.LogInfo("Saved IC10 code directly");
            }
        }
        catch (Exception ex)
        {
            Basic10Plugin.Log.LogError($"Failed to save code: {ex}");
            ShowError($"Save failed: {ex.Message}");
        }
    }
}
```

**Step 2: Build to verify**

Run: `dotnet build .worktrees/multi-platform/Basic10.GameMod/Basic10.GameMod.csproj`
Expected: Build succeeded

**Step 3: Commit**

```bash
git add .worktrees/multi-platform/Basic10.GameMod/EditorPatches.cs
git commit -m "feat(gamemod): intercept chip editor to show Basic-10 editor"
```

---

## Phase 2: Text Buffer & State Management

### Task 2.1: Create TextBuffer Class (Testable Core)

**Files:**
- Create: `.worktrees/multi-platform/Basic10.GameMod/Editor/TextBuffer.cs`
- Create: `.worktrees/multi-platform/Basic10.GameMod.Tests/TextBufferTests.cs` (if test project exists, else skip tests)

**Step 1: Create the TextBuffer class**

```csharp
using System;
using System.Collections.Generic;
using System.Text;

namespace Basic10.GameMod.Editor;

/// <summary>
/// Manages text content with line-based operations, cursor position, and selection.
/// Pure C# class for testability.
/// </summary>
public class TextBuffer
{
    private readonly List<string> _lines = new() { "" };

    // Cursor position
    public int CursorLine { get; private set; }
    public int CursorColumn { get; private set; }

    // Selection (if any)
    public bool HasSelection => SelectionStart != SelectionEnd;
    public (int line, int col) SelectionStart { get; private set; }
    public (int line, int col) SelectionEnd { get; private set; }

    public int LineCount => _lines.Count;

    public string GetLine(int index)
    {
        if (index < 0 || index >= _lines.Count) return "";
        return _lines[index];
    }

    public string GetAllText()
    {
        return string.Join("\n", _lines);
    }

    public void SetAllText(string text)
    {
        _lines.Clear();
        if (string.IsNullOrEmpty(text))
        {
            _lines.Add("");
        }
        else
        {
            _lines.AddRange(text.Split('\n'));
        }

        // Clamp cursor to valid position
        CursorLine = Math.Min(CursorLine, _lines.Count - 1);
        CursorColumn = Math.Min(CursorColumn, _lines[CursorLine].Length);
        ClearSelection();
    }

    public void InsertChar(char c)
    {
        DeleteSelection();

        if (c == '\n')
        {
            // Split current line
            var currentLine = _lines[CursorLine];
            var before = currentLine.Substring(0, CursorColumn);
            var after = currentLine.Substring(CursorColumn);
            _lines[CursorLine] = before;
            _lines.Insert(CursorLine + 1, after);
            CursorLine++;
            CursorColumn = 0;
        }
        else
        {
            // Insert character at cursor
            var line = _lines[CursorLine];
            _lines[CursorLine] = line.Insert(CursorColumn, c.ToString());
            CursorColumn++;
        }
    }

    public void InsertText(string text)
    {
        DeleteSelection();

        foreach (var c in text)
        {
            InsertChar(c);
        }
    }

    public void Backspace()
    {
        if (HasSelection)
        {
            DeleteSelection();
            return;
        }

        if (CursorColumn > 0)
        {
            // Delete char before cursor
            var line = _lines[CursorLine];
            _lines[CursorLine] = line.Remove(CursorColumn - 1, 1);
            CursorColumn--;
        }
        else if (CursorLine > 0)
        {
            // Join with previous line
            var prevLine = _lines[CursorLine - 1];
            var currentLine = _lines[CursorLine];
            _lines[CursorLine - 1] = prevLine + currentLine;
            _lines.RemoveAt(CursorLine);
            CursorLine--;
            CursorColumn = prevLine.Length;
        }
    }

    public void Delete()
    {
        if (HasSelection)
        {
            DeleteSelection();
            return;
        }

        var line = _lines[CursorLine];
        if (CursorColumn < line.Length)
        {
            // Delete char at cursor
            _lines[CursorLine] = line.Remove(CursorColumn, 1);
        }
        else if (CursorLine < _lines.Count - 1)
        {
            // Join with next line
            _lines[CursorLine] = line + _lines[CursorLine + 1];
            _lines.RemoveAt(CursorLine + 1);
        }
    }

    public void MoveCursor(int lineDelta, int colDelta, bool extend = false)
    {
        if (extend && !HasSelection)
        {
            SelectionStart = (CursorLine, CursorColumn);
        }

        // Apply delta
        CursorLine = Math.Clamp(CursorLine + lineDelta, 0, _lines.Count - 1);
        var lineLen = _lines[CursorLine].Length;
        CursorColumn = Math.Clamp(CursorColumn + colDelta, 0, lineLen);

        if (extend)
        {
            SelectionEnd = (CursorLine, CursorColumn);
        }
        else
        {
            ClearSelection();
        }
    }

    public void SetCursor(int line, int col, bool extend = false)
    {
        if (extend && !HasSelection)
        {
            SelectionStart = (CursorLine, CursorColumn);
        }

        CursorLine = Math.Clamp(line, 0, _lines.Count - 1);
        var lineLen = _lines[CursorLine].Length;
        CursorColumn = Math.Clamp(col, 0, lineLen);

        if (extend)
        {
            SelectionEnd = (CursorLine, CursorColumn);
        }
        else
        {
            ClearSelection();
        }
    }

    public void MoveToLineStart(bool extend = false)
    {
        SetCursor(CursorLine, 0, extend);
    }

    public void MoveToLineEnd(bool extend = false)
    {
        SetCursor(CursorLine, _lines[CursorLine].Length, extend);
    }

    public void MoveToDocumentStart(bool extend = false)
    {
        SetCursor(0, 0, extend);
    }

    public void MoveToDocumentEnd(bool extend = false)
    {
        SetCursor(_lines.Count - 1, _lines[^1].Length, extend);
    }

    public void SelectAll()
    {
        SelectionStart = (0, 0);
        SelectionEnd = (_lines.Count - 1, _lines[^1].Length);
        CursorLine = _lines.Count - 1;
        CursorColumn = _lines[^1].Length;
    }

    public string GetSelectedText()
    {
        if (!HasSelection) return "";

        var (startLine, startCol) = OrderedSelectionStart();
        var (endLine, endCol) = OrderedSelectionEnd();

        if (startLine == endLine)
        {
            return _lines[startLine].Substring(startCol, endCol - startCol);
        }

        var sb = new StringBuilder();
        sb.Append(_lines[startLine].Substring(startCol));
        for (int i = startLine + 1; i < endLine; i++)
        {
            sb.Append('\n');
            sb.Append(_lines[i]);
        }
        sb.Append('\n');
        sb.Append(_lines[endLine].Substring(0, endCol));
        return sb.ToString();
    }

    public void ClearSelection()
    {
        SelectionStart = (0, 0);
        SelectionEnd = (0, 0);
    }

    private void DeleteSelection()
    {
        if (!HasSelection) return;

        var (startLine, startCol) = OrderedSelectionStart();
        var (endLine, endCol) = OrderedSelectionEnd();

        if (startLine == endLine)
        {
            var line = _lines[startLine];
            _lines[startLine] = line.Remove(startCol, endCol - startCol);
        }
        else
        {
            // Merge first and last line
            var firstPart = _lines[startLine].Substring(0, startCol);
            var lastPart = _lines[endLine].Substring(endCol);
            _lines[startLine] = firstPart + lastPart;

            // Remove lines in between
            for (int i = startLine + 1; i <= endLine; i++)
            {
                _lines.RemoveAt(startLine + 1);
            }
        }

        CursorLine = startLine;
        CursorColumn = startCol;
        ClearSelection();
    }

    private (int line, int col) OrderedSelectionStart()
    {
        if (SelectionStart.line < SelectionEnd.line ||
            (SelectionStart.line == SelectionEnd.line && SelectionStart.col < SelectionEnd.col))
        {
            return SelectionStart;
        }
        return SelectionEnd;
    }

    private (int line, int col) OrderedSelectionEnd()
    {
        if (SelectionStart.line < SelectionEnd.line ||
            (SelectionStart.line == SelectionEnd.line && SelectionStart.col < SelectionEnd.col))
        {
            return SelectionEnd;
        }
        return SelectionStart;
    }
}
```

**Step 2: Build to verify**

Run: `dotnet build .worktrees/multi-platform/Basic10.GameMod/Basic10.GameMod.csproj`
Expected: Build succeeded

**Step 3: Commit**

```bash
git add .worktrees/multi-platform/Basic10.GameMod/Editor/TextBuffer.cs
git commit -m "feat(gamemod): add TextBuffer for cursor and selection management"
```

---

### Task 2.2: Add Undo/Redo Support to TextBuffer

**Files:**
- Modify: `.worktrees/multi-platform/Basic10.GameMod/Editor/TextBuffer.cs`

**Step 1: Add undo/redo stack**

Add these fields and methods to the TextBuffer class:

```csharp
// Undo/Redo stacks
private readonly Stack<TextSnapshot> _undoStack = new();
private readonly Stack<TextSnapshot> _redoStack = new();
private const int MaxUndoLevels = 100;

private class TextSnapshot
{
    public List<string> Lines { get; }
    public int CursorLine { get; }
    public int CursorColumn { get; }

    public TextSnapshot(List<string> lines, int cursorLine, int cursorColumn)
    {
        Lines = new List<string>(lines);
        CursorLine = cursorLine;
        CursorColumn = cursorColumn;
    }
}

/// <summary>
/// Save current state for undo. Call before making changes.
/// </summary>
public void SaveUndoState()
{
    _undoStack.Push(new TextSnapshot(_lines, CursorLine, CursorColumn));
    if (_undoStack.Count > MaxUndoLevels)
    {
        // Remove oldest - convert to array, skip first, rebuild
        var arr = _undoStack.ToArray();
        _undoStack.Clear();
        for (int i = arr.Length - MaxUndoLevels; i < arr.Length; i++)
        {
            _undoStack.Push(arr[i]);
        }
    }
    _redoStack.Clear();
}

/// <summary>
/// Undo the last change.
/// </summary>
public bool Undo()
{
    if (_undoStack.Count == 0) return false;

    // Save current state for redo
    _redoStack.Push(new TextSnapshot(_lines, CursorLine, CursorColumn));

    // Restore previous state
    var snapshot = _undoStack.Pop();
    _lines.Clear();
    _lines.AddRange(snapshot.Lines);
    CursorLine = snapshot.CursorLine;
    CursorColumn = snapshot.CursorColumn;
    ClearSelection();

    return true;
}

/// <summary>
/// Redo the last undone change.
/// </summary>
public bool Redo()
{
    if (_redoStack.Count == 0) return false;

    // Save current state for undo
    _undoStack.Push(new TextSnapshot(_lines, CursorLine, CursorColumn));

    // Restore redo state
    var snapshot = _redoStack.Pop();
    _lines.Clear();
    _lines.AddRange(snapshot.Lines);
    CursorLine = snapshot.CursorLine;
    CursorColumn = snapshot.CursorColumn;
    ClearSelection();

    return true;
}

public bool CanUndo => _undoStack.Count > 0;
public bool CanRedo => _redoStack.Count > 0;
```

**Step 2: Build to verify**

Run: `dotnet build .worktrees/multi-platform/Basic10.GameMod/Basic10.GameMod.csproj`
Expected: Build succeeded

**Step 3: Commit**

```bash
git add .worktrees/multi-platform/Basic10.GameMod/Editor/TextBuffer.cs
git commit -m "feat(gamemod): add undo/redo support to TextBuffer"
```

---

## Phase 3: Custom Text Rendering

### Task 3.1: Create TextRenderer for Line-Based Display

**Files:**
- Create: `.worktrees/multi-platform/Basic10.GameMod/Editor/TextRenderer.cs`

**Step 1: Create TextRenderer class**

```csharp
using UnityEngine;
using System.Collections.Generic;

namespace Basic10.GameMod.Editor;

/// <summary>
/// Renders text content with line numbers, scrolling, and cursor.
/// </summary>
public class TextRenderer
{
    // Styling
    private GUIStyle? _codeStyle;
    private GUIStyle? _lineNumberStyle;
    private GUIStyle? _cursorStyle;

    // Layout metrics
    private float _lineHeight = 18f;
    private float _charWidth = 8f;
    private float _lineNumberWidth = 50f;

    // Scroll state
    private Vector2 _scrollPosition;
    private int _visibleLineStart;
    private int _visibleLineCount;

    /// <summary>
    /// Initialize GUI styles. Must be called from OnGUI context.
    /// </summary>
    public void InitStyles()
    {
        if (_codeStyle != null) return;

        _codeStyle = new GUIStyle(GUI.skin.label)
        {
            font = Font.CreateDynamicFontFromOSFont("Consolas", 14),
            fontSize = 14,
            normal = { textColor = new Color(0.9f, 0.9f, 0.9f) },
            wordWrap = false,
            clipping = TextClipping.Clip,
            richText = true
        };

        // Calculate char width using a sample character
        var sampleContent = new GUIContent("M");
        _charWidth = _codeStyle.CalcSize(sampleContent).x;
        _lineHeight = _codeStyle.lineHeight + 2;

        _lineNumberStyle = new GUIStyle(_codeStyle)
        {
            alignment = TextAnchor.MiddleRight,
            normal = { textColor = new Color(0.5f, 0.5f, 0.5f) },
            padding = new RectOffset(0, 8, 0, 0)
        };

        _cursorStyle = new GUIStyle
        {
            normal = { background = MakeSolidTexture(new Color(1f, 1f, 1f, 0.8f)) }
        };
    }

    /// <summary>
    /// Render the text buffer in the given area.
    /// </summary>
    public void Render(Rect area, TextBuffer buffer)
    {
        InitStyles();

        var lineCount = buffer.LineCount;

        // Calculate visible lines
        _visibleLineCount = Mathf.CeilToInt(area.height / _lineHeight) + 1;
        _visibleLineStart = Mathf.FloorToInt(_scrollPosition.y / _lineHeight);
        _visibleLineStart = Mathf.Clamp(_visibleLineStart, 0, Mathf.Max(0, lineCount - 1));

        // Calculate total content height
        var contentHeight = lineCount * _lineHeight;
        var contentWidth = CalculateMaxLineWidth(buffer) + _lineNumberWidth + 50;

        // Begin scroll view
        var scrollRect = new Rect(0, 0, contentWidth, contentHeight);
        _scrollPosition = GUI.BeginScrollView(area, _scrollPosition, scrollRect, true, true);

        // Render visible lines
        for (int i = _visibleLineStart; i < lineCount && i < _visibleLineStart + _visibleLineCount; i++)
        {
            RenderLine(i, buffer);
        }

        // Render cursor
        RenderCursor(buffer);

        GUI.EndScrollView();
    }

    private void RenderLine(int lineIndex, TextBuffer buffer)
    {
        var y = lineIndex * _lineHeight;
        var lineText = buffer.GetLine(lineIndex);

        // Line number
        var lineNumRect = new Rect(0, y, _lineNumberWidth, _lineHeight);
        GUI.Label(lineNumRect, (lineIndex + 1).ToString(), _lineNumberStyle);

        // Code content
        var codeRect = new Rect(_lineNumberWidth, y, 10000, _lineHeight);
        GUI.Label(codeRect, lineText, _codeStyle);
    }

    private void RenderCursor(TextBuffer buffer)
    {
        var cursorX = _lineNumberWidth + (buffer.CursorColumn * _charWidth);
        var cursorY = buffer.CursorLine * _lineHeight;

        // Blinking cursor (every 0.5 seconds)
        if (Mathf.FloorToInt(Time.unscaledTime * 2) % 2 == 0)
        {
            var cursorRect = new Rect(cursorX, cursorY + 2, 2, _lineHeight - 4);
            GUI.Box(cursorRect, GUIContent.none, _cursorStyle);
        }
    }

    private float CalculateMaxLineWidth(TextBuffer buffer)
    {
        float maxWidth = 200; // Minimum width
        for (int i = 0; i < buffer.LineCount; i++)
        {
            var lineWidth = buffer.GetLine(i).Length * _charWidth;
            if (lineWidth > maxWidth) maxWidth = lineWidth;
        }
        return maxWidth;
    }

    /// <summary>
    /// Convert screen position to text position.
    /// </summary>
    public (int line, int col) ScreenToText(Vector2 screenPos, Rect area, TextBuffer buffer)
    {
        var localPos = screenPos - new Vector2(area.x, area.y) + _scrollPosition;

        var line = Mathf.FloorToInt(localPos.y / _lineHeight);
        line = Mathf.Clamp(line, 0, buffer.LineCount - 1);

        var col = Mathf.RoundToInt((localPos.x - _lineNumberWidth) / _charWidth);
        col = Mathf.Clamp(col, 0, buffer.GetLine(line).Length);

        return (line, col);
    }

    /// <summary>
    /// Ensure cursor is visible in scroll view.
    /// </summary>
    public void EnsureCursorVisible(Rect area, TextBuffer buffer)
    {
        var cursorY = buffer.CursorLine * _lineHeight;

        // Vertical scroll
        if (cursorY < _scrollPosition.y)
        {
            _scrollPosition.y = cursorY;
        }
        else if (cursorY + _lineHeight > _scrollPosition.y + area.height)
        {
            _scrollPosition.y = cursorY + _lineHeight - area.height;
        }

        // Horizontal scroll
        var cursorX = _lineNumberWidth + (buffer.CursorColumn * _charWidth);
        if (cursorX < _scrollPosition.x + _lineNumberWidth)
        {
            _scrollPosition.x = Mathf.Max(0, cursorX - _lineNumberWidth - 50);
        }
        else if (cursorX > _scrollPosition.x + area.width - 50)
        {
            _scrollPosition.x = cursorX - area.width + 100;
        }
    }

    private static Texture2D MakeSolidTexture(Color color)
    {
        var tex = new Texture2D(1, 1);
        tex.SetPixel(0, 0, color);
        tex.Apply();
        return tex;
    }
}
```

**Step 2: Build to verify**

Run: `dotnet build .worktrees/multi-platform/Basic10.GameMod/Basic10.GameMod.csproj`
Expected: Build succeeded

**Step 3: Commit**

```bash
git add .worktrees/multi-platform/Basic10.GameMod/Editor/TextRenderer.cs
git commit -m "feat(gamemod): add TextRenderer for line-based display with cursor"
```

---

### Task 3.2: Integrate TextBuffer and TextRenderer into EditorWindow

**Files:**
- Modify: `.worktrees/multi-platform/Basic10.GameMod/Editor/EditorWindow.cs`

**Step 1: Replace TextArea with custom rendering**

Update the EditorWindow class to use TextBuffer and TextRenderer:

```csharp
// Add these fields at the top of the class
private readonly TextBuffer _buffer = new();
private readonly TextRenderer _renderer = new();
private bool _hasFocus;

// Update the Show method
public static void Show(string initialCode, object targetChip,
    System.Action<string> onSave, System.Action onCancel)
{
    EnsureInstance();
    _instance!._buffer.SetAllText(initialCode ?? "");
    _instance._targetChip = targetChip;
    _instance._onSave = onSave;
    _instance._onCancel = onCancel;
    _instance._isVisible = true;
    _instance._hasFocus = true;

    Basic10Plugin.Log.LogInfo("Basic-10 Editor opened");
}

// Replace the DrawWindow method body with:
private void DrawWindow(int windowId)
{
    // Toolbar
    GUILayout.BeginHorizontal();
    if (GUILayout.Button("Save", GUILayout.Width(80)))
    {
        HandleSave();
    }
    if (GUILayout.Button("Compile", GUILayout.Width(80)))
    {
        HandleCompile();
    }
    GUILayout.FlexibleSpace();
    if (GUILayout.Button("Cancel", GUILayout.Width(80)))
    {
        HandleCancel();
    }
    GUILayout.EndHorizontal();

    GUILayout.Space(5);

    // Main editor area
    var editorRect = GUILayoutUtility.GetRect(
        _windowRect.width - 20,
        _windowRect.height - 100,
        GUILayout.ExpandWidth(true),
        GUILayout.ExpandHeight(true)
    );

    // Handle input
    if (_hasFocus)
    {
        HandleKeyboardInput();
        HandleMouseInput(editorRect);
    }

    // Render content
    _renderer.Render(editorRect, _buffer);

    // Status bar
    GUILayout.BeginHorizontal();
    GUILayout.Label($"Line {_buffer.CursorLine + 1}, Col {_buffer.CursorColumn + 1}");
    GUILayout.FlexibleSpace();
    GUILayout.Label($"Lines: {_buffer.LineCount}");
    GUILayout.FlexibleSpace();
    GUILayout.Label($"Size: {_buffer.GetAllText().Length} chars");
    GUILayout.EndHorizontal();

    // Make window draggable by title bar
    GUI.DragWindow(new Rect(0, 0, _windowRect.width, 25));

    // Track focus
    if (Event.current.type == EventType.MouseDown && editorRect.Contains(Event.current.mousePosition))
    {
        _hasFocus = true;
    }
}

// Update HandleSave to use buffer
private void HandleSave()
{
    _onSave?.Invoke(_buffer.GetAllText());
    _isVisible = false;
    Basic10Plugin.Log.LogInfo("Basic-10 Editor: Save requested");
}
```

**Step 2: Build to verify**

Run: `dotnet build .worktrees/multi-platform/Basic10.GameMod/Basic10.GameMod.csproj`
Expected: Build succeeded

**Step 3: Commit**

```bash
git add .worktrees/multi-platform/Basic10.GameMod/Editor/EditorWindow.cs
git commit -m "feat(gamemod): integrate TextBuffer and TextRenderer into editor window"
```

---

## Phase 4: Keyboard Input Handling

### Task 4.1: Add Keyboard Input Handler

**Files:**
- Create: `.worktrees/multi-platform/Basic10.GameMod/Editor/InputHandler.cs`

**Step 1: Create InputHandler class**

```csharp
using UnityEngine;

namespace Basic10.GameMod.Editor;

/// <summary>
/// Handles keyboard and mouse input for the text editor.
/// </summary>
public class InputHandler
{
    private readonly TextBuffer _buffer;
    private readonly TextRenderer _renderer;

    public InputHandler(TextBuffer buffer, TextRenderer renderer)
    {
        _buffer = buffer;
        _renderer = renderer;
    }

    /// <summary>
    /// Process keyboard events. Call from OnGUI.
    /// </summary>
    public void HandleKeyboard(Rect editorArea)
    {
        var evt = Event.current;
        if (evt.type != EventType.KeyDown) return;

        bool ctrl = evt.control || evt.command;
        bool shift = evt.shift;

        switch (evt.keyCode)
        {
            // Navigation
            case KeyCode.LeftArrow:
                if (ctrl)
                    MoveWordLeft(shift);
                else
                    _buffer.MoveCursor(0, -1, shift);
                evt.Use();
                break;

            case KeyCode.RightArrow:
                if (ctrl)
                    MoveWordRight(shift);
                else
                    _buffer.MoveCursor(0, 1, shift);
                evt.Use();
                break;

            case KeyCode.UpArrow:
                _buffer.MoveCursor(-1, 0, shift);
                evt.Use();
                break;

            case KeyCode.DownArrow:
                _buffer.MoveCursor(1, 0, shift);
                evt.Use();
                break;

            case KeyCode.Home:
                if (ctrl)
                    _buffer.MoveToDocumentStart(shift);
                else
                    _buffer.MoveToLineStart(shift);
                evt.Use();
                break;

            case KeyCode.End:
                if (ctrl)
                    _buffer.MoveToDocumentEnd(shift);
                else
                    _buffer.MoveToLineEnd(shift);
                evt.Use();
                break;

            case KeyCode.PageUp:
                _buffer.MoveCursor(-20, 0, shift);
                evt.Use();
                break;

            case KeyCode.PageDown:
                _buffer.MoveCursor(20, 0, shift);
                evt.Use();
                break;

            // Editing
            case KeyCode.Backspace:
                _buffer.SaveUndoState();
                _buffer.Backspace();
                evt.Use();
                break;

            case KeyCode.Delete:
                _buffer.SaveUndoState();
                _buffer.Delete();
                evt.Use();
                break;

            case KeyCode.Return:
            case KeyCode.KeypadEnter:
                _buffer.SaveUndoState();
                InsertNewlineWithIndent();
                evt.Use();
                break;

            case KeyCode.Tab:
                _buffer.SaveUndoState();
                if (shift)
                    Unindent();
                else
                    Indent();
                evt.Use();
                break;

            // Shortcuts
            case KeyCode.A:
                if (ctrl)
                {
                    _buffer.SelectAll();
                    evt.Use();
                }
                break;

            case KeyCode.C:
                if (ctrl)
                {
                    CopyToClipboard();
                    evt.Use();
                }
                break;

            case KeyCode.X:
                if (ctrl)
                {
                    _buffer.SaveUndoState();
                    CutToClipboard();
                    evt.Use();
                }
                break;

            case KeyCode.V:
                if (ctrl)
                {
                    _buffer.SaveUndoState();
                    PasteFromClipboard();
                    evt.Use();
                }
                break;

            case KeyCode.Z:
                if (ctrl)
                {
                    if (shift)
                        _buffer.Redo();
                    else
                        _buffer.Undo();
                    evt.Use();
                }
                break;

            case KeyCode.Y:
                if (ctrl)
                {
                    _buffer.Redo();
                    evt.Use();
                }
                break;
        }

        // Handle text input
        if (evt.type == EventType.KeyDown && evt.character != '\0' && !ctrl)
        {
            if (evt.character >= 32 || evt.character == '\t')
            {
                _buffer.SaveUndoState();
                _buffer.InsertChar(evt.character);
                evt.Use();
            }
        }

        // Ensure cursor is visible after navigation
        _renderer.EnsureCursorVisible(editorArea, _buffer);
    }

    /// <summary>
    /// Process mouse events. Call from OnGUI.
    /// </summary>
    public void HandleMouse(Rect editorArea)
    {
        var evt = Event.current;

        if (!editorArea.Contains(evt.mousePosition)) return;

        if (evt.type == EventType.MouseDown && evt.button == 0)
        {
            var (line, col) = _renderer.ScreenToText(evt.mousePosition, editorArea, _buffer);
            _buffer.SetCursor(line, col, evt.shift);
            evt.Use();
        }
        else if (evt.type == EventType.MouseDrag && evt.button == 0)
        {
            var (line, col) = _renderer.ScreenToText(evt.mousePosition, editorArea, _buffer);
            _buffer.SetCursor(line, col, true);
            evt.Use();
        }
    }

    private void MoveWordLeft(bool extend)
    {
        var line = _buffer.GetLine(_buffer.CursorLine);
        var col = _buffer.CursorColumn;

        // Skip whitespace
        while (col > 0 && char.IsWhiteSpace(line[col - 1]))
            col--;

        // Skip word characters
        while (col > 0 && !char.IsWhiteSpace(line[col - 1]))
            col--;

        _buffer.SetCursor(_buffer.CursorLine, col, extend);
    }

    private void MoveWordRight(bool extend)
    {
        var line = _buffer.GetLine(_buffer.CursorLine);
        var col = _buffer.CursorColumn;

        // Skip word characters
        while (col < line.Length && !char.IsWhiteSpace(line[col]))
            col++;

        // Skip whitespace
        while (col < line.Length && char.IsWhiteSpace(line[col]))
            col++;

        _buffer.SetCursor(_buffer.CursorLine, col, extend);
    }

    private void InsertNewlineWithIndent()
    {
        // Get current line's indentation
        var currentLine = _buffer.GetLine(_buffer.CursorLine);
        var indent = "";
        foreach (var c in currentLine)
        {
            if (c == ' ' || c == '\t')
                indent += c;
            else
                break;
        }

        _buffer.InsertChar('\n');
        _buffer.InsertText(indent);
    }

    private void Indent()
    {
        if (_buffer.HasSelection)
        {
            // TODO: Indent multiple lines
            _buffer.InsertText("    ");
        }
        else
        {
            _buffer.InsertText("    ");
        }
    }

    private void Unindent()
    {
        var line = _buffer.GetLine(_buffer.CursorLine);
        if (line.StartsWith("    "))
        {
            _buffer.MoveToLineStart();
            for (int i = 0; i < 4; i++)
                _buffer.Delete();
        }
        else if (line.StartsWith("\t"))
        {
            _buffer.MoveToLineStart();
            _buffer.Delete();
        }
    }

    private void CopyToClipboard()
    {
        var text = _buffer.GetSelectedText();
        if (!string.IsNullOrEmpty(text))
        {
            GUIUtility.systemCopyBuffer = text;
        }
    }

    private void CutToClipboard()
    {
        CopyToClipboard();
        _buffer.Delete(); // Delete selection
    }

    private void PasteFromClipboard()
    {
        var text = GUIUtility.systemCopyBuffer;
        if (!string.IsNullOrEmpty(text))
        {
            _buffer.InsertText(text);
        }
    }
}
```

**Step 2: Build to verify**

Run: `dotnet build .worktrees/multi-platform/Basic10.GameMod/Basic10.GameMod.csproj`
Expected: Build succeeded

**Step 3: Commit**

```bash
git add .worktrees/multi-platform/Basic10.GameMod/Editor/InputHandler.cs
git commit -m "feat(gamemod): add InputHandler for keyboard and mouse input"
```

---

### Task 4.2: Wire InputHandler into EditorWindow

**Files:**
- Modify: `.worktrees/multi-platform/Basic10.GameMod/Editor/EditorWindow.cs`

**Step 1: Add InputHandler field and wire up**

Add field:
```csharp
private InputHandler? _inputHandler;
```

Update EnsureInstance or Show to initialize:
```csharp
// In Show method, after EnsureInstance():
_instance!._inputHandler ??= new InputHandler(_instance._buffer, _instance._renderer);
```

Replace HandleKeyboardInput and HandleMouseInput calls with:
```csharp
// In DrawWindow, replace the input handling section:
if (_hasFocus)
{
    _inputHandler?.HandleKeyboard(editorRect);
    _inputHandler?.HandleMouse(editorRect);
}
```

Remove the old HandleKeyboardInput and HandleMouseInput placeholder methods.

**Step 2: Build to verify**

Run: `dotnet build .worktrees/multi-platform/Basic10.GameMod/Basic10.GameMod.csproj`
Expected: Build succeeded

**Step 3: Commit**

```bash
git add .worktrees/multi-platform/Basic10.GameMod/Editor/EditorWindow.cs
git commit -m "feat(gamemod): wire InputHandler into EditorWindow"
```

---

## Phase 5: Syntax Highlighting

### Task 5.1: Create SyntaxHighlighter Using Lexer

**Files:**
- Create: `.worktrees/multi-platform/Basic10.GameMod/Editor/SyntaxHighlighter.cs`

**Step 1: Create SyntaxHighlighter class**

```csharp
using System.Collections.Generic;
using System.Text;
using Basic10.Core.Lexer;
using UnityEngine;

namespace Basic10.GameMod.Editor;

/// <summary>
/// Provides syntax highlighting for BASIC code using the compiler's lexer.
/// Returns rich text for Unity IMGUI rendering.
/// </summary>
public class SyntaxHighlighter
{
    // Color scheme (can be made configurable via BepInEx config)
    private readonly Dictionary<TokenCategory, Color> _colors = new()
    {
        { TokenCategory.Keyword, new Color(0.6f, 0.8f, 1f) },      // Light blue
        { TokenCategory.Identifier, new Color(0.9f, 0.9f, 0.9f) }, // White
        { TokenCategory.Number, new Color(0.7f, 0.9f, 0.7f) },     // Light green
        { TokenCategory.String, new Color(0.9f, 0.7f, 0.5f) },     // Orange
        { TokenCategory.Comment, new Color(0.5f, 0.6f, 0.5f) },    // Gray-green
        { TokenCategory.Operator, new Color(0.9f, 0.9f, 0.7f) },   // Yellow-white
        { TokenCategory.Property, new Color(0.8f, 0.7f, 0.9f) },   // Light purple
        { TokenCategory.Label, new Color(1f, 0.8f, 0.5f) },        // Gold
        { TokenCategory.Default, new Color(0.9f, 0.9f, 0.9f) }     // White
    };

    private enum TokenCategory
    {
        Keyword,
        Identifier,
        Number,
        String,
        Comment,
        Operator,
        Property,
        Label,
        Default
    }

    /// <summary>
    /// Highlight a single line of BASIC code.
    /// Returns rich text with color tags.
    /// </summary>
    public string HighlightLine(string line)
    {
        if (string.IsNullOrEmpty(line)) return line;

        try
        {
            var lexer = new Lexer(line);
            var tokens = lexer.Tokenize();

            var sb = new StringBuilder();
            int lastPos = 0;

            foreach (var token in tokens)
            {
                if (token.Type == TokenType.Eof || token.Type == TokenType.Newline)
                    break;

                // Add any whitespace/content before this token
                if (token.Column > lastPos + 1)
                {
                    sb.Append(line.Substring(lastPos, token.Column - 1 - lastPos));
                }

                // Add colored token
                var category = CategorizeToken(token.Type);
                var color = _colors[category];
                var colorHex = ColorUtility.ToHtmlStringRGB(color);

                sb.Append($"<color=#{colorHex}>");
                sb.Append(EscapeRichText(token.Value ?? line.Substring(token.Column - 1, token.Length)));
                sb.Append("</color>");

                lastPos = token.Column - 1 + token.Length;
            }

            // Add any remaining content
            if (lastPos < line.Length)
            {
                sb.Append(line.Substring(lastPos));
            }

            return sb.ToString();
        }
        catch
        {
            // If lexing fails, return unhighlighted text
            return EscapeRichText(line);
        }
    }

    private TokenCategory CategorizeToken(TokenType type)
    {
        return type switch
        {
            // Keywords
            TokenType.If or TokenType.Then or TokenType.Else or TokenType.ElseIf or
            TokenType.EndIf or TokenType.For or TokenType.To or TokenType.Step or
            TokenType.Next or TokenType.While or TokenType.Wend or TokenType.Do or
            TokenType.Loop or TokenType.Until or TokenType.Goto or TokenType.Gosub or
            TokenType.Return or TokenType.End or TokenType.Sub or TokenType.EndSub or
            TokenType.Function or TokenType.EndFunction or TokenType.Dim or TokenType.Var or
            TokenType.Const or TokenType.Alias or TokenType.Device or TokenType.Define or
            TokenType.Select or TokenType.Case or TokenType.Default or TokenType.EndSelect or
            TokenType.Exit or TokenType.Break or TokenType.Continue or TokenType.Sleep or
            TokenType.Yield or TokenType.Let or TokenType.Print or TokenType.Input or
            TokenType.Call or TokenType.On or TokenType.Push or TokenType.Pop or TokenType.Peek
                => TokenCategory.Keyword,

            // Boolean/Logic keywords
            TokenType.And or TokenType.Or or TokenType.Not or TokenType.True or TokenType.False or
            TokenType.BitAnd or TokenType.BitOr or TokenType.BitXor or TokenType.BitNot or
            TokenType.Shl or TokenType.Shr or TokenType.Mod
                => TokenCategory.Keyword,

            // Numbers
            TokenType.Number => TokenCategory.Number,

            // Strings
            TokenType.String => TokenCategory.String,

            // Comments
            TokenType.Comment or TokenType.Rem or TokenType.MetaComment => TokenCategory.Comment,

            // Operators
            TokenType.Plus or TokenType.Minus or TokenType.Multiply or TokenType.Divide or
            TokenType.Power or TokenType.Equal or TokenType.NotEqual or TokenType.LessThan or
            TokenType.GreaterThan or TokenType.LessEqual or TokenType.GreaterEqual or
            TokenType.Ampersand or TokenType.Pipe or TokenType.Caret or TokenType.Tilde or
            TokenType.ShiftLeft or TokenType.ShiftRight or TokenType.Increment or TokenType.Decrement or
            TokenType.PlusEqual or TokenType.MinusEqual or TokenType.MultiplyEqual or TokenType.DivideEqual
                => TokenCategory.Operator,

            // Hash function (device lookup)
            TokenType.Hash => TokenCategory.Property,

            // Identifiers
            TokenType.Identifier => TokenCategory.Identifier,

            _ => TokenCategory.Default
        };
    }

    private static string EscapeRichText(string text)
    {
        return text
            .Replace("&", "&amp;")
            .Replace("<", "&lt;")
            .Replace(">", "&gt;");
    }
}
```

**Step 2: Build to verify**

Run: `dotnet build .worktrees/multi-platform/Basic10.GameMod/Basic10.GameMod.csproj`
Expected: Build succeeded

**Step 3: Commit**

```bash
git add .worktrees/multi-platform/Basic10.GameMod/Editor/SyntaxHighlighter.cs
git commit -m "feat(gamemod): add SyntaxHighlighter using compiler lexer"
```

---

### Task 5.2: Integrate SyntaxHighlighter into TextRenderer

**Files:**
- Modify: `.worktrees/multi-platform/Basic10.GameMod/Editor/TextRenderer.cs`

**Step 1: Add highlighter field and update RenderLine**

Add field:
```csharp
private readonly SyntaxHighlighter _highlighter = new();
```

Update RenderLine method:
```csharp
private void RenderLine(int lineIndex, TextBuffer buffer)
{
    var y = lineIndex * _lineHeight;
    var lineText = buffer.GetLine(lineIndex);

    // Line number
    var lineNumRect = new Rect(0, y, _lineNumberWidth, _lineHeight);
    GUI.Label(lineNumRect, (lineIndex + 1).ToString(), _lineNumberStyle);

    // Code content with syntax highlighting
    var highlightedText = _highlighter.HighlightLine(lineText);
    var codeRect = new Rect(_lineNumberWidth, y, 10000, _lineHeight);
    GUI.Label(codeRect, highlightedText, _codeStyle);
}
```

**Step 2: Build to verify**

Run: `dotnet build .worktrees/multi-platform/Basic10.GameMod/Basic10.GameMod.csproj`
Expected: Build succeeded

**Step 3: Commit**

```bash
git add .worktrees/multi-platform/Basic10.GameMod/Editor/TextRenderer.cs
git commit -m "feat(gamemod): integrate syntax highlighting into text renderer"
```

---

## Phase 6: Script File I/O

### Task 6.1: Create ScriptStorage for .bas Files

**Files:**
- Create: `.worktrees/multi-platform/Basic10.GameMod/Editor/ScriptStorage.cs`

**Step 1: Create ScriptStorage class**

```csharp
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;

namespace Basic10.GameMod.Editor;

/// <summary>
/// Handles reading and writing BASIC scripts to the Stationeers scripts folder.
/// Each script is stored as a folder containing source.bas and instruction.xml.
/// </summary>
public static class ScriptStorage
{
    private static string? _scriptsPath;

    /// <summary>
    /// Get the path to the Stationeers scripts folder.
    /// </summary>
    public static string ScriptsPath
    {
        get
        {
            if (_scriptsPath == null)
            {
                var myDocs = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                _scriptsPath = Path.Combine(myDocs, "My Games", "Stationeers", "scripts");

                // Ensure directory exists
                if (!Directory.Exists(_scriptsPath))
                {
                    Directory.CreateDirectory(_scriptsPath);
                }
            }
            return _scriptsPath;
        }
    }

    /// <summary>
    /// List all script names in the scripts folder.
    /// </summary>
    public static List<string> ListScripts()
    {
        var scripts = new List<string>();

        try
        {
            var dirs = Directory.GetDirectories(ScriptsPath);
            foreach (var dir in dirs)
            {
                var name = Path.GetFileName(dir);
                // Check if it has either source.bas or instruction.xml
                if (File.Exists(Path.Combine(dir, "source.bas")) ||
                    File.Exists(Path.Combine(dir, "instruction.xml")))
                {
                    scripts.Add(name);
                }
            }
        }
        catch (Exception ex)
        {
            Basic10Plugin.Log.LogWarning($"Failed to list scripts: {ex.Message}");
        }

        return scripts.OrderBy(s => s).ToList();
    }

    /// <summary>
    /// Load a script's source code. Returns BASIC source if available, otherwise IC10.
    /// </summary>
    public static (string code, bool isBasic) LoadScript(string scriptName)
    {
        var scriptDir = Path.Combine(ScriptsPath, scriptName);

        // Try BASIC source first
        var basPath = Path.Combine(scriptDir, "source.bas");
        if (File.Exists(basPath))
        {
            var basicCode = File.ReadAllText(basPath);
            Basic10Plugin.Log.LogInfo($"Loaded BASIC source: {scriptName}");
            return (basicCode, true);
        }

        // Fall back to IC10 from instruction.xml
        var xmlPath = Path.Combine(scriptDir, "instruction.xml");
        if (File.Exists(xmlPath))
        {
            try
            {
                var doc = XDocument.Load(xmlPath);
                var ic10Code = doc.Root?.Element("Code")?.Value ?? "";
                Basic10Plugin.Log.LogInfo($"Loaded IC10 from XML: {scriptName}");
                return (ic10Code, false);
            }
            catch (Exception ex)
            {
                Basic10Plugin.Log.LogWarning($"Failed to parse XML: {ex.Message}");
            }
        }

        return ("", false);
    }

    /// <summary>
    /// Save a script. Saves BASIC source to source.bas and compiles to instruction.xml.
    /// </summary>
    public static bool SaveScript(string scriptName, string basicSource, string ic10Code)
    {
        try
        {
            var scriptDir = Path.Combine(ScriptsPath, scriptName);
            Directory.CreateDirectory(scriptDir);

            // Save BASIC source
            var basPath = Path.Combine(scriptDir, "source.bas");
            File.WriteAllText(basPath, basicSource);

            // Save IC10 as instruction.xml
            var xmlPath = Path.Combine(scriptDir, "instruction.xml");
            var doc = new XDocument(
                new XElement("Script",
                    new XElement("Name", scriptName),
                    new XElement("Description", $"Basic-10 script: {scriptName}"),
                    new XElement("Author", "Basic-10"),
                    new XElement("Code", ic10Code)
                )
            );
            doc.Save(xmlPath);

            Basic10Plugin.Log.LogInfo($"Saved script: {scriptName}");
            return true;
        }
        catch (Exception ex)
        {
            Basic10Plugin.Log.LogError($"Failed to save script: {ex}");
            return false;
        }
    }

    /// <summary>
    /// Delete a script folder.
    /// </summary>
    public static bool DeleteScript(string scriptName)
    {
        try
        {
            var scriptDir = Path.Combine(ScriptsPath, scriptName);
            if (Directory.Exists(scriptDir))
            {
                Directory.Delete(scriptDir, true);
                Basic10Plugin.Log.LogInfo($"Deleted script: {scriptName}");
                return true;
            }
        }
        catch (Exception ex)
        {
            Basic10Plugin.Log.LogError($"Failed to delete script: {ex}");
        }
        return false;
    }
}
```

**Step 2: Build to verify**

Run: `dotnet build .worktrees/multi-platform/Basic10.GameMod/Basic10.GameMod.csproj`
Expected: Build succeeded

**Step 3: Commit**

```bash
git add .worktrees/multi-platform/Basic10.GameMod/Editor/ScriptStorage.cs
git commit -m "feat(gamemod): add ScriptStorage for .bas file I/O"
```

---

## Phase 7: Toolbar Actions

### Task 7.1: Implement Compile Preview

**Files:**
- Modify: `.worktrees/multi-platform/Basic10.GameMod/Editor/EditorWindow.cs`

**Step 1: Add compilation result state and preview**

Add these fields:
```csharp
private Basic10.Core.CompilationResult? _lastCompileResult;
private string _statusMessage = "";
private Color _statusColor = Color.white;
```

Update HandleCompile method:
```csharp
private void HandleCompile()
{
    try
    {
        var compiler = new Basic10.Core.Basic10Compiler();
        _lastCompileResult = compiler.Compile(_buffer.GetAllText());

        if (_lastCompileResult.Success)
        {
            _statusMessage = $"Compiled: {_lastCompileResult.LineCount} IC10 lines";
            _statusColor = new Color(0.5f, 1f, 0.5f); // Green
        }
        else
        {
            var errorCount = _lastCompileResult.Errors.Count(e =>
                e.Severity == Basic10.Core.CompilerErrorSeverity.Error);
            _statusMessage = $"Errors: {errorCount}";
            _statusColor = new Color(1f, 0.5f, 0.5f); // Red
        }

        Basic10Plugin.Log.LogInfo($"Compile preview: {_statusMessage}");
    }
    catch (Exception ex)
    {
        _statusMessage = $"Compile failed: {ex.Message}";
        _statusColor = new Color(1f, 0.5f, 0.5f);
        Basic10Plugin.Log.LogError($"Compile failed: {ex}");
    }
}
```

Update status bar in DrawWindow to show compilation status:
```csharp
// Status bar
GUILayout.BeginHorizontal();
GUILayout.Label($"Line {_buffer.CursorLine + 1}, Col {_buffer.CursorColumn + 1}");
GUILayout.FlexibleSpace();
GUILayout.Label($"Lines: {_buffer.LineCount}");
GUILayout.FlexibleSpace();

// Show status message with color
var prevColor = GUI.contentColor;
GUI.contentColor = _statusColor;
GUILayout.Label(_statusMessage);
GUI.contentColor = prevColor;

GUILayout.EndHorizontal();
```

**Step 2: Build to verify**

Run: `dotnet build .worktrees/multi-platform/Basic10.GameMod/Basic10.GameMod.csproj`
Expected: Build succeeded

**Step 3: Commit**

```bash
git add .worktrees/multi-platform/Basic10.GameMod/Editor/EditorWindow.cs
git commit -m "feat(gamemod): implement compile preview with status display"
```

---

### Task 7.2: Add Load/New Buttons

**Files:**
- Modify: `.worktrees/multi-platform/Basic10.GameMod/Editor/EditorWindow.cs`

**Step 1: Add load dialog state and toolbar buttons**

Add fields:
```csharp
private bool _showLoadDialog;
private Vector2 _loadDialogScroll;
private List<string> _availableScripts = new();
private string _newScriptName = "";
```

Update toolbar in DrawWindow:
```csharp
// Toolbar
GUILayout.BeginHorizontal();
if (GUILayout.Button("Save", GUILayout.Width(80)))
{
    HandleSave();
}
if (GUILayout.Button("Compile", GUILayout.Width(80)))
{
    HandleCompile();
}
GUILayout.Space(20);
if (GUILayout.Button("Load", GUILayout.Width(80)))
{
    _showLoadDialog = true;
    _availableScripts = ScriptStorage.ListScripts();
}
if (GUILayout.Button("New", GUILayout.Width(80)))
{
    _buffer.SetAllText("");
    _statusMessage = "New script";
    _statusColor = Color.white;
}
GUILayout.FlexibleSpace();
if (GUILayout.Button("Cancel", GUILayout.Width(80)))
{
    HandleCancel();
}
GUILayout.EndHorizontal();
```

Add load dialog drawing after main content:
```csharp
// Load dialog overlay
if (_showLoadDialog)
{
    DrawLoadDialog();
}
```

Add DrawLoadDialog method:
```csharp
private void DrawLoadDialog()
{
    // Semi-transparent overlay
    GUI.Box(new Rect(0, 0, _windowRect.width, _windowRect.height), "");

    // Dialog box
    var dialogRect = new Rect(
        _windowRect.width / 2 - 200,
        _windowRect.height / 2 - 150,
        400, 300
    );

    GUILayout.BeginArea(dialogRect, GUI.skin.box);

    GUILayout.Label("Load Script", GUI.skin.box);
    GUILayout.Space(10);

    _loadDialogScroll = GUILayout.BeginScrollView(_loadDialogScroll, GUILayout.Height(200));

    foreach (var script in _availableScripts)
    {
        if (GUILayout.Button(script, GUILayout.Height(25)))
        {
            LoadScriptByName(script);
            _showLoadDialog = false;
        }
    }

    if (_availableScripts.Count == 0)
    {
        GUILayout.Label("No scripts found");
    }

    GUILayout.EndScrollView();

    GUILayout.Space(10);

    GUILayout.BeginHorizontal();
    GUILayout.FlexibleSpace();
    if (GUILayout.Button("Cancel", GUILayout.Width(100)))
    {
        _showLoadDialog = false;
    }
    GUILayout.EndHorizontal();

    GUILayout.EndArea();
}

private void LoadScriptByName(string scriptName)
{
    var (code, isBasic) = ScriptStorage.LoadScript(scriptName);
    _buffer.SetAllText(code);
    _statusMessage = isBasic ? $"Loaded: {scriptName}" : $"Loaded IC10: {scriptName}";
    _statusColor = Color.white;
}
```

**Step 2: Build to verify**

Run: `dotnet build .worktrees/multi-platform/Basic10.GameMod/Basic10.GameMod.csproj`
Expected: Build succeeded

**Step 3: Commit**

```bash
git add .worktrees/multi-platform/Basic10.GameMod/Editor/EditorWindow.cs
git commit -m "feat(gamemod): add Load and New toolbar buttons with script browser"
```

---

## Phase 8: Problems Panel

### Task 8.1: Create ProblemsPanel Component

**Files:**
- Create: `.worktrees/multi-platform/Basic10.GameMod/Editor/ProblemsPanel.cs`

**Step 1: Create ProblemsPanel class**

```csharp
using System.Collections.Generic;
using Basic10.Core;
using UnityEngine;

namespace Basic10.GameMod.Editor;

/// <summary>
/// Displays compilation errors and warnings with clickable line navigation.
/// </summary>
public class ProblemsPanel
{
    private Vector2 _scrollPosition;
    private GUIStyle? _errorStyle;
    private GUIStyle? _warningStyle;

    /// <summary>
    /// Currently selected line (for navigation)
    /// </summary>
    public int? SelectedLine { get; private set; }

    /// <summary>
    /// Render the problems panel.
    /// </summary>
    public void Render(Rect area, CompilationResult? result)
    {
        InitStyles();

        GUI.Box(area, GUIContent.none);

        GUILayout.BeginArea(area);

        // Header
        GUILayout.BeginHorizontal(GUI.skin.box);
        GUILayout.Label("Problems", GUILayout.Width(100));

        // Metrics
        if (result != null)
        {
            var lineCount = result.LineCount;
            var byteSize = (result.IC10Code?.Length ?? 0);

            // Line count with color
            var lineColor = lineCount > 128 ? Color.red : lineCount > 100 ? Color.yellow : Color.green;
            GUI.contentColor = lineColor;
            GUILayout.Label($"Lines: {lineCount}/128");

            // Byte count with color
            var byteColor = byteSize > 4096 ? Color.red : byteSize > 3500 ? Color.yellow : Color.green;
            GUI.contentColor = byteColor;
            GUILayout.Label($"Size: {byteSize}/4096");

            GUI.contentColor = Color.white;
        }

        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();

        // Error list
        _scrollPosition = GUILayout.BeginScrollView(_scrollPosition);

        if (result != null && result.Errors.Count > 0)
        {
            foreach (var error in result.Errors)
            {
                var style = error.Severity == CompilerErrorSeverity.Error ? _errorStyle : _warningStyle;
                var icon = error.Severity == CompilerErrorSeverity.Error ? "✗" : "⚠";

                GUILayout.BeginHorizontal();

                if (GUILayout.Button($"{icon} Line {error.Line}: {error.Message}", style!))
                {
                    SelectedLine = error.Line;
                }

                GUILayout.EndHorizontal();
            }
        }
        else if (result != null && result.Success)
        {
            GUILayout.Label("✓ No problems", _warningStyle);
        }
        else
        {
            GUILayout.Label("Press Compile to check for problems");
        }

        GUILayout.EndScrollView();
        GUILayout.EndArea();
    }

    /// <summary>
    /// Clear the selected line (after navigation).
    /// </summary>
    public void ClearSelection()
    {
        SelectedLine = null;
    }

    private void InitStyles()
    {
        if (_errorStyle != null) return;

        _errorStyle = new GUIStyle(GUI.skin.button)
        {
            alignment = TextAnchor.MiddleLeft,
            normal = { textColor = new Color(1f, 0.5f, 0.5f) },
            hover = { textColor = new Color(1f, 0.7f, 0.7f) }
        };

        _warningStyle = new GUIStyle(GUI.skin.button)
        {
            alignment = TextAnchor.MiddleLeft,
            normal = { textColor = new Color(1f, 0.9f, 0.5f) },
            hover = { textColor = new Color(1f, 0.95f, 0.7f) }
        };
    }
}
```

**Step 2: Build to verify**

Run: `dotnet build .worktrees/multi-platform/Basic10.GameMod/Basic10.GameMod.csproj`
Expected: Build succeeded

**Step 3: Commit**

```bash
git add .worktrees/multi-platform/Basic10.GameMod/Editor/ProblemsPanel.cs
git commit -m "feat(gamemod): add ProblemsPanel with clickable errors and metrics"
```

---

### Task 8.2: Integrate ProblemsPanel into EditorWindow

**Files:**
- Modify: `.worktrees/multi-platform/Basic10.GameMod/Editor/EditorWindow.cs`

**Step 1: Add ProblemsPanel and adjust layout**

Add field:
```csharp
private readonly ProblemsPanel _problemsPanel = new();
```

Update DrawWindow layout to include problems panel at bottom:
```csharp
private void DrawWindow(int windowId)
{
    // ... toolbar code ...

    GUILayout.Space(5);

    // Calculate areas
    var problemsPanelHeight = 100f;
    var totalHeight = _windowRect.height - 80; // Account for toolbar and padding
    var editorHeight = totalHeight - problemsPanelHeight - 10;

    // Main editor area
    var editorRect = GUILayoutUtility.GetRect(
        _windowRect.width - 20,
        editorHeight,
        GUILayout.ExpandWidth(true)
    );

    // Handle input
    if (_hasFocus)
    {
        _inputHandler?.HandleKeyboard(editorRect);
        _inputHandler?.HandleMouse(editorRect);
    }

    // Render content
    _renderer.Render(editorRect, _buffer);

    GUILayout.Space(5);

    // Problems panel
    var problemsRect = GUILayoutUtility.GetRect(
        _windowRect.width - 20,
        problemsPanelHeight,
        GUILayout.ExpandWidth(true)
    );
    _problemsPanel.Render(problemsRect, _lastCompileResult);

    // Handle error navigation
    if (_problemsPanel.SelectedLine.HasValue)
    {
        _buffer.SetCursor(_problemsPanel.SelectedLine.Value - 1, 0);
        _renderer.EnsureCursorVisible(editorRect, _buffer);
        _problemsPanel.ClearSelection();
    }

    // ... status bar ...
    // ... drag window ...
}
```

**Step 2: Build to verify**

Run: `dotnet build .worktrees/multi-platform/Basic10.GameMod/Basic10.GameMod.csproj`
Expected: Build succeeded

**Step 3: Commit**

```bash
git add .worktrees/multi-platform/Basic10.GameMod/Editor/EditorWindow.cs
git commit -m "feat(gamemod): integrate ProblemsPanel with click-to-navigate"
```

---

## Phase 9: Sidebar Tabs (Basic Implementation)

### Task 9.1: Create Sidebar Container

**Files:**
- Create: `.worktrees/multi-platform/Basic10.GameMod/Editor/Sidebar.cs`

**Step 1: Create Sidebar class with tabs**

```csharp
using System.Collections.Generic;
using UnityEngine;

namespace Basic10.GameMod.Editor;

/// <summary>
/// Tabbed sidebar with Devices, Syntax, and Examples tabs.
/// </summary>
public class Sidebar
{
    private enum Tab { Devices, Syntax, Examples }
    private Tab _activeTab = Tab.Devices;

    private Vector2 _scrollPosition;
    private string _deviceSearch = "";

    // Cached device list from reflector
    private List<ScannedDevice>? _devices;

    /// <summary>
    /// Text to insert into editor (set when user clicks an item)
    /// </summary>
    public string? TextToInsert { get; private set; }

    public void Render(Rect area)
    {
        GUI.Box(area, GUIContent.none);
        GUILayout.BeginArea(area);

        // Tab buttons
        GUILayout.BeginHorizontal();
        if (GUILayout.Toggle(_activeTab == Tab.Devices, "Dev", "Button", GUILayout.Width(50)))
            _activeTab = Tab.Devices;
        if (GUILayout.Toggle(_activeTab == Tab.Syntax, "Syn", "Button", GUILayout.Width(50)))
            _activeTab = Tab.Syntax;
        if (GUILayout.Toggle(_activeTab == Tab.Examples, "Ex", "Button", GUILayout.Width(50)))
            _activeTab = Tab.Examples;
        GUILayout.EndHorizontal();

        GUILayout.Space(5);

        // Tab content
        _scrollPosition = GUILayout.BeginScrollView(_scrollPosition);

        TextToInsert = null; // Clear previous selection

        switch (_activeTab)
        {
            case Tab.Devices:
                RenderDevicesTab();
                break;
            case Tab.Syntax:
                RenderSyntaxTab();
                break;
            case Tab.Examples:
                RenderExamplesTab();
                break;
        }

        GUILayout.EndScrollView();
        GUILayout.EndArea();
    }

    private void RenderDevicesTab()
    {
        // Search box
        GUILayout.BeginHorizontal();
        GUILayout.Label("Search:", GUILayout.Width(50));
        _deviceSearch = GUILayout.TextField(_deviceSearch);
        GUILayout.EndHorizontal();

        GUILayout.Space(5);

        // Device list (placeholder - would use DeviceReflector data)
        var sampleDevices = new[]
        {
            ("Gas Sensor", -1252983604),
            ("Logic Memory", 1076425094),
            ("Solar Panel", -539224550),
            ("Battery Cell", -1024100462),
            ("Air Conditioner", 98765432),
        };

        var search = _deviceSearch.ToLowerInvariant();
        foreach (var (name, hash) in sampleDevices)
        {
            if (!string.IsNullOrEmpty(search) && !name.ToLowerInvariant().Contains(search))
                continue;

            if (GUILayout.Button($"{name}\n{hash}", GUILayout.Height(40)))
            {
                TextToInsert = hash.ToString();
            }
        }
    }

    private void RenderSyntaxTab()
    {
        GUILayout.Label("Keywords", GUI.skin.box);
        var keywords = new[] { "IF", "THEN", "ELSE", "ENDIF", "FOR", "TO", "NEXT",
            "WHILE", "WEND", "ALIAS", "VAR", "CONST", "DEVICE", "GOSUB", "RETURN" };

        foreach (var kw in keywords)
        {
            if (GUILayout.Button(kw, GUILayout.Height(25)))
            {
                TextToInsert = kw + " ";
            }
        }

        GUILayout.Space(10);
        GUILayout.Label("Functions", GUI.skin.box);
        var functions = new[] { "ABS()", "SQRT()", "SIN()", "COS()", "TAN()",
            "MIN(,)", "MAX(,)", "CLAMP(,,)", "HASH(\"\")" };

        foreach (var fn in functions)
        {
            if (GUILayout.Button(fn, GUILayout.Height(25)))
            {
                TextToInsert = fn;
            }
        }
    }

    private void RenderExamplesTab()
    {
        GUILayout.Label("Click to insert example", GUI.skin.box);

        if (GUILayout.Button("Solar Tracker", GUILayout.Height(30)))
        {
            TextToInsert = @"' Solar Tracker
ALIAS solar d0
ALIAS sensor d1

LOOP:
    angle = sensor.Horizontal
    solar.Horizontal = angle
    YIELD
GOTO LOOP
";
        }

        if (GUILayout.Button("Furnace Controller", GUILayout.Height(30)))
        {
            TextToInsert = @"' Furnace Controller
ALIAS furnace d0
ALIAS dial d1

LOOP:
    target = dial.Setting
    furnace.SettingInput = target
    YIELD
GOTO LOOP
";
        }

        if (GUILayout.Button("Airlock", GUILayout.Height(30)))
        {
            TextToInsert = @"' Simple Airlock
ALIAS innerDoor d0
ALIAS outerDoor d1
ALIAS button d2

LOOP:
    IF button.Activate THEN
        innerDoor.Open = 0
        SLEEP 1
        outerDoor.Open = 1
    ENDIF
    YIELD
GOTO LOOP
";
        }
    }
}
```

**Step 2: Build to verify**

Run: `dotnet build .worktrees/multi-platform/Basic10.GameMod/Basic10.GameMod.csproj`
Expected: Build succeeded

**Step 3: Commit**

```bash
git add .worktrees/multi-platform/Basic10.GameMod/Editor/Sidebar.cs
git commit -m "feat(gamemod): add Sidebar with Devices, Syntax, and Examples tabs"
```

---

### Task 9.2: Integrate Sidebar into EditorWindow

**Files:**
- Modify: `.worktrees/multi-platform/Basic10.GameMod/Editor/EditorWindow.cs`

**Step 1: Add sidebar and adjust layout**

Add field:
```csharp
private readonly Sidebar _sidebar = new();
```

Update DrawWindow to include sidebar on right side:
```csharp
private void DrawWindow(int windowId)
{
    // ... toolbar ...

    GUILayout.Space(5);

    // Calculate areas
    var sidebarWidth = 180f;
    var problemsPanelHeight = 100f;
    var totalHeight = _windowRect.height - 80;
    var contentWidth = _windowRect.width - sidebarWidth - 30;
    var editorHeight = totalHeight - problemsPanelHeight - 10;

    GUILayout.BeginHorizontal();

    // Left side: editor + problems
    GUILayout.BeginVertical(GUILayout.Width(contentWidth));

    // Editor
    var editorRect = GUILayoutUtility.GetRect(contentWidth, editorHeight);
    if (_hasFocus)
    {
        _inputHandler?.HandleKeyboard(editorRect);
        _inputHandler?.HandleMouse(editorRect);
    }
    _renderer.Render(editorRect, _buffer);

    GUILayout.Space(5);

    // Problems
    var problemsRect = GUILayoutUtility.GetRect(contentWidth, problemsPanelHeight);
    _problemsPanel.Render(problemsRect, _lastCompileResult);

    // Handle error navigation
    if (_problemsPanel.SelectedLine.HasValue)
    {
        _buffer.SetCursor(_problemsPanel.SelectedLine.Value - 1, 0);
        _renderer.EnsureCursorVisible(editorRect, _buffer);
        _problemsPanel.ClearSelection();
    }

    GUILayout.EndVertical();

    // Right side: sidebar
    var sidebarRect = GUILayoutUtility.GetRect(sidebarWidth, totalHeight);
    _sidebar.Render(sidebarRect);

    // Handle sidebar insertions
    if (_sidebar.TextToInsert != null)
    {
        _buffer.SaveUndoState();
        _buffer.InsertText(_sidebar.TextToInsert);
    }

    GUILayout.EndHorizontal();

    // ... status bar ...
    // ... drag window ...
}
```

**Step 2: Build to verify**

Run: `dotnet build .worktrees/multi-platform/Basic10.GameMod/Basic10.GameMod.csproj`
Expected: Build succeeded

**Step 3: Commit**

```bash
git add .worktrees/multi-platform/Basic10.GameMod/Editor/EditorWindow.cs
git commit -m "feat(gamemod): integrate Sidebar into editor layout"
```

---

## Phase 10: Final Integration & Testing

### Task 10.1: Add BepInEx Configuration

**Files:**
- Create: `.worktrees/multi-platform/Basic10.GameMod/EditorConfig.cs`

**Step 1: Create config class for customizable settings**

```csharp
using BepInEx.Configuration;
using UnityEngine;

namespace Basic10.GameMod;

/// <summary>
/// BepInEx configuration for the Basic-10 editor.
/// Settings are stored in BepInEx/config/com.dogtired.basic10.cfg
/// </summary>
public static class EditorConfig
{
    // Color settings
    public static ConfigEntry<string> KeywordColor { get; private set; } = null!;
    public static ConfigEntry<string> IdentifierColor { get; private set; } = null!;
    public static ConfigEntry<string> NumberColor { get; private set; } = null!;
    public static ConfigEntry<string> StringColor { get; private set; } = null!;
    public static ConfigEntry<string> CommentColor { get; private set; } = null!;

    // Editor settings
    public static ConfigEntry<int> FontSize { get; private set; } = null!;
    public static ConfigEntry<bool> AutoCompile { get; private set; } = null!;

    public static void Initialize(ConfigFile config)
    {
        // Colors (as hex strings)
        KeywordColor = config.Bind("Colors", "Keyword", "#99CCFF",
            "Color for keywords (IF, THEN, FOR, etc.)");
        IdentifierColor = config.Bind("Colors", "Identifier", "#E5E5E5",
            "Color for variables and identifiers");
        NumberColor = config.Bind("Colors", "Number", "#B3E6B3",
            "Color for numeric literals");
        StringColor = config.Bind("Colors", "String", "#E6B380",
            "Color for string literals");
        CommentColor = config.Bind("Colors", "Comment", "#809980",
            "Color for comments");

        // Editor
        FontSize = config.Bind("Editor", "FontSize", 14,
            "Code editor font size (10-24)");
        AutoCompile = config.Bind("Editor", "AutoCompile", false,
            "Automatically compile when typing stops");

        Basic10Plugin.Log.LogInfo("Configuration loaded");
    }

    /// <summary>
    /// Parse a hex color string to Unity Color.
    /// </summary>
    public static Color ParseColor(string hex, Color fallback)
    {
        if (ColorUtility.TryParseHtmlString(hex, out var color))
            return color;
        return fallback;
    }
}
```

**Step 2: Update Plugin to initialize config**

In `Basic10Plugin.Awake()`, add after Log initialization:
```csharp
// Initialize configuration
EditorConfig.Initialize(Config);
```

**Step 3: Build to verify**

Run: `dotnet build .worktrees/multi-platform/Basic10.GameMod/Basic10.GameMod.csproj`
Expected: Build succeeded

**Step 4: Commit**

```bash
git add .worktrees/multi-platform/Basic10.GameMod/EditorConfig.cs
git add .worktrees/multi-platform/Basic10.GameMod/Basic10Plugin.cs
git commit -m "feat(gamemod): add BepInEx configuration for editor settings"
```

---

### Task 10.2: Full Build and Manual Test

**Step 1: Clean and rebuild entire GameMod project**

Run:
```bash
dotnet clean .worktrees/multi-platform/Basic10.GameMod/Basic10.GameMod.csproj
dotnet build .worktrees/multi-platform/Basic10.GameMod/Basic10.GameMod.csproj -c Release
```
Expected: Build succeeded, 0 warnings, 0 errors

**Step 2: Copy to Stationeers mods folder for testing**

Run:
```bash
# Copy output to mods folder (adjust path as needed)
xcopy /Y ".worktrees\multi-platform\Basic10.GameMod\bin\Release\net472\*.dll" "%USERPROFILE%\Documents\My Games\Stationeers\mods\Basic10\plugins\"
```

**Step 3: Manual test checklist**

- [ ] Launch Stationeers with BepInEx
- [ ] Approach an IC10 chip and open programming interface
- [ ] Verify Basic-10 editor appears instead of vanilla editor
- [ ] Type BASIC code and verify syntax highlighting
- [ ] Test keyboard shortcuts (Ctrl+Z, Ctrl+C, Ctrl+V, etc.)
- [ ] Click Compile and verify problems panel updates
- [ ] Click on an error and verify cursor jumps to line
- [ ] Save and verify chip receives compiled IC10 code
- [ ] Load existing scripts from sidebar

**Step 4: Commit completion**

```bash
git add -A
git commit -m "feat(gamemod): complete Basic-10 in-game editor v1.0"
```

---

## Summary

This plan implements the Basic-10 in-game editor in 10 phases:

1. **Core Infrastructure** - EditorWindow shell, game integration patches
2. **Text Buffer** - Line-based text management with cursor and selection
3. **Text Rendering** - Custom IMGUI rendering with line numbers
4. **Keyboard Input** - Full keyboard handling with shortcuts
5. **Syntax Highlighting** - Lexer-based coloring
6. **Script File I/O** - .bas file storage alongside instruction.xml
7. **Toolbar Actions** - Save, Compile, Load, New functionality
8. **Problems Panel** - Clickable errors with metrics display
9. **Sidebar Tabs** - Devices, Syntax, Examples
10. **Configuration** - BepInEx config for customization

Each task is atomic (2-5 minutes), with exact code and build commands.
