# Extended Script Mode Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Add a toolbar toggle for extended script mode (512 lines) that leverages the "More Lines of Code" mod by jixxed.

**Architecture:** Add UI toggle to toolbar, update line count validation/display logic, modify save/export to tag extended scripts with mod requirement comment and XML element.

**Tech Stack:** WPF/XAML, C# (.NET 8.0), AvalonEdit

---

## Constants Reference

```csharp
private const int VANILLA_LINE_LIMIT = 128;
private const int EXTENDED_LINE_LIMIT = 512;
private const string MOD_WORKSHOP_URL = "https://steamcommunity.com/sharedfiles/filedetails/?id=3265272725";
private const string MOD_NAME = "More Lines of Code";
private const string MOD_AUTHOR = "jixxed";
```

---

### Task 1: Add Extended Mode Color to Theme Files

**Files:**
- Modify: `UI/Themes/DarkTheme.xaml:52` (after HighlightBrush)
- Modify: `UI/Themes/LightTheme.xaml:52` (after HighlightBrush)

**Step 1: Add purple color and brush to DarkTheme.xaml**

After line 52 (`<SolidColorBrush x:Key="HighlightBrush"...`), add:

```xml
    <!-- Extended Script Mode (exceeds vanilla 128, valid for mod) -->
    <Color x:Key="ExtendedModeColor">#9C27B0</Color>
    <SolidColorBrush x:Key="ExtendedModeBrush" Color="{DynamicResource ExtendedModeColor}"/>
```

**Step 2: Add purple color and brush to LightTheme.xaml**

After line 52 (`<SolidColorBrush x:Key="HighlightBrush"...`), add:

```xml
    <!-- Extended Script Mode (exceeds vanilla 128, valid for mod) -->
    <Color x:Key="ExtendedModeColor">#7B1FA2</Color>
    <SolidColorBrush x:Key="ExtendedModeBrush" Color="{DynamicResource ExtendedModeColor}"/>
```

**Step 3: Build to verify no XAML errors**

Run: `dotnet build`
Expected: Build succeeded

**Step 4: Commit**

```bash
git add UI/Themes/DarkTheme.xaml UI/Themes/LightTheme.xaml
git commit -m "feat: add ExtendedModeBrush for 512-line mode indicator"
```

---

### Task 2: Add Extended Mode Checkbox to Toolbar (XAML)

**Files:**
- Modify: `UI/MainWindow.xaml:265` (after AutoCompleteCheckBox)

**Step 1: Add the checkbox after AutoCompleteCheckBox**

Find line 265 (end of AutoCompleteCheckBox), and after it add:

```xml
                <Rectangle Width="1" Fill="{DynamicResource SeparatorBrush}" Margin="8,4"/>
                <CheckBox x:Name="ExtendedModeCheckBox" Content="Extended (512)"
                          VerticalAlignment="Center" Margin="4,0"
                          Foreground="White"
                          ToolTip="Allow scripts up to 512 lines (requires 'More Lines of Code' mod by jixxed)"
                          Checked="ExtendedModeCheckBox_Changed" Unchecked="ExtendedModeCheckBox_Changed"/>
```

**Step 2: Build to verify XAML compiles**

Run: `dotnet build`
Expected: Build succeeded (will have warnings about missing event handler - that's expected)

**Step 3: Commit**

```bash
git add UI/MainWindow.xaml
git commit -m "feat: add Extended (512) checkbox to toolbar"
```

---

### Task 3: Add State Variables and Constants

**Files:**
- Modify: `UI/MainWindow.xaml.cs:80` (after _lastAutoSave field)

**Step 1: Add constants and state variables**

After line 80 (`private DateTime _lastAutoSave = DateTime.MinValue;`), add:

```csharp
    // Extended script mode (512 lines - requires "More Lines of Code" mod)
    private const int VANILLA_LINE_LIMIT = 128;
    private const int EXTENDED_LINE_LIMIT = 512;
    private const string MOD_WORKSHOP_URL = "https://steamcommunity.com/sharedfiles/filedetails/?id=3265272725";
    private const string MOD_NAME = "More Lines of Code";
    private const string MOD_AUTHOR = "jixxed";
    private bool _extendedModeEnabled = false;
    private bool _extendedModeWarningShown = false;
```

**Step 2: Build to verify**

Run: `dotnet build`
Expected: Build succeeded

**Step 3: Commit**

```bash
git add UI/MainWindow.xaml.cs
git commit -m "feat: add extended mode constants and state variables"
```

---

### Task 4: Implement Extended Mode Toggle Handler

**Files:**
- Modify: `UI/MainWindow.xaml.cs` (add new method after existing checkbox handlers)

**Step 1: Find AutoCompleteCheckBox_Changed method and add new handler after it**

Search for `AutoCompleteCheckBox_Changed` method. After that method, add:

```csharp
    private void ExtendedModeCheckBox_Changed(object sender, RoutedEventArgs e)
    {
        var isChecked = ExtendedModeCheckBox.IsChecked == true;

        if (isChecked && !_extendedModeWarningShown)
        {
            // Show first-time warning dialog
            var result = MessageBox.Show(
                $"This mode allows scripts up to 512 lines, but requires the \"{MOD_NAME}\" mod by {MOD_AUTHOR} to be installed in Stationeers.\n\n" +
                "Scripts saved in this mode will not work without the mod.\n\n" +
                "Click 'Yes' to enable extended mode, 'No' to cancel, or 'Help' to open the mod's Steam Workshop page.",
                "Extended Script Mode",
                MessageBoxButton.YesNoCancel,
                MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                _extendedModeEnabled = true;
                _extendedModeWarningShown = true;
            }
            else if (result == MessageBoxResult.Cancel)
            {
                // "Cancel" acts as "Learn More" - open workshop page
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                {
                    FileName = MOD_WORKSHOP_URL,
                    UseShellExecute = true
                });
                ExtendedModeCheckBox.IsChecked = false;
                return;
            }
            else
            {
                // No - cancel
                ExtendedModeCheckBox.IsChecked = false;
                return;
            }
        }
        else
        {
            _extendedModeEnabled = isChecked;
        }

        // Update line count display with new limits
        UpdateLineCount();
    }
```

**Step 2: Build to verify**

Run: `dotnet build`
Expected: Build succeeded

**Step 3: Commit**

```bash
git add UI/MainWindow.xaml.cs
git commit -m "feat: implement extended mode toggle with warning dialog"
```

---

### Task 5: Update Line Count Display Logic

**Files:**
- Modify: `UI/MainWindow.xaml.cs` - UpdateLineCount method (around line 2336)

**Step 1: Replace the entire UpdateLineCount method**

Find and replace the `UpdateLineCount()` method with:

```csharp
    private void UpdateLineCount()
    {
        var basicLines = BasicEditor.LineCount;
        var mipsLines = string.IsNullOrEmpty(MipsOutput.Text) ? 0 : MipsOutput.LineCount;
        var lineLimit = _extendedModeEnabled ? EXTENDED_LINE_LIMIT : VANILLA_LINE_LIMIT;

        BasicLineCountText.Text = $"Lines: {basicLines}";
        MipsLineCountText.Text = $"Lines: {mipsLines} / {lineLimit}";

        // Update warning badges based on current mode
        if (_extendedModeEnabled)
        {
            // Extended mode: warn at vanilla limit, error at extended limit
            LineWarningBadge.Visibility = mipsLines >= 100 && mipsLines <= VANILLA_LINE_LIMIT ? Visibility.Visible : Visibility.Collapsed;
            LineErrorBadge.Visibility = mipsLines > EXTENDED_LINE_LIMIT ? Visibility.Visible : Visibility.Collapsed;
        }
        else
        {
            // Vanilla mode: warn near 128, error over 128
            LineWarningBadge.Visibility = mipsLines >= 100 && mipsLines <= VANILLA_LINE_LIMIT ? Visibility.Visible : Visibility.Collapsed;
            LineErrorBadge.Visibility = mipsLines > VANILLA_LINE_LIMIT ? Visibility.Visible : Visibility.Collapsed;
        }

        // Update line budget indicator in status bar with color coding
        LineBudgetText.Text = $"{mipsLines}/{lineLimit}";

        if (_extendedModeEnabled)
        {
            // Extended mode color thresholds
            if (mipsLines > EXTENDED_LINE_LIMIT)
            {
                // Over extended limit - red error
                MipsLineCountText.Foreground = (Brush)FindResource("ErrorBrush");
                LineBudgetIndicator.Background = new SolidColorBrush(Color.FromRgb(244, 67, 54)); // Red
            }
            else if (mipsLines > 450)
            {
                // Near extended limit (451-512) - red warning
                MipsLineCountText.Foreground = (Brush)FindResource("ErrorBrush");
                LineBudgetIndicator.Background = new SolidColorBrush(Color.FromRgb(244, 67, 54)); // Red
            }
            else if (mipsLines > VANILLA_LINE_LIMIT)
            {
                // Exceeds vanilla but valid for mod (129-450) - purple
                MipsLineCountText.Foreground = (Brush)FindResource("ExtendedModeBrush");
                LineBudgetIndicator.Background = new SolidColorBrush(Color.FromRgb(156, 39, 176)); // Purple
            }
            else if (mipsLines >= 100)
            {
                // Near vanilla limit (100-128) - orange warning
                MipsLineCountText.Foreground = (Brush)FindResource("WarningBrush");
                LineBudgetIndicator.Background = new SolidColorBrush(Color.FromRgb(255, 152, 0)); // Orange
            }
            else
            {
                // Safe (0-99) - green
                MipsLineCountText.Foreground = (Brush)FindResource("SecondaryTextBrush");
                LineBudgetIndicator.Background = new SolidColorBrush(Color.FromRgb(0, 200, 83)); // Green
            }
        }
        else
        {
            // Vanilla mode - original behavior
            if (mipsLines > VANILLA_LINE_LIMIT)
            {
                MipsLineCountText.Foreground = (Brush)FindResource("ErrorBrush");
                LineBudgetIndicator.Background = new SolidColorBrush(Color.FromRgb(244, 67, 54)); // Red
            }
            else if (mipsLines >= 100)
            {
                MipsLineCountText.Foreground = (Brush)FindResource("WarningBrush");
                LineBudgetIndicator.Background = new SolidColorBrush(Color.FromRgb(255, 152, 0)); // Orange
            }
            else
            {
                MipsLineCountText.Foreground = (Brush)FindResource("SecondaryTextBrush");
                LineBudgetIndicator.Background = new SolidColorBrush(Color.FromRgb(0, 200, 83)); // Green
            }
        }
    }
```

**Step 2: Build to verify**

Run: `dotnet build`
Expected: Build succeeded

**Step 3: Commit**

```bash
git add UI/MainWindow.xaml.cs
git commit -m "feat: update line count display for extended mode thresholds"
```

---

### Task 6: Add Extended Script Header Helper Method

**Files:**
- Modify: `UI/MainWindow.xaml.cs` (add helper method near GenerateInstructionXml)

**Step 1: Add helper method to generate extended script header**

After the `ExtractMetaAuthor` method (around line 1242), add:

```csharp
    private string GetExtendedScriptHeader()
    {
        return $"# EXTENDED SCRIPT - Requires \"{MOD_NAME}\" mod by {MOD_AUTHOR}\n# {MOD_WORKSHOP_URL}\n";
    }

    private bool IsExtendedScript(int lineCount)
    {
        return _extendedModeEnabled && lineCount > VANILLA_LINE_LIMIT;
    }
```

**Step 2: Build to verify**

Run: `dotnet build`
Expected: Build succeeded

**Step 3: Commit**

```bash
git add UI/MainWindow.xaml.cs
git commit -m "feat: add helper methods for extended script detection"
```

---

### Task 7: Update GenerateInstructionXml for Extended Mode

**Files:**
- Modify: `UI/MainWindow.xaml.cs` - GenerateInstructionXml method (around line 1244)

**Step 1: Replace GenerateInstructionXml method**

Find and replace the entire `GenerateInstructionXml` method:

```csharp
    private void GenerateInstructionXml(string path, string scriptName, string ic10Code, string author)
    {
        // Generate timestamp in game format (ticks)
        var ticks = DateTime.UtcNow.Ticks;

        // Count actual IC10 lines (for extended script detection)
        var lineCount = ic10Code.Split('\n', StringSplitOptions.RemoveEmptyEntries).Length;
        var isExtended = IsExtendedScript(lineCount);

        // Prepend extended script header if needed
        var finalCode = isExtended ? GetExtendedScriptHeader() + ic10Code : ic10Code;

        // Escape the IC10 code for XML
        var escapedCode = System.Security.SecurityElement.Escape(finalCode);

        // Use settings author first, then meta comment author, then default
        var displayAuthor = !string.IsNullOrWhiteSpace(_settings.ScriptAuthor)
            ? _settings.ScriptAuthor
            : (!string.IsNullOrWhiteSpace(author) ? author : "Unknown");

        // Build description: user's custom description + "Built in Basic-10"
        var userDesc = _settings.ScriptDescription?.Trim() ?? "";
        var description = string.IsNullOrEmpty(userDesc)
            ? "Built in Basic-10"
            : $"{userDesc}\n\nBuilt in Basic-10";

        // Build RequiresMod element if extended
        var requireModElement = isExtended
            ? $"\n  <RequiresMod>{MOD_WORKSHOP_URL}</RequiresMod>"
            : "";

        var xml = $@"<?xml version=""1.0"" encoding=""utf-8""?>
<InstructionData xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"">
  <DateTime>{ticks}</DateTime>
  <GameVersion>0.2</GameVersion>
  <Title>{System.Security.SecurityElement.Escape(scriptName)}</Title>
  <Description>{System.Security.SecurityElement.Escape(description)}</Description>
  <Author>{System.Security.SecurityElement.Escape(displayAuthor)}</Author>
  <WorkshopFileHandle>0</WorkshopFileHandle>
  <Instructions>{escapedCode}</Instructions>{requireModElement}
</InstructionData>";
        File.WriteAllText(path, xml);
    }
```

**Step 2: Build to verify**

Run: `dotnet build`
Expected: Build succeeded

**Step 3: Commit**

```bash
git add UI/MainWindow.xaml.cs
git commit -m "feat: add RequiresMod element and header for extended scripts"
```

---

### Task 8: Update CopyIC10 for Extended Mode

**Files:**
- Modify: `UI/MainWindow.xaml.cs` - CopyIC10_Click method (around line 1704)

**Step 1: Replace CopyIC10_Click method**

Find and replace the `CopyIC10_Click` method:

```csharp
    private void CopyIC10_Click(object sender, RoutedEventArgs e)
    {
        if (!string.IsNullOrEmpty(MipsOutput.Text))
        {
            var code = MipsOutput.Text;
            var lineCount = code.Split('\n', StringSplitOptions.RemoveEmptyEntries).Length;

            // Prepend extended script header if needed
            if (IsExtendedScript(lineCount))
            {
                code = GetExtendedScriptHeader() + code;
            }

            Clipboard.SetText(code);
            SetStatus("IC10 code copied to clipboard", true);
        }
    }
```

**Step 2: Build to verify**

Run: `dotnet build`
Expected: Build succeeded

**Step 3: Commit**

```bash
git add UI/MainWindow.xaml.cs
git commit -m "feat: add extended script header to clipboard copy"
```

---

### Task 9: Update Version Number

**Files:**
- Modify: `BasicToMips.csproj:12`

**Step 1: Update version to 3.0.27**

Change line 12 from:
```xml
    <Version>3.0.26</Version>
```
To:
```xml
    <Version>3.0.27</Version>
```

**Step 2: Build to verify**

Run: `dotnet build -c Release`
Expected: Build succeeded

**Step 3: Commit**

```bash
git add BasicToMips.csproj
git commit -m "chore: bump version to 3.0.27"
```

---

### Task 10: Full Build and Test

**Step 1: Clean and rebuild**

Run: `dotnet clean && dotnet build -c Release`
Expected: Build succeeded with 0 errors

**Step 2: Run the application manually to test**

Run: `dotnet run -c Release`

Test checklist:
- [ ] Checkbox appears in toolbar after Auto-complete
- [ ] Clicking checkbox shows warning dialog
- [ ] "Yes" enables mode, checkbox stays checked
- [ ] "No" cancels, checkbox stays unchecked
- [ ] "Cancel" opens browser to workshop, checkbox unchecked
- [ ] Line count shows /512 when enabled, /128 when disabled
- [ ] Lines 129-450 show purple indicator when extended mode on
- [ ] Lines >512 show red error when extended mode on

**Step 3: Commit all remaining changes**

```bash
git add -A
git commit -m "feat: complete extended script mode implementation"
```

---

### Task 11: Build Release Package for v3.0.27

**Step 1: Publish release build**

Run:
```bash
dotnet publish -c Release -r win-x64 --self-contained true -o ./publish
```

**Step 2: Create release zip**

Run:
```powershell
powershell -Command "Compress-Archive -Path './publish/*' -DestinationPath './BasicToMips_v3.0.27.zip' -Force"
```

**Step 3: Verify zip was created**

Run: `dir BasicToMips_v3.0.27.zip`
Expected: File exists with reasonable size (50+ MB)

---

### Task 12: Create v2.2.1 Branch for Repository Release

**Note:** v2.2.1 should NOT include MCP integration or features added after v2.1.0. We need to create this from a clean state based on repository code.

**Step 1: Fetch latest from repository**

Run:
```bash
git fetch origin
git checkout -b release/v2.2.1 origin/main
```

**Step 2: Cherry-pick only the extended mode commits**

Apply the extended mode changes to this branch by cherry-picking the commits made in Tasks 1-8.

Or manually apply the same changes to the v2.1.0 codebase files.

**Step 3: Update version to 2.2.1**

Change version in BasicToMips.csproj to `2.2.1`

**Step 4: Build and test v2.2.1**

Run: `dotnet build -c Release`

**Step 5: Create release package**

Run:
```bash
dotnet publish -c Release -r win-x64 --self-contained true -o ./publish-v2.2.1
powershell -Command "Compress-Archive -Path './publish-v2.2.1/*' -DestinationPath './BasicToMips_v2.2.1.zip' -Force"
```

---

## Summary

**v3.0.27 (local):** Full implementation with all existing features + extended mode
**v2.2.1 (repository):** Minimal release based on v2.1.0 + extended mode only

Both versions include:
- Toolbar checkbox "Extended (512)"
- First-time warning dialog with mod credit
- Purple color for 129-450 line range
- `<RequiresMod>` XML element in instruction.xml
- IC10 header comment on save/export/copy
