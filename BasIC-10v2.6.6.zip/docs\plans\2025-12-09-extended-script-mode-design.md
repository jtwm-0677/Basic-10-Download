# Extended Script Mode Design

**Date:** 2025-12-09
**Feature:** Toggle for extended length scripts (512 lines) via "More Lines of Code" mod
**Versions:** v2.2.1 (release) and v3.0.26 (unreleased)

## Overview

Add a toggle to allow scripts up to 512 lines (instead of the vanilla 128-line limit) by leveraging the popular "More Lines of Code" mod by jixxed. The feature includes clear warnings about mod dependency and tags saved scripts appropriately.

**Mod Reference:**
- **Name:** More Lines of Code
- **Author:** jixxed
- **Steam Workshop:** https://steamcommunity.com/sharedfiles/filedetails/?id=3265272725
- **Limits Changed:** 128 → 512 lines, 4096 → 12288 file size

## UI Components

### Toolbar Checkbox

Add a checkbox to the toolbar (next to Auto-compile and Auto-complete):

```
☐ Extended (512)
```

- Defaults to OFF on each application start (not persisted across sessions)
- When enabled, changes line limit validation from 128 to 512

### First-Time Warning Dialog

When user first enables the toggle (per session), show a modal dialog:

```
┌─────────────────────────────────────────────────────────┐
│  Extended Script Mode                                    │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  This mode allows scripts up to 512 lines, but requires │
│  the "More Lines of Code" mod by jixxed to be installed │
│  in Stationeers.                                         │
│                                                          │
│  Scripts saved in this mode will not work without the   │
│  mod.                                                    │
│                                                          │
│              [Learn More]  [Cancel]  [Enable]           │
└─────────────────────────────────────────────────────────┘
```

- **Learn More:** Opens Steam Workshop link in browser
- **Cancel:** Leaves toggle unchecked
- **Enable:** Enables extended mode for this session

### Persistent Visual Indicator

While extended mode is enabled, display a persistent indicator:
- Purple-tinted badge or highlight on the checkbox area
- Status bar indicator showing current mode

## Line Count Display

### Extended Mode ON - Thresholds

| Lines    | Color  | Display    | Meaning                        |
|----------|--------|------------|--------------------------------|
| 0-99     | Green  | `45/512`   | Safe                           |
| 100-128  | Orange | `115/512`  | Near vanilla limit             |
| 129-450  | Purple | `250/512`  | Exceeds vanilla, valid for mod |
| 451-512  | Red    | `480/512`  | Near extended limit            |
| 512+     | Red    | `530/512`  | Over extended limit (error)    |

### Extended Mode OFF - Thresholds (unchanged)

| Lines | Color  | Display    |
|-------|--------|------------|
| 0-99  | Green  | `45/128`   |
| 100-128 | Orange | `115/128` |
| 128+  | Red    | `150/128`  |

### Display Locations

Update these displays based on mode:
- MIPS output header: `Lines: X / 512` vs `Lines: X / 128`
- Status bar budget indicator: `X/512` vs `X/128`
- Warning/error badges with appropriate thresholds

## Save/Export Tagging

Tags are ONLY added when:
1. Extended mode is enabled, AND
2. Script exceeds 128 lines

### IC10 Code Header

Add at top of generated IC10 output:

```
# EXTENDED SCRIPT - Requires "More Lines of Code" mod by jixxed
# https://steamcommunity.com/sharedfiles/filedetails/?id=3265272725
```

### instruction.xml Element

Add new element to InstructionData:

```xml
<?xml version="1.0" encoding="utf-8"?>
<InstructionData xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <DateTime>...</DateTime>
  <GameVersion>0.2</GameVersion>
  <Title>ScriptName</Title>
  <Description>Built in Basic-10</Description>
  <Author>...</Author>
  <WorkshopFileHandle>0</WorkshopFileHandle>
  <Instructions>...</Instructions>
  <RequiresMod>https://steamcommunity.com/sharedfiles/filedetails/?id=3265272725</RequiresMod>
</InstructionData>
```

### Export Behavior

- **Save to Scripts Folder:** Adds both IC10 header and XML element
- **Export IC10 to File:** Adds IC10 header comment
- **Copy IC10 to Clipboard:** Adds IC10 header comment

## Implementation Scope

### v2.2.1 (Repository Release)

**Note:** Visual programming interface is NOT exposed in this version.

Files to modify:
1. `UI/MainWindow.xaml` - Add toolbar checkbox, update status bar
2. `UI/MainWindow.xaml.cs` - Toggle logic, warning dialog, threshold changes
3. `UI/Themes/DarkTheme.xaml` - Add ExtendedModeBrush (purple)
4. `UI/Themes/LightTheme.xaml` - Add ExtendedModeBrush (purple)

### v3.0.26 (Local Unreleased)

All changes from v2.2.1, plus:
5. `Services/HttpApiServer.cs` - Include extended mode in API responses
6. `Basic10.Mcp/HttpBridge.cs` - Reflect extended mode state in MCP tools

## Technical Details

### Constants

```csharp
private const int VANILLA_LINE_LIMIT = 128;
private const int EXTENDED_LINE_LIMIT = 512;
private const string MOD_WORKSHOP_URL = "https://steamcommunity.com/sharedfiles/filedetails/?id=3265272725";
private const string MOD_NAME = "More Lines of Code";
private const string MOD_AUTHOR = "jixxed";
```

### State Variables

```csharp
private bool _extendedModeEnabled = false;      // Toggle state
private bool _extendedModeWarningShown = false; // Per-session warning flag
```

### Purple Color (Theme Resources)

```xml
<!-- Extended mode indicator - exceeds vanilla but valid for mod -->
<SolidColorBrush x:Key="ExtendedModeBrush" Color="#9C27B0"/>      <!-- Purple 500 -->
<SolidColorBrush x:Key="ExtendedModeHoverBrush" Color="#7B1FA2"/> <!-- Purple 700 -->
```

## Version Notes

- **v2.2.0 → v2.2.1:** This feature addition
- **v3.0.26:** Same feature, unreleased development version
- Repository: https://github.com/jtwm-0677/Stationeers_BasIC-10
