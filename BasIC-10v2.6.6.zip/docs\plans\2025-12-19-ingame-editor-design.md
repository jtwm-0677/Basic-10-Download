# Basic-10 In-Game Editor - Design Document

**Status:** Design complete, ready for implementation planning
**Date:** 2025-12-19

## Overview

Standalone in-game BASIC code editor for Stationeers that replaces the vanilla IC10 chip editor. 100% independent - no dependencies on IC10 Editor or other mods.

## Core Decisions

| Decision | Choice |
|----------|--------|
| Architecture | Standalone (not IC10 Editor plugin) |
| UI Framework | Unity IMGUI |
| Source Storage | Scripts folder (`source.bas` alongside `instruction.xml`) |
| Mixed Coding | Supported (BASIC + inline IC10 via ASM blocks) |
| Autocomplete | None for initial release |
| Syntax Highlighting | Semantic coloring, user-configurable via BepInEx config |

## File Structure

```
Documents\My Games\Stationeers\scripts\{ScriptName}\
├── instruction.xml    ← IC10 code (game loads this)
└── source.bas         ← BASIC source (we preserve this)
```

When opening existing scripts:
- If `.bas` exists → load BASIC source
- If only `instruction.xml` → show IC10 as-is

## UI Layout

```
┌─────────────────────────────────────────────────────────────┐
│  [Save] [Compile] [Load] [New] [Cancel]                     │
├─────────────────────────────────────────────┬───────────────┤
│                                             │[Dev][Syn][Ex] │
│   1 │ ALIAS sensor d0                       │───────────────│
│   2 │ VAR temp = 0                          │               │
│   3 │                                       │  (tab content)│
│   4 │ LOOP:                                 │               │
│   5 │   temp = sensor.Temperature           │               │
│                                             │               │
├─────────────────────────────────────────────┴───────────────┤
│  ✗ Line 12: Unknown variable    │ 45/128 lines │ 1.2KB/4KB │
└─────────────────────────────────────────────────────────────┘
```

### Components

1. **Toolbar** - Save, Compile, Load, New, Cancel buttons
2. **Code Editor** - Main area with line numbers, scrollable
3. **Tabbed Sidebar** (right side):
   - **Devices** - Search + device list, click to insert hash
   - **Syntax** - Language reference (keywords, operators, functions)
   - **Examples** - Sample snippets, click to insert/load
4. **Problems Panel** (bottom):
   - Clickable errors (jump to line)
   - IC10 line count with color coding
   - Byte count with color coding

## Syntax Highlighting

Semantic coloring that tracks user-defined identifiers:

| Category | What it colors |
|----------|----------------|
| Keywords | IF, THEN, FOR, WHILE, ALIAS, VAR, CONST, etc. |
| User Identifiers | Variables, constants, aliases, device names - unified color |
| Strings | "text", Name["DeviceName"] content |
| Numbers | 123, 3.14, -500 |
| Comments | ' comment, REM comment |
| Device Properties | .Temperature, .Pressure, .On, .Setting |
| Operators | +, -, *, /, =, <, >, AND, OR |
| Labels | LOOP:, START:, END: |
| IC10 (in ASM blocks) | Different color for inline assembly |

All colors configurable via BepInEx config file.

## Text Editing (Initial Release)

| Shortcut | Action |
|----------|--------|
| Arrow keys | Move cursor |
| Shift + Arrow | Select text |
| Ctrl + Arrow | Jump by word |
| Home / End | Start / end of line |
| Ctrl + Home/End | Start / end of document |
| Ctrl + A | Select all |
| Ctrl + C/X/V | Copy / Cut / Paste |
| Ctrl + Z/Y | Undo / Redo |
| Tab / Shift+Tab | Indent / Unindent |
| Enter | New line with auto-indent |

### Planned for Future
- Ctrl+F - Find
- Ctrl+H - Find/Replace
- Ctrl+G - Go to line
- Multi-cursor editing
- Block select

## Problems Panel

- Clickable errors → jump to line
- IC10 metrics: line count, byte count
- Color coding: green (safe), yellow (warning), red (limit exceeded)

## Compilation Workflow

1. **Save button** - Compile, if success save both files, if errors show in panel
2. **Compile button** - Compile only, preview output + errors without saving

## Sidebar Tabs

### Devices Tab (Barebones)
- Search box
- Scrollable device list
- Click to insert device hash

### Syntax Tab
- Language reference
- Keywords, operators
- Built-in functions
- Device property syntax

### Examples Tab
- Sample snippets (Furnace Controller, Airlock, Solar Tracker, etc.)
- Click to insert or load

## NOT in Initial Release

- Split view (BASIC / IC10)
- Variable Inspector panel
- Autocomplete / Intellisense
- Find/Replace
- Multi-cursor
- Real-time compilation while typing

## Technical Notes

### BepInEx Integration
- Plugin extends `BaseUnityPlugin`
- Harmony patches to intercept chip editor opening
- Config file for all color settings

### Mod Structure
```
mods\Basic10\
├── About\
│   └── About.xml
├── plugins\
│   ├── Basic10.Core.dll
│   └── Basic10.GameMod.dll
├── Basic10.Core.dll
└── Basic10.GameMod.dll
```

### Game Integration Points
- Patch `InputSourceCode.ShowInputPanel` to show our editor
- Patch save/load to handle `.bas` files
- Use game's scripts folder for storage

## Reference Repos (for architecture study only)

- IC10 Editor: https://github.com/aproposmath/StationeersIC10Editor
- SLANG: https://github.com/dbidwell94/stationeers_lang

These are for reference only - do not modify or interact with.

## Next Steps

1. Create implementation plan with detailed tasks
2. Set up git worktree for development
3. Build IMGUI editor shell
4. Implement text editing core
5. Add syntax highlighting
6. Integrate compiler
7. Add sidebar tabs
8. Test and iterate

---

## Continuation Context

This document was created during a brainstorming session. The design is complete and ready for implementation planning.

To continue:
1. Use `superpowers:writing-plans` skill to create detailed implementation plan
2. Use `superpowers:using-git-worktrees` to create isolated workspace
3. Begin implementation

The GameMod project structure already exists at:
`.worktrees/multi-platform/Basic10.GameMod/`

Current files there are basic BepInEx plugin structure - will need significant expansion for the editor UI.
