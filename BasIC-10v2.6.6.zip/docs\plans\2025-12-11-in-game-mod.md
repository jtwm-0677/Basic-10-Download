# Basic-10 In-Game Mod Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Create a BepInEx mod that embeds the Basic-10 BASIC compiler inside Stationeers, allowing players to write BASIC code directly in-game with a toggle to switch between BASIC and vanilla MIPS editors.

**Architecture:** Refactor the existing compiler into a shared `Basic10.Core.dll` library (netstandard2.1) that both the WPF desktop app and the BepInEx in-game mod reference. This ensures bug fixes and features propagate to both apps automatically. The core library contains compiler, decompiler, and shared utilities. UI code remains separate in each app.

**Tech Stack:** C# (.NET Standard 2.1 for Core, .NET 8.0 for WPF), BepInEx 5.4, Harmony 2.x, StationeersLaunchPad, Unity IMGUI

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                      Basic10.Core.dll                           │
│                    (netstandard2.1)                             │
│                                                                 │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐ │
│  │  Compiler   │  │ Decompiler  │  │        Shared           │ │
│  │             │  │             │  │                         │ │
│  │  - Lexer    │  │ - IC10Parser│  │ - IDeviceDatabase       │ │
│  │  - Parser   │  │ - IC10Decomp│  │ - HashDictionary        │ │
│  │  - AST      │  │             │  │ - CompilerOptions       │ │
│  │  - CodeGen  │  │             │  │ - CompilationResult     │ │
│  └─────────────┘  └─────────────┘  └─────────────────────────┘ │
└───────────────────────────┬─────────────────────────────────────┘
                            │
            ┌───────────────┼───────────────┐
            │               │               │
            ▼               │               ▼
┌───────────────────┐       │     ┌───────────────────┐
│  BasicToMips.exe  │       │     │ Basic10.InGame.dll│
│   (WPF Desktop)   │       │     │  (BepInEx Mod)    │
│                   │       │     │                   │
│ - AvalonEdit UI   │       │     │ - Unity IMGUI UI  │
│ - WebView2 docs   │       │     │ - Harmony patches │
│ - HTTP API server │       │     │ - Editor toggle   │
│ - Settings UI     │       │     │                   │
└───────────────────┘       │     └───────────────────┘
                            │
                            ▼
              ┌─────────────────────────┐
              │  %LocalAppData%/        │
              │  BasicToMips/           │
              │  ├─ settings.json       │
              │  └─ hash_dictionary.json│
              └─────────────────────────┘
                    (Shared by both apps)
```

---

## Prerequisites

Before starting, ensure you have:

1. **Development Environment**
   - Visual Studio 2022 or Rider
   - .NET 8.0 SDK
   - .NET Standard 2.1 targeting capability

2. **Game Files**
   - Stationeers installed via Steam
   - BepInEx 5.4 installed in game directory
   - StationeersLaunchPad installed

3. **Decompilation Tools**
   - dnSpy or ILSpy for examining `Assembly-CSharp.dll`
   - Located at: `<Steam>/steamapps/common/Stationeers/rocketstation_Data/Managed/`

4. **Reference Repositories**
   - IC10 Editor: https://github.com/aproposmath/StationeersIC10Editor
   - Slang Compiler: https://github.com/dbidwell94/stationeers_lang
   - StationeersLaunchPad: https://github.com/StationeersLaunchPad/StationeersLaunchPad
   - BepInEx: https://github.com/BepInEx/BepInEx
   - BepInEx Docs: https://docs.bepinex.dev

---

## Phase 1: Create Shared Core Library

### Task 1.1: Create Basic10.Core Project

**Files:**
- Create: `Basic10.Core/Basic10.Core.csproj`

**Step 1: Create the project file**

Create `Basic10.Core/Basic10.Core.csproj`:

```xml
<Project Sdk="Microsoft.NET.Sdk">

  <PropertyGroup>
    <TargetFramework>netstandard2.1</TargetFramework>
    <LangVersion>latest</LangVersion>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
    <RootNamespace>Basic10.Core</RootNamespace>
    <AssemblyName>Basic10.Core</AssemblyName>
    <Version>1.0.0</Version>
    <Authors>Dog Tired Studios</Authors>
    <Description>Basic-10 BASIC to IC10 compiler core library - shared by desktop and in-game mod</Description>
  </PropertyGroup>

  <!-- No external dependencies - pure .NET Standard for maximum compatibility -->

</Project>
```

**Step 2: Add project to solution**

Run: `dotnet sln BasicToMips.sln add Basic10.Core/Basic10.Core.csproj`

**Step 3: Verify project builds**

Run: `dotnet build Basic10.Core/Basic10.Core.csproj`
Expected: Build succeeded

**Step 4: Commit**

```bash
git add Basic10.Core/ BasicToMips.sln
git commit -m "feat(core): create Basic10.Core shared library project"
```

---

### Task 1.2: Move Lexer to Core Library

**Files:**
- Move: `src/Lexer/Lexer.cs` → `Basic10.Core/Compiler/Lexer/Lexer.cs`
- Modify: Update namespace to `Basic10.Core.Compiler.Lexer`

**Step 1: Create directory structure**

```bash
mkdir -p Basic10.Core/Compiler/Lexer
```

**Step 2: Move and update Lexer.cs**

Move `src/Lexer/Lexer.cs` to `Basic10.Core/Compiler/Lexer/Lexer.cs`.

Update the namespace declaration:
```csharp
namespace Basic10.Core.Compiler.Lexer;
```

**Step 3: Verify build**

Run: `dotnet build Basic10.Core/Basic10.Core.csproj`
Expected: Build succeeded

**Step 4: Commit**

```bash
git add Basic10.Core/Compiler/Lexer/
git commit -m "refactor(core): move Lexer to shared library"
```

---

### Task 1.3: Move AST to Core Library

**Files:**
- Move: `src/AST/AstNode.cs` → `Basic10.Core/Compiler/AST/AstNode.cs`
- Modify: Update namespace to `Basic10.Core.Compiler.AST`

**Step 1: Create directory and move file**

```bash
mkdir -p Basic10.Core/Compiler/AST
```

Move `src/AST/AstNode.cs` to `Basic10.Core/Compiler/AST/AstNode.cs`.

**Step 2: Update namespace**

```csharp
namespace Basic10.Core.Compiler.AST;
```

**Step 3: Verify build**

Run: `dotnet build Basic10.Core/Basic10.Core.csproj`
Expected: Build succeeded

**Step 4: Commit**

```bash
git add Basic10.Core/Compiler/AST/
git commit -m "refactor(core): move AST to shared library"
```

---

### Task 1.4: Move Parser to Core Library

**Files:**
- Move: `src/Parser/Parser.cs` → `Basic10.Core/Compiler/Parser/Parser.cs`
- Modify: Update namespace and using statements

**Step 1: Create directory and move file**

```bash
mkdir -p Basic10.Core/Compiler/Parser
```

Move `src/Parser/Parser.cs` to `Basic10.Core/Compiler/Parser/Parser.cs`.

**Step 2: Update namespace and usings**

```csharp
using Basic10.Core.Compiler.Lexer;
using Basic10.Core.Compiler.AST;

namespace Basic10.Core.Compiler.Parser;
```

**Step 3: Verify build**

Run: `dotnet build Basic10.Core/Basic10.Core.csproj`
Expected: Build succeeded

**Step 4: Commit**

```bash
git add Basic10.Core/Compiler/Parser/
git commit -m "refactor(core): move Parser to shared library"
```

---

### Task 1.5: Move CodeGen to Core Library

**Files:**
- Move: `src/CodeGen/MipsGenerator.cs` → `Basic10.Core/Compiler/CodeGen/MipsGenerator.cs`
- Move: `src/CodeGen/RegisterAllocator.cs` → `Basic10.Core/Compiler/CodeGen/RegisterAllocator.cs`
- Move: `src/CodeGen/CodeEmitter.cs` → `Basic10.Core/Compiler/CodeGen/CodeEmitter.cs`
- Modify: Update namespaces and using statements

**Step 1: Create directory and move files**

```bash
mkdir -p Basic10.Core/Compiler/CodeGen
```

Move all CodeGen files.

**Step 2: Update namespaces**

In each file:
```csharp
using Basic10.Core.Compiler.AST;
using Basic10.Core.Shared;

namespace Basic10.Core.Compiler.CodeGen;
```

**Step 3: Handle DeviceDatabase dependency**

The MipsGenerator references `DeviceDatabase`. Create an interface in Shared:

Create `Basic10.Core/Shared/IDeviceDatabase.cs`:

```csharp
namespace Basic10.Core.Shared;

/// <summary>
/// Interface for device/property hash lookups.
/// Implemented by the host application (WPF or in-game mod).
/// </summary>
public interface IDeviceDatabase
{
    int? GetDeviceHash(string deviceName);
    int? GetPropertyHash(string propertyName);
    int? GetSlotPropertyHash(string propertyName);
    int? GetBatchModeValue(string modeName);
    int? GetReagentModeValue(string modeName);
    IEnumerable<string> GetDeviceNames();
    IEnumerable<string> GetPropertyNames();
}
```

Update MipsGenerator to use `IDeviceDatabase` instead of static `DeviceDatabase`.

**Step 4: Verify build**

Run: `dotnet build Basic10.Core/Basic10.Core.csproj`
Expected: Build succeeded (may need to stub some methods temporarily)

**Step 5: Commit**

```bash
git add Basic10.Core/Compiler/CodeGen/ Basic10.Core/Shared/
git commit -m "refactor(core): move CodeGen to shared library with IDeviceDatabase interface"
```

---

### Task 1.6: Move Decompiler to Core Library

**Files:**
- Move: `src/IC10/IC10Parser.cs` → `Basic10.Core/Decompiler/IC10Parser.cs`
- Move: `src/IC10/IC10Decompiler.cs` → `Basic10.Core/Decompiler/IC10Decompiler.cs`
- Modify: Update namespaces

**Step 1: Create directory and move files**

```bash
mkdir -p Basic10.Core/Decompiler
```

Move IC10 files.

**Step 2: Update namespaces**

```csharp
using Basic10.Core.Shared;

namespace Basic10.Core.Decompiler;
```

**Step 3: Verify build**

Run: `dotnet build Basic10.Core/Basic10.Core.csproj`
Expected: Build succeeded

**Step 4: Commit**

```bash
git add Basic10.Core/Decompiler/
git commit -m "refactor(core): move Decompiler to shared library"
```

---

### Task 1.7: Move Shared Utilities to Core Library

**Files:**
- Move/Create: `Basic10.Core/Shared/HashDictionary.cs`
- Move/Create: `Basic10.Core/Shared/CompilerOptions.cs`
- Move/Create: `Basic10.Core/Shared/CompilationResult.cs`
- Move: `src/Shared/SourceMap.cs` → `Basic10.Core/Shared/SourceMap.cs`

**Step 1: Create HashDictionary in Shared**

The HashDictionary needs to work without DeviceDatabase for pre-population.
Create a version that accepts an `IDeviceDatabase` for initialization:

```csharp
namespace Basic10.Core.Shared;

/// <summary>
/// A living hash dictionary that learns string-to-hash mappings from user compilations.
/// Persists across sessions to enable reverse hash lookups during decompilation.
/// </summary>
public class HashDictionary
{
    private readonly Dictionary<int, string> _hashToString = new();
    private readonly Dictionary<string, int> _stringToHash = new(StringComparer.OrdinalIgnoreCase);
    private readonly string _dictionaryPath;
    private bool _isDirty = false;

    public HashDictionary(string? customPath = null)
    {
        var appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        var basicTenDir = Path.Combine(appDataPath, "BasicToMips");

        if (!Directory.Exists(basicTenDir))
        {
            Directory.CreateDirectory(basicTenDir);
        }

        _dictionaryPath = customPath ?? Path.Combine(basicTenDir, "hash_dictionary.json");
        Load();
    }

    /// <summary>
    /// Pre-populate from a device database.
    /// </summary>
    public void PopulateFromDatabase(IDeviceDatabase database)
    {
        foreach (var deviceName in database.GetDeviceNames())
        {
            var hash = database.GetDeviceHash(deviceName);
            if (hash.HasValue)
            {
                RegisterHash(deviceName, hash.Value);
            }
        }

        foreach (var propName in database.GetPropertyNames())
        {
            var hash = database.GetPropertyHash(propName);
            if (hash.HasValue)
            {
                RegisterHash(propName, hash.Value);
            }
        }
    }

    public void RegisterHash(string value, int hash)
    {
        if (string.IsNullOrEmpty(value)) return;

        if (!_hashToString.TryGetValue(hash, out var existing) || existing != value)
        {
            _hashToString[hash] = value;
            _stringToHash[value] = hash;
            _isDirty = true;
        }
    }

    public string? LookupHash(int hash)
    {
        return _hashToString.TryGetValue(hash, out var value) ? value : null;
    }

    public int? LookupString(string value)
    {
        return _stringToHash.TryGetValue(value, out var hash) ? hash : null;
    }

    public int Count => _hashToString.Count;

    public void Save()
    {
        if (!_isDirty) return;

        try
        {
            var data = new HashDictionaryData
            {
                Version = 1,
                Entries = _hashToString.Select(kvp => new HashEntry
                {
                    Hash = kvp.Key,
                    Value = kvp.Value
                }).ToList()
            };

            var json = System.Text.Json.JsonSerializer.Serialize(data,
                new System.Text.Json.JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(_dictionaryPath, json);
            _isDirty = false;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"Failed to save hash dictionary: {ex.Message}");
        }
    }

    private void Load()
    {
        if (!File.Exists(_dictionaryPath)) return;

        try
        {
            var json = File.ReadAllText(_dictionaryPath);
            var data = System.Text.Json.JsonSerializer.Deserialize<HashDictionaryData>(json);

            if (data?.Entries != null)
            {
                foreach (var entry in data.Entries)
                {
                    _hashToString[entry.Hash] = entry.Value;
                    _stringToHash[entry.Value] = entry.Hash;
                }
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"Failed to load hash dictionary: {ex.Message}");
        }
    }

    private class HashDictionaryData
    {
        public int Version { get; set; }
        public List<HashEntry> Entries { get; set; } = new();
    }

    private class HashEntry
    {
        public int Hash { get; set; }
        public string Value { get; set; } = "";
    }
}
```

**Step 2: Create CompilationResult**

Create `Basic10.Core/Shared/CompilationResult.cs`:

```csharp
namespace Basic10.Core.Shared;

public class CompilationResult
{
    public bool Success { get; }
    public string? MipsCode { get; }
    public int LineCount { get; }
    public IReadOnlyList<CompilerError> Errors { get; }
    public IReadOnlyList<CompilerError> Warnings { get; }
    public SourceMap? SourceMap { get; }

    private CompilationResult(bool success, string? mipsCode, int lineCount,
        IReadOnlyList<CompilerError> errors, IReadOnlyList<CompilerError> warnings,
        SourceMap? sourceMap = null)
    {
        Success = success;
        MipsCode = mipsCode;
        LineCount = lineCount;
        Errors = errors;
        Warnings = warnings;
        SourceMap = sourceMap;
    }

    public static CompilationResult Succeeded(string mipsCode, int lineCount,
        List<CompilerError>? warnings = null, SourceMap? sourceMap = null)
    {
        return new CompilationResult(true, mipsCode, lineCount,
            Array.Empty<CompilerError>(), warnings ?? new List<CompilerError>(), sourceMap);
    }

    public static CompilationResult Failed(params CompilerError[] errors)
    {
        return new CompilationResult(false, null, 0, errors, Array.Empty<CompilerError>());
    }

    public static CompilationResult Failed(List<CompilerError> errors)
    {
        return new CompilationResult(false, null, 0, errors, Array.Empty<CompilerError>());
    }
}

public class CompilerError
{
    public int Line { get; }
    public int Column { get; }
    public string Message { get; }
    public CompilerErrorSeverity Severity { get; }

    public CompilerError(int line, int column, string message,
        CompilerErrorSeverity severity = CompilerErrorSeverity.Error)
    {
        Line = line;
        Column = column;
        Message = message;
        Severity = severity;
    }

    public override string ToString() => $"[{Severity}] Line {Line}: {Message}";
}

public enum CompilerErrorSeverity
{
    Warning,
    Error
}
```

**Step 3: Verify build**

Run: `dotnet build Basic10.Core/Basic10.Core.csproj`
Expected: Build succeeded

**Step 4: Commit**

```bash
git add Basic10.Core/Shared/
git commit -m "refactor(core): move shared utilities to core library"
```

---

### Task 1.8: Create Public API Entry Point

**Files:**
- Create: `Basic10.Core/BasicCompiler.cs`
- Create: `Basic10.Core/BasicDecompiler.cs`

**Step 1: Create BasicCompiler.cs**

Create `Basic10.Core/BasicCompiler.cs`:

```csharp
using Basic10.Core.Compiler.Lexer;
using Basic10.Core.Compiler.Parser;
using Basic10.Core.Compiler.CodeGen;
using Basic10.Core.Shared;

namespace Basic10.Core;

/// <summary>
/// Main entry point for the Basic-10 compiler.
/// </summary>
public class BasicCompiler
{
    private readonly IDeviceDatabase? _deviceDatabase;
    private readonly HashDictionary? _hashDictionary;

    public BasicCompiler(IDeviceDatabase? deviceDatabase = null, HashDictionary? hashDictionary = null)
    {
        _deviceDatabase = deviceDatabase;
        _hashDictionary = hashDictionary;
    }

    /// <summary>
    /// Compiles BASIC source code to IC10 MIPS assembly.
    /// </summary>
    public CompilationResult Compile(string basicSource, CompilerOptions? options = null)
    {
        options ??= new CompilerOptions();
        var warnings = new List<CompilerError>();

        try
        {
            // 1. Lexical analysis
            var lexer = new Lexer(basicSource);
            var tokens = lexer.Tokenize();

            // 2. Parsing
            var parser = new Parser(tokens);
            var ast = parser.Parse();

            // 3. Code generation
            var generator = new MipsGenerator(ast, options, _deviceDatabase, _hashDictionary);
            var result = generator.Generate();

            // 4. Embed BASIC source if requested
            string mipsCode = result.Code;
            if (options.EmbedBasicSource)
            {
                mipsCode = EmbedBasicSource(basicSource, mipsCode);
            }

            // 5. Check line count
            int lineCount = CountExecutableLines(mipsCode);
            if (lineCount > options.MaxLines)
            {
                warnings.Add(new CompilerError(0, 0,
                    $"Output exceeds {options.MaxLines} lines ({lineCount} lines)",
                    CompilerErrorSeverity.Warning));
            }

            return CompilationResult.Succeeded(mipsCode, lineCount, warnings, result.SourceMap);
        }
        catch (CompilerException ex)
        {
            return CompilationResult.Failed(ex.Errors);
        }
        catch (Exception ex)
        {
            return CompilationResult.Failed(new CompilerError(0, 0, $"Internal error: {ex.Message}"));
        }
    }

    private static string EmbedBasicSource(string basicSource, string mipsCode)
    {
        var encoded = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(basicSource));
        var header = $"# BASIC10_SOURCE:{encoded}\n";
        return header + mipsCode;
    }

    /// <summary>
    /// Extract embedded BASIC source from compiled MIPS code.
    /// </summary>
    public static string? ExtractBasicSource(string mipsCode)
    {
        const string marker = "# BASIC10_SOURCE:";
        var lines = mipsCode.Split('\n');
        foreach (var line in lines)
        {
            if (line.StartsWith(marker))
            {
                var encoded = line.Substring(marker.Length).Trim();
                try
                {
                    var bytes = Convert.FromBase64String(encoded);
                    return System.Text.Encoding.UTF8.GetString(bytes);
                }
                catch
                {
                    return null;
                }
            }
        }
        return null;
    }

    private static int CountExecutableLines(string mipsCode)
    {
        return mipsCode.Split('\n')
            .Count(line =>
            {
                var trimmed = line.Trim();
                return !string.IsNullOrEmpty(trimmed) &&
                       !trimmed.StartsWith("#") &&
                       !trimmed.EndsWith(":");
            });
    }
}
```

**Step 2: Create BasicDecompiler.cs**

Create `Basic10.Core/BasicDecompiler.cs`:

```csharp
using Basic10.Core.Decompiler;
using Basic10.Core.Shared;

namespace Basic10.Core;

/// <summary>
/// Main entry point for the IC10 decompiler.
/// </summary>
public class BasicDecompiler
{
    private readonly HashDictionary? _hashDictionary;

    public BasicDecompiler(HashDictionary? hashDictionary = null)
    {
        _hashDictionary = hashDictionary;
    }

    /// <summary>
    /// Decompiles IC10 MIPS assembly back to BASIC-like pseudocode.
    /// </summary>
    public string Decompile(string mipsCode)
    {
        var parser = new IC10Parser();
        var program = parser.Parse(mipsCode);
        var decompiler = new IC10Decompiler(program, _hashDictionary);
        return decompiler.Decompile();
    }
}
```

**Step 3: Verify build**

Run: `dotnet build Basic10.Core/Basic10.Core.csproj`
Expected: Build succeeded

**Step 4: Commit**

```bash
git add Basic10.Core/
git commit -m "feat(core): add public API entry points (BasicCompiler, BasicDecompiler)"
```

---

### Task 1.9: Update WPF App to Reference Core Library

**Files:**
- Modify: `BasicToMips.csproj`
- Modify: Various source files to use new namespaces
- Delete: Original `src/` files that were moved (after verification)

**Step 1: Add project reference**

Update `BasicToMips.csproj` to add:

```xml
<ItemGroup>
  <ProjectReference Include="Basic10.Core\Basic10.Core.csproj" />
</ItemGroup>
```

**Step 2: Create DeviceDatabase adapter**

The WPF app has the full `DeviceDatabase` class. Create an adapter that implements `IDeviceDatabase`:

Create `Data/DeviceDatabaseAdapter.cs`:

```csharp
using Basic10.Core.Shared;

namespace BasicToMips.Data;

/// <summary>
/// Adapts the existing DeviceDatabase to the IDeviceDatabase interface.
/// </summary>
public class DeviceDatabaseAdapter : IDeviceDatabase
{
    public int? GetDeviceHash(string deviceName)
    {
        var device = DeviceDatabase.Devices.FirstOrDefault(d =>
            d.PrefabName.Equals(deviceName, StringComparison.OrdinalIgnoreCase));
        return device?.Hash;
    }

    public int? GetPropertyHash(string propertyName)
    {
        var prop = DeviceDatabase.LogicTypes.FirstOrDefault(p =>
            p.Name.Equals(propertyName, StringComparison.OrdinalIgnoreCase));
        return prop?.Hash;
    }

    public int? GetSlotPropertyHash(string propertyName)
    {
        var prop = DeviceDatabase.SlotLogicTypes.FirstOrDefault(p =>
            p.Name.Equals(propertyName, StringComparison.OrdinalIgnoreCase));
        return prop?.Hash;
    }

    public int? GetBatchModeValue(string modeName)
    {
        var mode = DeviceDatabase.BatchModes.FirstOrDefault(m =>
            m.Name.Equals(modeName, StringComparison.OrdinalIgnoreCase));
        return mode?.Value;
    }

    public int? GetReagentModeValue(string modeName)
    {
        var mode = DeviceDatabase.ReagentModes.FirstOrDefault(m =>
            m.Name.Equals(modeName, StringComparison.OrdinalIgnoreCase));
        return mode?.Value;
    }

    public IEnumerable<string> GetDeviceNames()
    {
        return DeviceDatabase.Devices.Select(d => d.PrefabName);
    }

    public IEnumerable<string> GetPropertyNames()
    {
        return DeviceDatabase.LogicTypes.Select(p => p.Name);
    }
}
```

**Step 3: Update CompilerService to use new API**

Update `UI/Services/CompilerService.cs` to instantiate and use `BasicCompiler`:

```csharp
using Basic10.Core;
using Basic10.Core.Shared;

// In CompilerService constructor or initialization:
private readonly BasicCompiler _compiler;
private readonly BasicDecompiler _decompiler;
private readonly HashDictionary _hashDictionary;

public CompilerService()
{
    _hashDictionary = new HashDictionary();
    var deviceDb = new DeviceDatabaseAdapter();
    _hashDictionary.PopulateFromDatabase(deviceDb);

    _compiler = new BasicCompiler(deviceDb, _hashDictionary);
    _decompiler = new BasicDecompiler(_hashDictionary);
}

// Update Compile method:
public CompilationResult Compile(string source, CompilerOptions options)
{
    return _compiler.Compile(source, options);
}
```

**Step 4: Update using statements throughout WPF app**

Search and replace namespace references:
- `BasicToMips.Lexer` → `Basic10.Core.Compiler.Lexer`
- `BasicToMips.Parser` → `Basic10.Core.Compiler.Parser`
- `BasicToMips.AST` → `Basic10.Core.Compiler.AST`
- etc.

**Step 5: Delete moved source files**

After confirming everything builds:
```bash
rm -rf src/Lexer src/Parser src/AST src/CodeGen src/IC10
```

Keep `src/` folder for any remaining WPF-specific code.

**Step 6: Verify full solution builds**

Run: `dotnet build BasicToMips.sln`
Expected: All projects build successfully

**Step 7: Test WPF app functionality**

- Launch app
- Compile a BASIC program
- Decompile an IC10 program
- Verify hash dictionary still works

**Step 8: Commit**

```bash
git add .
git commit -m "refactor: update WPF app to use Basic10.Core shared library"
```

---

## Phase 2: BepInEx Plugin

### Task 2.1: Create Plugin Project

**Files:**
- Create: `Basic10.InGame/Basic10.InGame.csproj`
- Create: `Basic10.InGame/Basic10Plugin.cs`

**Step 1: Create project file**

Create `Basic10.InGame/Basic10.InGame.csproj`:

```xml
<Project Sdk="Microsoft.NET.Sdk">

  <PropertyGroup>
    <TargetFramework>netstandard2.1</TargetFramework>
    <LangVersion>latest</LangVersion>
    <Nullable>enable</Nullable>
    <RootNamespace>Basic10.InGame</RootNamespace>
    <AssemblyName>Basic10.InGame</AssemblyName>
    <Version>1.0.0</Version>
    <Authors>Dog Tired Studios</Authors>
    <Description>Basic-10 in-game compiler for Stationeers</Description>
  </PropertyGroup>

  <!-- BepInEx Dependencies -->
  <ItemGroup>
    <PackageReference Include="BepInEx.Core" Version="5.4.21" />
    <PackageReference Include="HarmonyX" Version="2.10.2" />
  </ItemGroup>

  <!-- Reference shared core compiler -->
  <ItemGroup>
    <ProjectReference Include="..\Basic10.Core\Basic10.Core.csproj" />
  </ItemGroup>

  <!-- Game Assembly References (copy from Stationeers install) -->
  <ItemGroup>
    <Reference Include="Assembly-CSharp">
      <HintPath>lib\Assembly-CSharp.dll</HintPath>
      <Private>false</Private>
    </Reference>
    <Reference Include="UnityEngine">
      <HintPath>lib\UnityEngine.dll</HintPath>
      <Private>false</Private>
    </Reference>
    <Reference Include="UnityEngine.CoreModule">
      <HintPath>lib\UnityEngine.CoreModule.dll</HintPath>
      <Private>false</Private>
    </Reference>
    <Reference Include="UnityEngine.IMGUIModule">
      <HintPath>lib\UnityEngine.IMGUIModule.dll</HintPath>
      <Private>false</Private>
    </Reference>
  </ItemGroup>

</Project>
```

**Step 2: Create lib folder**

Create `Basic10.InGame/lib/` and copy required DLLs from Stationeers.
Add to `.gitignore`:

```
Basic10.InGame/lib/
```

**Step 3: Create plugin entry point**

Create `Basic10.InGame/Basic10Plugin.cs`:

```csharp
using BepInEx;
using BepInEx.Logging;
using HarmonyLib;
using Basic10.Core;
using Basic10.Core.Shared;

namespace Basic10.InGame;

[BepInPlugin(PluginGuid, PluginName, PluginVersion)]
[BepInProcess("rocketstation.exe")]
public class Basic10Plugin : BaseUnityPlugin
{
    public const string PluginGuid = "com.dogtiredstudios.basic10";
    public const string PluginName = "Basic-10 In-Game Compiler";
    public const string PluginVersion = "1.0.0";

    internal static ManualLogSource Log = null!;
    internal static BasicCompiler Compiler = null!;
    internal static BasicDecompiler Decompiler = null!;
    internal static HashDictionary HashDict = null!;

    private Harmony? _harmony;

    private void Awake()
    {
        Log = Logger;
        Log.LogInfo($"{PluginName} v{PluginVersion} loading...");

        try
        {
            // Initialize shared components
            HashDict = new HashDictionary();
            // Note: In-game mod uses simplified device database
            Compiler = new BasicCompiler(new InGameDeviceDatabase(), HashDict);
            Decompiler = new BasicDecompiler(HashDict);

            // Apply Harmony patches
            _harmony = new Harmony(PluginGuid);
            _harmony.PatchAll();

            Log.LogInfo($"{PluginName} loaded successfully!");
        }
        catch (Exception ex)
        {
            Log.LogError($"Failed to initialize: {ex}");
        }
    }

    private void Update()
    {
        // F8 to toggle BASIC editor
        if (UnityEngine.Input.GetKeyDown(UnityEngine.KeyCode.F8))
        {
            UI.EditorToggle.Toggle();
        }
    }

    private void OnDestroy()
    {
        _harmony?.UnpatchSelf();
        HashDict?.Save();
    }
}
```

**Step 4: Add to solution and verify build**

Run: `dotnet sln BasicToMips.sln add Basic10.InGame/Basic10.InGame.csproj`
Run: `dotnet build Basic10.InGame/Basic10.InGame.csproj`
Expected: Build succeeded

**Step 5: Commit**

```bash
git add Basic10.InGame/ .gitignore BasicToMips.sln
git commit -m "feat(mod): create BepInEx plugin project referencing shared core"
```

---

### Task 2.2: Create In-Game Device Database

**Files:**
- Create: `Basic10.InGame/InGameDeviceDatabase.cs`

**Step 1: Create simplified device database**

The in-game mod can use a simplified database or read from game data at runtime:

```csharp
using Basic10.Core.Shared;

namespace Basic10.InGame;

/// <summary>
/// In-game device database implementation.
/// Can be populated from game data at runtime or use embedded common hashes.
/// </summary>
public class InGameDeviceDatabase : IDeviceDatabase
{
    private readonly Dictionary<string, int> _deviceHashes = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, int> _propertyHashes = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, int> _slotPropertyHashes = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, int> _batchModes = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, int> _reagentModes = new(StringComparer.OrdinalIgnoreCase);

    public InGameDeviceDatabase()
    {
        // TODO: Populate from game data at runtime
        // For now, include common devices/properties
        PopulateCommonHashes();
    }

    private void PopulateCommonHashes()
    {
        // Common batch modes
        _batchModes["Average"] = 0;
        _batchModes["Sum"] = 1;
        _batchModes["Minimum"] = 2;
        _batchModes["Maximum"] = 3;

        // Common properties (add more as needed)
        // These would ideally be read from the game's data
    }

    public int? GetDeviceHash(string deviceName) =>
        _deviceHashes.TryGetValue(deviceName, out var h) ? h : null;

    public int? GetPropertyHash(string propertyName) =>
        _propertyHashes.TryGetValue(propertyName, out var h) ? h : null;

    public int? GetSlotPropertyHash(string propertyName) =>
        _slotPropertyHashes.TryGetValue(propertyName, out var h) ? h : null;

    public int? GetBatchModeValue(string modeName) =>
        _batchModes.TryGetValue(modeName, out var v) ? v : null;

    public int? GetReagentModeValue(string modeName) =>
        _reagentModes.TryGetValue(modeName, out var v) ? v : null;

    public IEnumerable<string> GetDeviceNames() => _deviceHashes.Keys;
    public IEnumerable<string> GetPropertyNames() => _propertyHashes.Keys;
}
```

**Step 2: Commit**

```bash
git add Basic10.InGame/
git commit -m "feat(mod): add in-game device database implementation"
```

---

### Task 2.3: Decompile and Document Game Classes

**Files:**
- Create: `Basic10.InGame/docs/game-classes.md`

**Step 1: Open dnSpy/ILSpy with Assembly-CSharp.dll**

Load: `<Steam>/steamapps/common/Stationeers/rocketstation_Data/Managed/Assembly-CSharp.dll`

**Step 2: Search for IC10-related classes**

Search for: `IC10`, `Programmable`, `Circuit`, `CodeEditor`, `Script`

**Step 3: Document findings**

Create `Basic10.InGame/docs/game-classes.md` with:
- Class names for IC10 chip components
- Method signatures for saving/loading code
- UI window classes for the code editor
- Patch targets

**Step 4: Commit**

```bash
git add Basic10.InGame/docs/
git commit -m "docs(mod): document Stationeers game classes for patching"
```

---

### Task 2.4: Create Harmony Patches

**Files:**
- Create: `Basic10.InGame/Patches/EditorPatches.cs`

Based on decompiled findings, create patches to:
1. Intercept when IC10 editor opens
2. Intercept code save to compile BASIC
3. Intercept code load to detect embedded BASIC

See original plan for patch implementation details. Update `typeof()` placeholders with actual class names from decompilation.

---

## Phase 3: In-Game Editor UI

### Task 3.1: Create Editor Window

**Files:**
- Create: `Basic10.InGame/UI/BasicEditorWindow.cs`

Create Unity IMGUI-based editor window (see original plan for implementation).

### Task 3.2: Add Syntax Highlighting

**Files:**
- Create: `Basic10.InGame/UI/SyntaxHighlighter.cs`

Create syntax highlighter using Unity rich text (see original plan).

### Task 3.3: Add Editor Toggle

**Files:**
- Create: `Basic10.InGame/UI/EditorToggle.cs`

Create toggle manager to switch between BASIC and vanilla MIPS editors (see original plan).

---

## Phase 4: Testing and Deployment

### Task 4.1: Create Build Script

**Files:**
- Create: `build-all.ps1`

```powershell
# Build script for Basic-10 (all projects)

param(
    [switch]$Release,
    [string]$StationeersPath = "C:\Program Files (x86)\Steam\steamapps\common\Stationeers"
)

$ErrorActionPreference = "Stop"
$config = if ($Release) { "Release" } else { "Debug" }

Write-Host "Building Basic-10 Solution ($config)..." -ForegroundColor Cyan

# Build entire solution
dotnet build BasicToMips.sln -c $config

if ($LASTEXITCODE -ne 0) {
    Write-Host "Build failed!" -ForegroundColor Red
    exit 1
}

Write-Host "Build successful!" -ForegroundColor Green

# Deploy in-game mod if Stationeers found
$pluginsPath = Join-Path $StationeersPath "BepInEx\plugins\Basic10"

if (Test-Path $StationeersPath) {
    Write-Host "Deploying in-game mod to $pluginsPath..." -ForegroundColor Cyan

    if (-not (Test-Path $pluginsPath)) {
        New-Item -ItemType Directory -Path $pluginsPath | Out-Null
    }

    $modOutput = "Basic10.InGame\bin\$config\netstandard2.1"
    Copy-Item "$modOutput\Basic10.Core.dll" $pluginsPath -Force
    Copy-Item "$modOutput\Basic10.InGame.dll" $pluginsPath -Force

    Write-Host "Deployment complete!" -ForegroundColor Green
}
```

### Task 4.2: Testing Checklist

See original plan for comprehensive testing checklist.

### Task 4.3: Steam Workshop Preparation

See original plan for workshop assets.

---

## Appendix A: Final Project Structure

```
BASICtoMIPS_ByDogTired/
├── Basic10.Core/                    # Shared core library (netstandard2.1)
│   ├── Basic10.Core.csproj
│   ├── BasicCompiler.cs             # Public API - compilation
│   ├── BasicDecompiler.cs           # Public API - decompilation
│   ├── Compiler/
│   │   ├── Lexer/
│   │   │   └── Lexer.cs
│   │   ├── Parser/
│   │   │   └── Parser.cs
│   │   ├── AST/
│   │   │   └── AstNode.cs
│   │   └── CodeGen/
│   │       ├── MipsGenerator.cs
│   │       ├── RegisterAllocator.cs
│   │       └── CodeEmitter.cs
│   ├── Decompiler/
│   │   ├── IC10Parser.cs
│   │   └── IC10Decompiler.cs
│   └── Shared/
│       ├── IDeviceDatabase.cs
│       ├── HashDictionary.cs
│       ├── CompilerOptions.cs
│       ├── CompilationResult.cs
│       └── SourceMap.cs
│
├── Basic10.InGame/                  # BepInEx mod (netstandard2.1)
│   ├── Basic10.InGame.csproj
│   ├── Basic10Plugin.cs
│   ├── InGameDeviceDatabase.cs
│   ├── lib/                         # Game assemblies (gitignored)
│   ├── Patches/
│   │   └── EditorPatches.cs
│   ├── UI/
│   │   ├── BasicEditorWindow.cs
│   │   ├── SyntaxHighlighter.cs
│   │   └── EditorToggle.cs
│   └── docs/
│       └── game-classes.md
│
├── BasicToMips.csproj               # WPF Desktop app (net8.0-windows)
├── Data/
│   ├── DeviceDatabase.cs            # Full device database
│   └── DeviceDatabaseAdapter.cs     # Implements IDeviceDatabase
├── UI/                              # WPF UI code
├── Editor/                          # AvalonEdit integration
│
├── BasicToMips.sln                  # Solution file
├── build-all.ps1                    # Build script
└── docs/
    └── plans/
        └── 2025-12-11-in-game-mod.md
```

---

## Appendix B: Shared Data Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    User compiles BASIC code                     │
└───────────────────────────┬─────────────────────────────────────┘
                            │
            ┌───────────────┼───────────────┐
            ▼               │               ▼
┌───────────────────┐       │     ┌───────────────────┐
│  BasicToMips.exe  │       │     │ Basic10.InGame    │
│                   │       │     │                   │
│ BasicCompiler     │       │     │ BasicCompiler     │
│      │            │       │     │      │            │
│      ▼            │       │     │      ▼            │
│ HashDictionary    │       │     │ HashDictionary    │
│ .RegisterHash()   │       │     │ .RegisterHash()   │
└────────┬──────────┘       │     └────────┬──────────┘
         │                  │              │
         └──────────────────┼──────────────┘
                            ▼
              ┌─────────────────────────┐
              │  %LocalAppData%/        │
              │  BasicToMips/           │
              │  hash_dictionary.json   │
              └─────────────────────────┘
                            │
         ┌──────────────────┼──────────────┐
         │                  │              │
         ▼                  │              ▼
┌───────────────────┐       │     ┌───────────────────┐
│  BasicToMips.exe  │       │     │ Basic10.InGame    │
│                   │       │     │                   │
│ HashDictionary    │       │     │ HashDictionary    │
│ .LookupHash()     │       │     │ .LookupHash()     │
│      │            │       │     │      │            │
│      ▼            │       │     │      ▼            │
│ BasicDecompiler   │       │     │ BasicDecompiler   │
└───────────────────┘       │     └───────────────────┘
                            │
                            ▼
              ┌─────────────────────────┐
              │   Hashes resolve to     │
              │   original strings!     │
              └─────────────────────────┘
```

---

## Appendix C: Key Resources

| Resource | URL |
|----------|-----|
| BepInEx Documentation | https://docs.bepinex.dev |
| Harmony Wiki | https://harmony.pardeike.net/articles/intro.html |
| StationeersLaunchPad | https://github.com/StationeersLaunchPad/StationeersLaunchPad |
| IC10 Editor (Reference) | https://github.com/aproposmath/StationeersIC10Editor |
| Slang Compiler (Reference) | https://github.com/dbidwell94/stationeers_lang |
| Unity IMGUI Manual | https://docs.unity3d.com/Manual/GUIScriptingGuide.html |

---

**End of Implementation Plan**
