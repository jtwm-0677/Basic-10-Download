# Time Tracking System - Session Notes
**Date:** 2025-12-07
**Status:** In Progress - Paused for other work

## Completed Scripts

### 1. Master Clock (VERIFIED WORKING - DO NOT EDIT)
- Core chip all others depend on
- Handles day detection and tick counting
- Writes to: Day Count Memory, Tick Memory, Day Flag Memory
- Solar angle thresholds: 87° (sunrise/sunset), 120° (re-arm)

### 2. Elapsed Time (WORKING)
- Reads: Day Count Memory
- Calculates proper time breakdown (not cumulative):
  - Days: remainder after months (0-29 range displayed as value)
  - Weeks: floor(remaining days after months / 7)
  - Months: remainder after years (0-11 range)
  - Years: floor(total months / 12)
- Writes to: Elapsed Days/Weeks/Months/Years Memory chips
- Formula uses `dayCount - 1` adjustment for 1-based counting

### 3. Day Progress (WORKING)
- Reads: Tick Memory (0-2399 per day)
- Ticks 0-1199 = Daytime, 1200-2399 = Nighttime
- Outputs INVERSE values so sliders move opposite directions:
  - During day: dayPercent increases, nightPercent = 100 - dayPercent
  - During night: nightPercent increases, dayPercent = 100 - nightPercent
- Writes to: Day Progress Memory, Night Progress Memory

### 4. Display Controller (WORKING)
- Reads from all elapsed time memory chips + day/night progress
- Writes to displays:
  - Elapsed Days/Weeks/Months/Years (ModularDeviceLEDdisplay2)
  - Day Progress slider (ModularDeviceSliderDiode2) - Yellow (5)
  - Night Progress slider (ModularDeviceSliderDiode2) - Blue (0)
- Slider values divided by 100 for 0-1 range

### 5. Climate Control V2 (WORKING)
- Temperature thresholds:
  - Heaters OFF at >= 17C (290.15K)
  - Cooling valve ON at > 21C (294.15K)
  - Cooling valve OFF at <= 20.5C (293.65K) - hysteresis
  - Dangerous temp warning: < 10C or > 30C
- Converts K to C for display (temp - 273.15)
- Indicators:
  - Heating (ModularDeviceLabelDiode2): Red (4), blinking (Mode 1)
  - Cooling (ModularDeviceLabelDiode2): Blue (0), blinking (Mode 1)
  - Idle (ModularDeviceLabelDiode2): Green (2), solid (Mode 0)
  - DANGEROUS TEMPERATURE (ModularDeviceLabelDiode3): Red (4), blinking (Mode 1)
- Displays: Temperature L (display3), Temperature S (display2)

## Pending Scripts

### Europa Chip 1 (date logic)
- Not started
- Will calculate Europa calendar dates

### Europa Chip 2 (month/weekday names)
- Not started
- Text displays for month and day names

### Earth Date
- Not started
- 5.86:1 time dilation calculation

## Key Technical Notes

### Device Types (Modular - from mods)
- ModularDeviceLEDdisplay2: Smaller LED display
- ModularDeviceLEDdisplay3: Larger LED display
- ModularDeviceSliderDiode2: Slider indicator (range 0-1)
- ModularDeviceLabelDiode2: Small label with indicator
- ModularDeviceLabelDiode3: Large label with indicator

### Color Values
- 0 = Blue
- 2 = Green
- 4 = Red
- 5 = Yellow

### Important Learnings
1. Don't use `VAR` declarations - just use variables directly
2. Displays need device type hash correct (display2 vs display3)
3. Sliders use 0-1 range, divide percentage by 100
4. Exact device names required for name-based lookup
5. Comments in BASIC code caused jump target bugs (fixed in compiler)

### Memory Chips in Use
- Day Count Memory (Master Clock writes)
- Tick Memory (Master Clock writes)
- Day Flag Memory (Master Clock writes)
- Elapsed Days Memory
- Elapsed Weeks Memory
- Elapsed Months Memory
- Elapsed Years Memory
- Day Progress Memory
- Night Progress Memory
- Temperature Memory

## Bugs Found & Fixed This Session

1. **GOTO/Label Jump Bug** - Comments counted in line numbers, fixed by preserving labels
2. **IF/ELSE Branch Bug** - Same root cause, internal labels still converted to offsets incorrectly
   - Documentation: `docs/Test Documents/test plans/2025-12-07-jump-target-comment-bug.md`
   - Documentation: `docs/Test Documents/test plans/2025-12-07-if-else-branch-comment-bug.md`
