# Time Tracking System - Continuation Document
**Date:** 2025-12-07
**Status:** In Progress

## Working Scripts

### 1. Master Clock (VERIFIED WORKING)
- **File:** Master Clock.bas
- **Function:** Day detection, tick counting
- **Thresholds:**
  - Day trigger: angle <= 87
  - Re-arm: angle > 120
- **Observed ranges:** Min ~39.5 (noon), Max ~145 (midnight)
- **Outputs:**
  - Day Count Memory (cumulative days)
  - Tick Memory (0-2399, resets at sunrise)
  - Day Flag Memory (0=waiting, 1=armed)

### 2. Debug Display (VERIFIED WORKING)
- **File:** Debug Display.bas
- **Function:** Shows memory values on displays
- **Devices:**
  - Debug Day (ModularDeviceLEDdisplay3)
  - Debug Tick (ModularDeviceLEDdisplay3)
  - Debug Flag (ModularDeviceLEDdisplay3)

### 3. Time Display (NEEDS TESTING)
- **File:** Time Display.bas
- **Function:** 12-hour clock from tick count
- **Devices:**
  - Hour Display (ModularDeviceLEDdisplay3)
  - Minute Display (ModularDeviceLEDdisplay3)
  - AMPM Display (ModularDeviceLEDdisplay2)
- **Note:** Fixed integer truncation issue

## Scripts To Build

### 4. Europa Chip 1 - Date Logic
- Reads Day Count Memory from Master Clock
- Calculates day/month/year from starting date (Nov 20, 2325)
- Writes to: Europa Day, Europa Month, Europa Year memories
- Must NOT do its own day detection

### 5. Europa Chip 2 - Name Displays
- Reads Europa Month and Day Count memories
- Shows month name and weekday using Mode 10
- Mode 10 values already calculated in previous sessions

### 6. Elapsed Time
- **IMPORTANT USER REQUIREMENT:**
  - Days: Display 1-30, reset to 1 at END of day 30 (after full day completes)
  - Months: Display 1-12, reset to 1 at END of month 12 (after full month completes)
  - Years: Cumulative, never resets
- Reads Day Count Memory

### 7. Day Progress
- Reads SolarAngle directly from sensor
- Controls sliders for day/night progress
- Shows countdown to sunrise/sunset

### 8. Earth Date
- Reads Day Count Memory
- Applies 5.86:1 time dilation
- Calculates Earth date from departure date

## Device Summary (Current)

### Memory Chips (StructureLogicMemory)
- Day Count Memory
- Tick Memory
- Day Flag Memory

### Sensor
- Daylight Sensor (MUST FACE UP)

### Displays Already Named
- Debug Day, Debug Tick, Debug Flag
- Hour Display, Minute Display, AMPM Display

## Solar Angle Reference
- Sunrise/Sunset threshold: 87 degrees
- Re-arm threshold: 120 degrees
- Min angle (noon): ~39.5 degrees
- Max angle (midnight): ~145 degrees
- Day cycle: 1200 seconds = 2400 ticks

## Key Technical Notes
- YIELD = 0.5 seconds
- 2400 ticks per day
- 100 ticks per hour
- Tick resets to 0 at sunrise (synced to solar)
- Mode 10 = octet-packed ASCII for text displays
