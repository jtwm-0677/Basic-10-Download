# Basic-10 In-Game Editor - Continuation Document

**Date:** 2025-12-19
**Status:** TESTING - Editor should now appear when opening IC10 chip
**Priority:** Test in-game and fix any remaining issues

---

## RECENT CHANGES (This Session)

### 1. Added ImGuiNET Support
Added references to the game's ImGui libraries:
- `RG.ImGui.dll`
- `RG.ImGui.Unity.dll`

### 2. Added Critical Harmony Patches
Following IC10Editor's proven pattern:

```csharp
// Draw our editor in the game's ImGui loop
[HarmonyPatch(typeof(ImguiCreativeSpawnMenu), "Draw")]
[HarmonyPostfix]
private static void ImguiCreativeSpawnMenu_Draw_Postfix()
{
    foreach (var editor in AllEditors)
        editor.Draw();
}

// Intercept native editor opening
[HarmonyPatch(typeof(InputSourceCode), "ShowInputPanel")]
[HarmonyPrefix]
public static void InputSourceCode_ShowInputPanel_Prefix(...)

// Disable native editor input handling
[HarmonyPatch(typeof(InputSourceCode), "HandleInput")]
[HarmonyPrefix]
private static bool InputSourceCode_HandleInput_Prefix()
{
    return EditorWindow.UseNativeEditor;
}

[HarmonyPatch(typeof(EditorLineOfCode), "HandleUpdate")]
[HarmonyPrefix]
private static bool EditorLineOfCode_HandleUpdate_Prefix()
{
    return EditorWindow.UseNativeEditor;
}
```

### 3. Editor Window Management
Added IC10Editor-style editor management:
```csharp
public static ConditionalWeakTable<ProgrammableChipMotherboard, EditorWindow> EditorData = new();
public static List<EditorWindow> AllEditors = new();

private static EditorWindow GetEditor(ProgrammableChipMotherboard pcm)
{
    if (!EditorData.TryGetValue(pcm, out var editor))
    {
        editor = new EditorWindow(pcm);
        EditorData.Add(pcm, editor);
        AllEditors.Add(editor);
    }
    return editor;
}
```

### 4. Refactored EditorWindow to Use ImGuiNET
- Removed MonoBehaviour - now a plain class
- Uses ImGuiNET for rendering (`ImGui.Begin`, `ImGui.Button`, `ImGui.InputTextMultiline`)
- Added `Draw()` method called from Harmony postfix
- Added `ShowWindow()`, `HideWindow()`, `ResetCode()`, `SetTitle()`, `Confirm()` methods

---

## CODE LOCATION

All GameMod code is in the worktree:
```
C:\Development\Stationeers Stuff\BASICtoMIPS_ByDogTired\.worktrees\multi-platform\Basic10.GameMod\
```

**Key Files:**
- `Basic10Plugin.cs` - BepInEx plugin entry point
- `EditorPatches.cs` - All Harmony patches (CRITICAL FILE)
- `Editor/EditorWindow.cs` - Main ImGui window (REFACTORED)
- `ChipStorage.cs` - Store BASIC source by motherboard

---

## DEPLOYMENT LOCATION

```
C:\Users\jtwm0\Documents\My Games\Stationeers\mods\Basic-10\
├── About\
│   └── About.xml (+ images)
├── Basic10.Core.dll
└── Basic10.GameMod.dll
```

**Build command:**
```bash
cd "C:\Development\Stationeers Stuff\BASICtoMIPS_ByDogTired\.worktrees\multi-platform"
dotnet build Basic10.GameMod/Basic10.GameMod.csproj -c Release
```

**Deploy command:**
```powershell
Copy-Item -Path "Basic10.GameMod\bin\Release\net472\Basic10.*.dll" -Destination "C:\Users\jtwm0\Documents\My Games\Stationeers\mods\Basic-10\" -Force
```

---

## TESTING CHECKLIST

1. [ ] Launch Stationeers with Basic-10 mod enabled
2. [ ] Check BepInEx log for loading messages:
   - "Basic-10 Compiler v1.0.0 loading..."
   - "PatchAll completed"
   - "Total patched methods in game: X"
3. [ ] Place a Programmable IC10 chip
4. [ ] Click on the chip to open editor
5. [ ] Verify Basic-10 editor appears (not vanilla IC10 editor)
6. [ ] Test basic text editing
7. [ ] Test Compile button
8. [ ] Test Confirm button (save and close)
9. [ ] Test Cancel button

---

## WHAT TO CHECK IF EDITOR DOESN'T APPEAR

### Check BepInEx Log
```
C:\Program Files (x86)\Steam\steamapps\common\Stationeers\BepInEx\LogOutput.log
```

Look for:
- "ShowInputPanel intercepted!" - confirms patch is working
- "Basic-10 Editor window shown" - confirms editor opened
- Any exceptions or errors

### If No "ShowInputPanel intercepted!" Message:
- The Harmony patch isn't being called
- Check if InputSourceCode.ShowInputPanel method signature matches

### If Editor Opens But Doesn't Show:
- Check for exceptions in Draw()
- Verify ImGuiNET is available

---

## POTENTIAL ISSUES

1. **InputSourceCode.HandleInput might not exist** - We added a patch but it might fail silently if the method doesn't exist. Check BepInEx log for patch count.

2. **ImGui rendering context** - If the game's ImGui state isn't set up correctly when our Draw is called, rendering might fail.

3. **PauseGameToggle was removed** - Game won't pause when editor opens. Can add back later.

---

## NEXT STEPS

If editor works:
1. Add syntax highlighting
2. Add line numbers
3. Add undo/redo
4. Add error display panel
5. Add pause game toggle

If editor doesn't work:
1. Check BepInEx log for exact error
2. Compare patch signatures with IC10Editor decompiled code
3. Add more logging to identify where it fails

---

## REFERENCE: IC10Editor Decompiled

Location: `C:\Development\Stationeers Stuff\IC10 editor decompiled\IC10Editor\`

This is the reference implementation that works. Key differences from our implementation:
- IC10Editor has more features (vim mode, library search, etc.)
- IC10Editor has custom text rendering
- We use ImGui.InputTextMultiline for simplicity
