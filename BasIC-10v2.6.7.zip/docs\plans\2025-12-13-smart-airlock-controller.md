# Smart Airlock Controller Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.
>
> **REQUIRED REFERENCE:** Before each task, read `docs/IC10Reference.md` for IC10/MIPS syntax, units (kPa not Pa!), vent modes, and common pitfalls.

**Goal:** Build an incremental Smart Airlock Controller for Stationeers, testing each component before adding the next.

**Architecture:** Single-script approach initially. Add Button Watcher as separate IC only if complexity requires it. State machine pattern: IDLE(0) -> PRESSURIZING(1) / DEPRESSURIZING(2) -> DOOR_OPEN(3) -> IDLE(0).

**Tech Stack:** Basic-10 compiler, IC10 MIPS assembly, Stationeers game

---

## Hardware Setup (User Responsibility)

**NASA Aesthetic Goal:** Information overload - abundant displays, technical look, every reading visible.

**Devices on network with exact names:**

### Buttons
| Device Type | Name | Purpose |
|-------------|------|---------|
| ModularDeviceUtilityButton2x2 | "To Interior" | Request interior cycling |
| ModularDeviceUtilityButton2x2 | "To Exterior" | Request exterior cycling |
| ModularDeviceUtilityButton2x2 | "Call Interior" | Call from interior side |
| ModularDeviceUtilityButton2x2 | "Call Exterior" | Call from exterior side |

### Doors & Vents
| Device Type | Name | Purpose |
|-------------|------|---------|
| StructureCompositeDoor | "Interior" | Door to base interior |
| StructureCompositeDoor | "Exterior" | Door to exterior/vacuum |
| StructureActiveVent | "Interior" | Connects to base atmosphere pipe |
| StructureActiveVent | "Exterior" | Connects to exterior/vacuum pipe |

### Sensors
| Device Type | Name | Purpose |
|-------------|------|---------|
| StructureGasSensor | "Interior Sensor" | Measures base interior atmosphere |
| StructureGasSensor | "Airlock Sensor" | Measures airlock atmosphere |
| StructureGasSensor | "Exterior Sensor" | Measures exterior atmosphere |

### Pressure Displays
| Device Type | Name | Purpose |
|-------------|------|---------|
| ModularDeviceLEDdisplay2 | "Airlock Pressure" | Airlock pressure in kPa |

### Temperature Displays (Kelvin + Celsius pairs)
| Device Type | Name | Purpose |
|-------------|------|---------|
| ModularDeviceLEDdisplay2 | "Interior Temp K" | Interior temperature (Kelvin) |
| ModularDeviceLEDdisplay2 | "Interior Temp C" | Interior temperature (Celsius) |
| ModularDeviceLEDdisplay2 | "Airlock Temp K" | Airlock temperature (Kelvin) |
| ModularDeviceLEDdisplay2 | "Airlock Temp C" | Airlock temperature (Celsius) |
| ModularDeviceLEDdisplay2 | "Exterior Temp K" | Exterior temperature (Kelvin) |
| ModularDeviceLEDdisplay2 | "Exterior Temp C" | Exterior temperature (Celsius) |

### Status Displays & Indicators
| Device Type | Name | Purpose |
|-------------|------|---------|
| ModularDeviceLEDdisplay2 | "AutoClose Countdown" | Seconds until auto-close |
| ModularDeviceLabelDiode2 | "AUTOMATIC CLOSE" | Indicator light |

### Memory (if needed for multi-IC)
| Device Type | Name | Purpose |
|-------------|------|---------|
| StructureLogicMemory | "Button Memory" | Inter-IC communication |
| StructureLogicMemory | "State Memory" | Persistent state storage |

**Pressure targets:**
- Interior: 101 kPa (base atmosphere)
- Exterior: 2 kPa (near vacuum)

**Vent modes (from IC10Reference.md):**
- Mode 0 (Inward): Pull gas FROM room INTO pipe
- Mode 1 (Outward): Push gas FROM pipe INTO room

---

## Phase 1: Tick Counter and Housing Display

### Task 1.1: Create minimal looping script

**Files:**
- Create: Stationeers scripts folder `Smart Airlock/Smart Airlock.bas`

**Step 1: Write minimal script in Basic-10**

```basic
# Smart Airlock Controller - Phase 1
# Verify IC housing runs and displays tick counter

VAR tick = 0

Main:
    tick = tick + 1
    db.Setting = tick
    YIELD
    GOTO Main
END
```

**Step 2: Compile and verify**

- Press F5 to compile
- Expected: 8 IC10 lines, no errors
- Compiled output should show `s db Setting r0`

**Step 3: Load into game and verify**

- Save script via File > Save to Scripts Folder as "Smart Airlock"
- Load IC10 output into IC Housing
- Turn on housing
- Expected: Housing display increments every tick (~2/second)

**Step 4: Verify loop continues**

- Watch for 10+ seconds
- Expected: Number continues incrementing without stopping
- If stops: Hardware/power issue, not script

---

## Phase 2: Read and Display Pressure

### Task 2.1: Add pressure sensor reading

**Files:**
- Modify: `Smart Airlock/Smart Airlock.bas`

**Step 1: Add sensor alias and pressure display**

```basic
# Smart Airlock Controller - Phase 2
# Read pressure sensor, display on LED

ALIAS sensor = IC.Device[StructureGasSensor].Name["Airlock Sensor"]
ALIAS dispPressure = IC.Device[ModularDeviceLEDdisplay2].Name["Airlock Pressure"]

VAR tick = 0
VAR pressure = 0

Main:
    tick = tick + 1
    db.Setting = tick

    pressure = sensor.Pressure
    dispPressure.Setting = pressure

    YIELD
    GOTO Main
END
```

**Step 2: Compile and verify**

- Press F5 to compile
- Expected: ~15 IC10 lines, no errors
- Should see `lbn` instruction for sensor read
- Should see `sbn` instruction for display write

**Step 3: Load and test in game**

- Save and load into IC Housing
- Expected:
  - Housing display: incrementing tick
  - "Airlock Pressure" display: ~101 (if pressurized) or ~0-2 (if depressurized)
- Verify pressure reading changes if you pump air in/out

---

## Phase 3: Temperature Displays (All 6)

### Task 3.1: Add all temperature sensor readings and displays

**Files:**
- Modify: `Smart Airlock/Smart Airlock.bas`

**Step 1: Add sensor and display aliases**

```basic
# Smart Airlock Controller - Phase 3
# Read all temperatures, display in Kelvin and Celsius

# === SENSORS ===
ALIAS sensorInt = IC.Device[StructureGasSensor].Name["Interior Sensor"]
ALIAS sensorAirlock = IC.Device[StructureGasSensor].Name["Airlock Sensor"]
ALIAS sensorExt = IC.Device[StructureGasSensor].Name["Exterior Sensor"]

# === PRESSURE DISPLAY ===
ALIAS dispPressure = IC.Device[ModularDeviceLEDdisplay2].Name["Airlock Pressure"]

# === TEMPERATURE DISPLAYS ===
ALIAS dispIntTempK = IC.Device[ModularDeviceLEDdisplay2].Name["Interior Temp K"]
ALIAS dispIntTempC = IC.Device[ModularDeviceLEDdisplay2].Name["Interior Temp C"]
ALIAS dispAirlockTempK = IC.Device[ModularDeviceLEDdisplay2].Name["Airlock Temp K"]
ALIAS dispAirlockTempC = IC.Device[ModularDeviceLEDdisplay2].Name["Airlock Temp C"]
ALIAS dispExtTempK = IC.Device[ModularDeviceLEDdisplay2].Name["Exterior Temp K"]
ALIAS dispExtTempC = IC.Device[ModularDeviceLEDdisplay2].Name["Exterior Temp C"]

# === CONSTANTS ===
CONST KELVIN_OFFSET = 273.15

# === VARIABLES ===
VAR tick = 0
VAR pressure = 0
VAR tempIntK = 0
VAR tempAirlockK = 0
VAR tempExtK = 0

Main:
    tick = tick + 1
    db.Setting = tick

    # Read pressure
    pressure = sensorAirlock.Pressure
    dispPressure.Setting = pressure

    # Read temperatures (all in Kelvin from sensors)
    tempIntK = sensorInt.Temperature
    tempAirlockK = sensorAirlock.Temperature
    tempExtK = sensorExt.Temperature

    # Display Kelvin values
    dispIntTempK.Setting = tempIntK
    dispAirlockTempK.Setting = tempAirlockK
    dispExtTempK.Setting = tempExtK

    # Display Celsius values (Kelvin - 273.15)
    dispIntTempC.Setting = tempIntK - KELVIN_OFFSET
    dispAirlockTempC.Setting = tempAirlockK - KELVIN_OFFSET
    dispExtTempC.Setting = tempExtK - KELVIN_OFFSET

    YIELD
    GOTO Main
END
```

**Step 2: Compile and verify**

- Press F5 to compile
- Expected: ~35 IC10 lines, no errors
- Should see multiple `lbn` and `sbn` instructions

**Step 3: Load and test in game**

- Expected results:
  - Housing display: incrementing tick
  - "Airlock Pressure": ~101 or ~0-2 kPa
  - "Interior Temp K": ~293 (if ~20°C)
  - "Interior Temp C": ~20
  - "Airlock Temp K": varies with state
  - "Airlock Temp C": varies with state
  - "Exterior Temp K": varies (vacuum is cold)
  - "Exterior Temp C": negative number likely

**Step 4: Verify all 7 displays update**

- All displays should show values (not static 0)
- Kelvin values should be ~273 higher than Celsius
- If any display stays at 0, check device name spelling

---

## Phase 4: Set Indicator Colors

### Task 4.1: Add indicator with static color

**Files:**
- Modify: `Smart Airlock/Smart Airlock.bas`

**Step 1: Add indicator alias and set color**

```basic
# Smart Airlock Controller - Phase 3
# Add indicator light with color

ALIAS sensor = IC.Device[StructureGasSensor].Name["Airlock Sensor"]
ALIAS dispPressure = IC.Device[ModularDeviceLEDdisplay2].Name["Airlock Pressure"]
ALIAS dispCountdown = IC.Device[ModularDeviceLEDdisplay2].Name["AutoClose Countdown"]
ALIAS indAutoClose = IC.Device[ModularDeviceLabelDiode2].Name["AUTOMATIC CLOSE"]

VAR tick = 0
VAR pressure = 0

Main:
    tick = tick + 1
    db.Setting = tick

    pressure = sensor.Pressure
    dispPressure.Setting = pressure
    dispCountdown.Setting = 0

    # Color 0=Off, 1=Blue, 2=Gray, 3=Green, 4=Orange, 5=Red, 6=Yellow, 7=White
    indAutoClose.Color = 3
    indAutoClose.On = 1

    YIELD
    GOTO Main
END
```

**Step 2: Compile and verify**

- Press F5 to compile
- Expected: ~20 IC10 lines, no errors

**Step 3: Load and test in game**

- Expected:
  - Housing display: incrementing tick
  - "Airlock Pressure" display: current pressure in kPa
  - "AutoClose Countdown" display: 0
  - "AUTOMATIC CLOSE" indicator: GREEN and ON

**Step 4: Test color changes**

- Change `indAutoClose.Color = 5` (red) and reload
- Verify indicator turns red
- Change back to 3 (green) for now

---

## Phase 5: Read Door States

### Task 5.1: Add door state reading

**Files:**
- Modify: `Smart Airlock/Smart Airlock.bas`

**Step 1: Add door aliases and read states**

```basic
# Smart Airlock Controller - Phase 5
# Read door open/closed states

ALIAS sensor = IC.Device[StructureGasSensor].Name["Airlock Sensor"]
ALIAS dispPressure = IC.Device[ModularDeviceLEDdisplay2].Name["Airlock Pressure"]
ALIAS dispCountdown = IC.Device[ModularDeviceLEDdisplay2].Name["AutoClose Countdown"]
ALIAS indAutoClose = IC.Device[ModularDeviceLabelDiode2].Name["AUTOMATIC CLOSE"]
ALIAS doorInt = IC.Device[StructureCompositeDoor].Name["Interior"]
ALIAS doorExt = IC.Device[StructureCompositeDoor].Name["Exterior"]

VAR tick = 0
VAR pressure = 0
VAR doorIntOpen = 0
VAR doorExtOpen = 0

Main:
    tick = tick + 1
    db.Setting = tick

    pressure = sensor.Pressure
    doorIntOpen = doorInt.Open
    doorExtOpen = doorExt.Open

    dispPressure.Setting = pressure

    # Show door states: 0=both closed, 1=int open, 2=ext open, 3=both open
    dispCountdown.Setting = doorIntOpen + (doorExtOpen * 2)

    # Green if both closed, Orange if either open
    IF doorIntOpen = 1 OR doorExtOpen = 1 THEN
        indAutoClose.Color = 4
    ELSE
        indAutoClose.Color = 3
    ENDIF
    indAutoClose.On = 1

    YIELD
    GOTO Main
END
```

**Step 2: Compile and verify**

- Press F5 to compile
- Expected: ~35 IC10 lines, no errors

**Step 3: Load and test in game**

- Expected with both doors closed:
  - Housing: incrementing tick
  - Pressure display: current kPa
  - Countdown display: 0
  - Indicator: GREEN

- Manually open interior door:
  - Countdown display: 1
  - Indicator: ORANGE

- Manually open exterior door (close interior first):
  - Countdown display: 2
  - Indicator: ORANGE

---

## Phase 6: Read Button Presses

### Task 6.1: Add button reading

**Files:**
- Modify: `Smart Airlock/Smart Airlock.bas`

**Step 1: Add button aliases and detection**

```basic
# Smart Airlock Controller - Phase 5
# Detect button presses (Activate property)

ALIAS sensor = IC.Device[StructureGasSensor].Name["Airlock Sensor"]
ALIAS dispPressure = IC.Device[ModularDeviceLEDdisplay2].Name["Airlock Pressure"]
ALIAS dispCountdown = IC.Device[ModularDeviceLEDdisplay2].Name["AutoClose Countdown"]
ALIAS indAutoClose = IC.Device[ModularDeviceLabelDiode2].Name["AUTOMATIC CLOSE"]
ALIAS doorInt = IC.Device[StructureCompositeDoor].Name["Interior"]
ALIAS doorExt = IC.Device[StructureCompositeDoor].Name["Exterior"]
ALIAS btnToInt = IC.Device[ModularDeviceUtilityButton2x2].Name["To Interior"]
ALIAS btnToExt = IC.Device[ModularDeviceUtilityButton2x2].Name["To Exterior"]

VAR tick = 0
VAR pressure = 0
VAR doorIntOpen = 0
VAR doorExtOpen = 0
VAR lastButton = 0

Main:
    tick = tick + 1
    db.Setting = tick

    pressure = sensor.Pressure
    doorIntOpen = doorInt.Open
    doorExtOpen = doorExt.Open

    # Check buttons - Activate is 1 for ONE tick when pressed
    IF btnToInt.Activate = 1 THEN
        lastButton = 1
    ELSEIF btnToExt.Activate = 1 THEN
        lastButton = 2
    ENDIF

    dispPressure.Setting = pressure
    dispCountdown.Setting = lastButton

    IF doorIntOpen = 1 OR doorExtOpen = 1 THEN
        indAutoClose.Color = 4
    ELSE
        indAutoClose.Color = 3
    ENDIF
    indAutoClose.On = 1

    YIELD
    GOTO Main
END
```

**Step 2: Compile and verify**

- Press F5 to compile
- Expected: ~45 IC10 lines, no errors

**Step 3: Load and test in game**

- Expected at start:
  - Countdown display: 0 (no button pressed yet)

- Press "To Interior" button:
  - Countdown display: 1 (and stays at 1)

- Press "To Exterior" button:
  - Countdown display: 2 (and stays at 2)

This confirms button detection works.

---

## Phase 7: State Machine Foundation

### Task 7.1: Implement basic state machine

**Files:**
- Modify: `Smart Airlock/Smart Airlock.bas`

**Step 1: Add state machine with visual feedback**

```basic
# Smart Airlock Controller - Phase 6
# State machine: 0=IDLE, 1=PRESSURIZING, 2=DEPRESSURIZING, 3=DOOR_OPEN

ALIAS sensor = IC.Device[StructureGasSensor].Name["Airlock Sensor"]
ALIAS dispPressure = IC.Device[ModularDeviceLEDdisplay2].Name["Airlock Pressure"]
ALIAS dispCountdown = IC.Device[ModularDeviceLEDdisplay2].Name["AutoClose Countdown"]
ALIAS indAutoClose = IC.Device[ModularDeviceLabelDiode2].Name["AUTOMATIC CLOSE"]
ALIAS doorInt = IC.Device[StructureCompositeDoor].Name["Interior"]
ALIAS doorExt = IC.Device[StructureCompositeDoor].Name["Exterior"]
ALIAS btnToInt = IC.Device[ModularDeviceUtilityButton2x2].Name["To Interior"]
ALIAS btnToExt = IC.Device[ModularDeviceUtilityButton2x2].Name["To Exterior"]

CONST STATE_IDLE = 0
CONST STATE_PRESSURIZE = 1
CONST STATE_DEPRESSURIZE = 2
CONST STATE_DOOR_OPEN = 3

VAR tick = 0
VAR pressure = 0
VAR doorIntOpen = 0
VAR doorExtOpen = 0
VAR state = 0

Main:
    tick = tick + 1
    db.Setting = tick

    # Read inputs
    pressure = sensor.Pressure
    doorIntOpen = doorInt.Open
    doorExtOpen = doorExt.Open

    # State machine
    IF state = STATE_IDLE THEN
        GOSUB StateIdle
    ELSEIF state = STATE_PRESSURIZE THEN
        GOSUB StatePressurize
    ELSEIF state = STATE_DEPRESSURIZE THEN
        GOSUB StateDepressurize
    ELSEIF state = STATE_DOOR_OPEN THEN
        GOSUB StateDoorOpen
    ENDIF

    # Display current state and pressure
    dispPressure.Setting = pressure
    dispCountdown.Setting = state

    YIELD
    GOTO Main

# === STATE 0: IDLE ===
StateIdle:
    indAutoClose.Color = 3
    indAutoClose.On = 1

    IF btnToInt.Activate = 1 THEN
        state = STATE_PRESSURIZE
    ELSEIF btnToExt.Activate = 1 THEN
        state = STATE_DEPRESSURIZE
    ENDIF
    RETURN

# === STATE 1: PRESSURIZE (placeholder) ===
StatePressurize:
    indAutoClose.Color = 1
    indAutoClose.On = 1

    # For now, just go to DOOR_OPEN after detecting state
    state = STATE_DOOR_OPEN
    RETURN

# === STATE 2: DEPRESSURIZE (placeholder) ===
StateDepressurize:
    indAutoClose.Color = 5
    indAutoClose.On = 1

    # For now, just go to DOOR_OPEN after detecting state
    state = STATE_DOOR_OPEN
    RETURN

# === STATE 3: DOOR OPEN (placeholder) ===
StateDoorOpen:
    indAutoClose.Color = 4
    indAutoClose.On = 1

    # For now, just go back to IDLE
    state = STATE_IDLE
    RETURN

END
```

**Step 2: Compile and verify**

- Press F5 to compile
- Expected: ~70 IC10 lines, no errors

**Step 3: Load and test in game**

- Expected at start:
  - Countdown display: 0 (IDLE state)
  - Indicator: GREEN

- Press "To Interior":
  - Indicator flashes BLUE (pressurize) -> ORANGE (door open) -> GREEN (idle)
  - Countdown: cycles 0 -> 1 -> 3 -> 0

- Press "To Exterior":
  - Indicator flashes RED (depressurize) -> ORANGE (door open) -> GREEN (idle)
  - Countdown: cycles 0 -> 2 -> 3 -> 0

This confirms state transitions work. States cycle too fast (no actual work), but structure is correct.

---

## Phase 8: Pressurization Logic

### Task 8.1: Implement actual pressurization

**Files:**
- Modify: `Smart Airlock/Smart Airlock.bas`

**Step 1: Add vent control for pressurization**

Replace the StatePressurize subroutine:

```basic
# === STATE 1: PRESSURIZE ===
# Fill airlock to ~101 kPa, then open interior door
StatePressurize:
    indAutoClose.Color = 1
    indAutoClose.On = 1

    # Close exterior door, turn off exterior vent
    doorExt.Open = 0
    ventExt.On = 0

    # Check if pressure is within tolerance (98-104 kPa)
    IF pressure >= 98 AND pressure <= 104 THEN
        ventInt.On = 0
        doorInt.Open = 1
        state = STATE_DOOR_OPEN
        RETURN
    ENDIF

    # Need more pressure: Mode 1 pushes air FROM pipe INTO room
    IF pressure < 101 THEN
        ventInt.Mode = 1
    ELSE
        ventInt.Mode = 0
    ENDIF
    ventInt.On = 1
    RETURN
```

**Step 2: Add vent aliases at top of script**

Add after door aliases:
```basic
ALIAS ventInt = IC.Device[StructureActiveVent].Name["Interior"]
ALIAS ventExt = IC.Device[StructureActiveVent].Name["Exterior"]
```

**Step 3: Compile and test**

- Press F5 to compile
- Expected: ~80 IC10 lines, no errors
- In game: Press "To Interior" when depressurized
- Expected: Pressure rises, then interior door opens

---

## Phase 9: Depressurization Logic

### Task 9.1: Implement actual depressurization

**Files:**
- Modify: `Smart Airlock/Smart Airlock.bas`

**Step 1: Replace StateDepressurize subroutine**

```basic
# === STATE 2: DEPRESSURIZE ===
# Empty airlock to ~2 kPa, then open exterior door
StateDepressurize:
    indAutoClose.Color = 5
    indAutoClose.On = 1

    # Close interior door, turn off interior vent
    doorInt.Open = 0
    ventInt.On = 0

    # Safety: only open exterior if pressure < 5 kPa
    IF pressure < 5 THEN
        IF pressure <= 3 THEN
            ventExt.On = 0
            doorExt.Open = 1
            state = STATE_DOOR_OPEN
            RETURN
        ENDIF
    ENDIF

    # Need less pressure: Mode 0 pulls air FROM room INTO pipe
    IF pressure > 2 THEN
        ventExt.Mode = 0
    ELSE
        ventExt.Mode = 1
    ENDIF
    ventExt.On = 1
    RETURN
```

**Step 2: Compile and test**

- Press F5 to compile
- In game: Press "To Exterior" when pressurized
- Expected: Pressure drops, then exterior door opens (only when safe)

---

## Phase 10: Door Open Timer

### Task 10.1: Add auto-close countdown

**Files:**
- Modify: `Smart Airlock/Smart Airlock.bas`

**Step 1: Add timer variable and constant**

Add with other constants:
```basic
CONST AUTO_CLOSE_TICKS = 100
```

Add with other variables:
```basic
VAR closeTimer = 0
```

**Step 2: Replace StateDoorOpen subroutine**

```basic
# === STATE 3: DOOR OPEN - COUNTDOWN ===
StateDoorOpen:
    indAutoClose.Color = 4
    indAutoClose.On = 1
    indAutoClose.Mode = 1

    closeTimer = closeTimer + 1
    dispCountdown.Setting = AUTO_CLOSE_TICKS - closeTimer

    IF closeTimer > AUTO_CLOSE_TICKS THEN
        doorInt.Open = 0
        doorExt.Open = 0
        closeTimer = 0
        indAutoClose.Mode = 0
        state = STATE_IDLE
    ENDIF
    RETURN
```

**Step 3: Reset timer when entering DOOR_OPEN state**

In StatePressurize, before `state = STATE_DOOR_OPEN`:
```basic
closeTimer = 0
```

In StateDepressurize, before `state = STATE_DOOR_OPEN`:
```basic
closeTimer = 0
```

**Step 4: Compile and test**

- Press F5 to compile
- In game: Complete a cycle
- Expected: Countdown display shows decreasing number, door closes at 0

---

## Phase 11: Manual Door Detection

### Task 11.1: Detect manual door opens in IDLE state

**Files:**
- Modify: `Smart Airlock/Smart Airlock.bas`

**Step 1: Update StateIdle to detect manual door opens**

```basic
# === STATE 0: IDLE ===
StateIdle:
    indAutoClose.Color = 3
    indAutoClose.On = 1
    indAutoClose.Mode = 0
    dispCountdown.Setting = 0

    # Turn off vents when idle
    ventInt.On = 0
    ventExt.On = 0

    # Check for button presses
    IF btnToInt.Activate = 1 THEN
        state = STATE_PRESSURIZE
        RETURN
    ELSEIF btnToExt.Activate = 1 THEN
        state = STATE_DEPRESSURIZE
        RETURN
    ENDIF

    # Check for manual door open - start countdown
    IF doorIntOpen = 1 OR doorExtOpen = 1 THEN
        closeTimer = 0
        state = STATE_DOOR_OPEN
    ENDIF
    RETURN
```

**Step 2: Compile and test**

- Press F5 to compile
- In game: Manually open a door (not via button)
- Expected: Countdown starts, door auto-closes after timer

---

## Final Complete Script Reference

After all 11 phases, the complete script will include:

1. **Sensors:** Interior, Airlock, Exterior (3 gas sensors)
2. **Displays:**
   - Airlock Pressure (1)
   - Temperature K + C for all 3 locations (6)
   - AutoClose Countdown (1)
   - Total: 8 displays
3. **Indicator:** AUTOMATIC CLOSE with color states
4. **State machine:** IDLE(0) -> PRESSURIZE(1) / DEPRESSURIZE(2) -> DOOR_OPEN(3)
5. **Vent modes:** Mode 1 = push into room, Mode 0 = pull from room
6. **Safety:** Exterior door only opens if pressure < 5 kPa
7. **Auto-close:** Timer with countdown display
8. **Manual detection:** Detects hand-opened doors, starts countdown

**NASA Aesthetic achieved:** 8 displays showing real-time data, color-coded indicator, technical information overload.

---

## Debugging Reference

If script stops running, check:
1. `db.Setting` should increment (proves main loop runs)
2. All device names match exactly (case-sensitive)
3. Pressure units are kPa (101 not 101000)
4. See `docs/IC10Reference.md` sections:
   - "Common Pitfalls and Debugging"
   - "Units Reference"
   - "Vent Modes"
