# Stack Handling in Basic-10

This document provides a comprehensive overview of stack handling in the Basic-10 compiler, including current implementation, IC10 stack capabilities, and opportunities for improvement.

---

## Table of Contents

1. [IC10 Stack Architecture](#ic10-stack-architecture)
2. [Current Implementation](#current-implementation)
3. [BASIC Stack Commands](#basic-stack-commands)
4. [Internal Stack Usage](#internal-stack-usage)
5. [Simulator Support](#simulator-support)
6. [Gap Analysis](#gap-analysis)
7. [Improvement Opportunities](#improvement-opportunities)

---

## IC10 Stack Architecture

### Hardware Stack in Stationeers

The IC10 processor in Stationeers has:

| Feature | Value | Notes |
|---------|-------|-------|
| Stack Size | 512 slots | Shared between push/pop and direct access |
| Stack Pointer | `sp` register | Points to next free slot |
| Return Address | `ra` register | Used by `jal`/`j ra` for subroutines |
| Addressing | 0-511 | Direct access via `peek`/`poke` with address |

### IC10 Stack Instructions (Complete List)

| Instruction | Syntax | Description |
|-------------|--------|-------------|
| `push` | `push value` | Push value onto stack, increment sp |
| `pop` | `pop register` | Pop top of stack into register, decrement sp |
| `peek` | `peek register` | Read top of stack without removing (sp-1) |
| `poke` | `poke address value` | Write value to specific stack address |
| `get` | `get register device address` | Read from device memory at address |
| `put` | `put device address value` | Write to device memory at address |
| `getd` | `getd register deviceHash address` | Read from hashed device memory |
| `putd` | `putd deviceHash address value` | Write to hashed device memory |

### Special Registers

| Register | Purpose | Notes |
|----------|---------|-------|
| `sp` | Stack pointer | Auto-managed by push/pop, can be read/written |
| `ra` | Return address | Set by `jal`, used by `j ra` to return |

---

## Current Implementation

### Compiler Architecture

```
src/
├── Lexer/
│   ├── Lexer.cs          # Tokenizes PUSH, POP, PEEK keywords
│   └── TokenType.cs      # Push, Pop, Peek token types
├── Parser/
│   └── Parser.cs         # ParsePushStatement, ParsePopStatement, ParsePeekStatement
├── AST/
│   └── AstNode.cs        # PushStatement, PopStatement, PeekStatement nodes
├── CodeGen/
│   ├── MipsGenerator.cs  # GeneratePush, GeneratePop, GeneratePeek
│   └── RegisterAllocator.cs  # Spills to stack when registers exhausted
└── Simulator/
    └── IC10Simulator.cs  # Push, Pop, Peek simulation
```

### Code Locations

| Feature | File | Line(s) |
|---------|------|---------|
| Token definitions | `Lexer.cs` | 72-74 |
| Token types | `TokenType.cs` | 61-63 |
| Parser | `Parser.cs` | 96-98, 1376-1400 |
| AST nodes | `AstNode.cs` | 138-151 |
| Code generation | `MipsGenerator.cs` | 339-346, 1110-1130 |
| Register spilling | `RegisterAllocator.cs` | 158-168 |
| Simulator | `IC10Simulator.cs` | 598-631 |

---

## BASIC Stack Commands

### Implemented Commands

#### PUSH
```basic
PUSH expression
```
Pushes the value of any expression onto the IC10 stack.

**Generated IC10:**
```
# PUSH onto stack
push r0
```

**Implementation:** `MipsGenerator.cs:1110-1116`
```csharp
private void GeneratePush(PushStatement push)
{
    var valueReg = GenerateExpression(push.Value);
    EmitComment("PUSH onto stack");
    Emit($"push {valueReg}");
    FreeRegister(valueReg);
}
```

#### POP
```basic
POP variableName
```
Pops the top value from the stack into a variable.

**Generated IC10:**
```
# POP into myVar
pop r0
```

**Implementation:** `MipsGenerator.cs:1118-1123`
```csharp
private void GeneratePop(PopStatement pop)
{
    var varReg = GetOrCreateVariable(pop.VariableName);
    EmitComment($"POP into {pop.VariableName}");
    Emit($"pop {varReg}");
}
```

#### PEEK
```basic
PEEK variableName
```
Reads the top value from the stack without removing it.

**Generated IC10:**
```
# PEEK into myVar
peek r0
```

**Implementation:** `MipsGenerator.cs:1125-1130`
```csharp
private void GeneratePeek(PeekStatement peek)
{
    var varReg = GetOrCreateVariable(peek.VariableName);
    EmitComment($"PEEK into {peek.VariableName}");
    Emit($"peek {varReg}");
}
```

### NOT Implemented as Direct Commands

| Command | Status | Notes |
|---------|--------|-------|
| `POKE` | Used internally | For arrays, not exposed as BASIC command |
| Direct `sp` access | Not exposed | No BASIC syntax to read/write stack pointer |
| Indexed peek | Not available | Can't peek at arbitrary stack position |

---

## Internal Stack Usage

### 1. Register Spilling

When all 16 registers are in use, the compiler spills variables to the IC housing (`db`) memory.

**RegisterAllocator.cs:158-168:**
```csharp
private void SpillRegister(int regNum, List<string> emitBuffer)
{
    var variableName = _registerContents[regNum];
    if (variableName == null) return;

    int stackSlot = _nextStackSlot++;
    emitBuffer.Add($"put db {stackSlot} r{regNum}");  // Spill
    _spilledVariables[variableName] = stackSlot;
    _variableRegisters.Remove(variableName);
    _registerContents[regNum] = null;
}
```

**Reload when needed:**
```csharp
emitBuffer.Add($"get r{reg} db {stackSlot}");  // Reload
```

**Note:** This uses device memory (`db`), not the IC10 stack, to avoid conflicts with user stack operations.

### 2. Function Calls (CALL/SUB)

Arguments are passed via the stack:

**MipsGenerator.cs:1755-1766:**
```csharp
private void GenerateCall(CallStatement call)
{
    // Push arguments in reverse order (last arg first)
    for (int i = call.Arguments.Count - 1; i >= 0; i--)
    {
        var argReg = GenerateExpression(call.Arguments[i]);
        Emit($"push {argReg}");
        FreeRegister(argReg);
    }
    Emit($"jal {call.SubName}");
}
```

**Subroutine receives parameters:**
```csharp
// In GenerateSub - pop parameters in order
Emit($"pop {paramReg}");
```

### 3. Arrays (DIM)

Arrays use `poke` for direct memory access:

**MipsGenerator.cs:1574-1578:**
```csharp
var baseReg = GetOrCreateVariable(dim.VariableName);
Emit($"move {baseReg} {_stackPointer}");
_stackPointer += size;
EmitComment($"DIM {dim.VariableName} - allocated {size} slots");
```

**Array element write uses poke:**
```csharp
Emit($"poke {valueReg} r{TempRegister}");  // Write to calculated address
```

### 4. GOSUB/RETURN

Uses IC10's `jal`/`j ra` mechanism:

```basic
GOSUB mySub    ' Compiles to: jal mySub
...
mySub:
    ' code
    RETURN     ' Compiles to: j ra
```

---

## Simulator Support

### Implemented in IC10Simulator.cs

**Stack Properties:**
```csharp
public const int StackSize = 512;
public double[] Stack { get; } = new double[StackSize];
public int StackPointer { get; private set; } = 0;
```

**Push (line 598-606):**
```csharp
private void Push(string[] parts)
{
    if (StackPointer >= StackSize)
        throw new InvalidOperationException("Stack overflow");
    Stack[StackPointer++] = GetValue(parts[1]);
    ProgramCounter++;
}
```

**Pop (line 608-617):**
```csharp
private void Pop(string[] parts)
{
    if (StackPointer <= 0)
        throw new InvalidOperationException("Stack underflow");
    var dest = GetRegisterIndex(parts[1]);
    Registers[dest] = Stack[--StackPointer];
    ProgramCounter++;
}
```

**Peek (line 619-631):**
```csharp
private void Peek(string[] parts)
{
    var dest = GetRegisterIndex(parts[1]);
    if (StackPointer <= 0)
        Registers[dest] = 0;
    else
        Registers[dest] = Stack[StackPointer - 1];
    ProgramCounter++;
}
```

### NOT Implemented in Simulator

| Instruction | Status | Impact |
|-------------|--------|--------|
| `poke` | Missing | Arrays won't simulate correctly |
| `get`/`put` | Partial | Device memory only, not stack |
| `getd`/`putd` | Missing | Hashed device memory access |
| `sp` register | Not exposed | Can't read/modify stack pointer |

---

## Gap Analysis

### Comparing IC10 Capabilities vs Basic-10 Support

| IC10 Feature | BASIC Syntax | Compiler | Simulator | Notes |
|--------------|--------------|----------|-----------|-------|
| `push value` | `PUSH expr` | ✅ | ✅ | Fully implemented |
| `pop reg` | `POP var` | ✅ | ✅ | Fully implemented |
| `peek reg` | `PEEK var` | ✅ | ✅ | Fully implemented |
| `poke addr val` | None | ⚠️ Internal | ❌ | Used for arrays, not exposed |
| `sp` read | None | ❌ | ❌ | No way to read stack pointer |
| `sp` write | None | ❌ | ❌ | No way to set stack pointer |
| `peek reg addr` | None | ❌ | ❌ | Indexed peek not supported |
| `get reg dev addr` | `device.Memory[n]` | ✅ | ⚠️ Partial | Device memory works |
| `put dev addr val` | `device.Memory[n] = x` | ✅ | ⚠️ Partial | Device memory works |
| `getd`/`putd` | Named device memory | ✅ | ❌ | Compiler works, simulator missing |

### Missing BASIC Features

1. **No POKE statement** - `poke` is used internally for arrays but not available as:
   ```basic
   POKE address, value   ' Would write to stack address directly
   ```

2. **No stack pointer access** - Can't do:
   ```basic
   sp = 100              ' Set stack pointer
   depth = sp            ' Read stack pointer
   ```

3. **No indexed PEEK** - Can't do:
   ```basic
   value = PEEK(5)       ' Peek at stack position 5
   ```

4. **No CLEAR/RESET stack** - Can't do:
   ```basic
   CLEAR STACK           ' Reset stack pointer to 0
   ```

---

## Improvement Opportunities

### Priority 1: Essential Additions

#### 1.1 POKE Statement
Expose the existing internal `poke` functionality:

```basic
POKE address, value
```

**Implementation needed:**
- Add `Poke` token type
- Add `PokeStatement` AST node
- Add parser rule
- Add code generator (trivial - already uses `poke` internally)

#### 1.2 Stack Pointer Access
Allow reading/writing `sp`:

```basic
VAR depth = SP        ' Read current stack depth
SP = 0                ' Clear/reset stack
```

**Implementation needed:**
- Treat `SP` as special variable that maps to `sp` register
- Generate `move rX sp` for reads
- Generate `move sp rX` for writes

### Priority 2: Enhanced Functionality

#### 2.1 Indexed PEEK Function
Peek at any stack position:

```basic
value = PEEK(index)   ' Read stack[index] without changing sp
```

**Implementation:**
- Requires computing offset and using `peek` with calculated address
- IC10 doesn't have native indexed peek - would need workaround

#### 2.2 Stack Size Function
Get remaining stack capacity:

```basic
remaining = STACKFREE()   ' Returns 512 - sp
```

**Implementation:**
```
move rResult 512
sub rResult rResult sp
```

#### 2.3 CLEAR Statement
Reset stack:

```basic
CLEAR STACK
```

**Implementation:**
```
move sp 0
```

### Priority 3: Advanced Features

#### 3.1 Stack Frame Management
For proper function scoping:

```basic
SUB myFunc(a, b)
    LOCAL x, y           ' Allocate on stack
    ' ...
    RETURN result        ' Clean up stack frame
END SUB
```

**Would require:**
- Frame pointer tracking
- Local variable allocation on stack
- Automatic cleanup on return

#### 3.2 Stack-Based Arrays
Use IC10 stack instead of device memory for arrays:

```basic
DIM STACK myArray(10)   ' Allocate on IC stack, not db
```

**Benefits:**
- Faster access (no device I/O)
- Doesn't consume device memory slots

**Drawbacks:**
- Shares space with push/pop operations
- Requires careful stack management

#### 3.3 Coroutine/Continuation Support
Save/restore execution state:

```basic
SAVESTATE handle       ' Push all registers + pc
LOADSTATE handle       ' Restore state
```

### Priority 4: Simulator Improvements

#### 4.1 Add Missing Instructions
```csharp
case "poke": Poke(parts); break;
case "getd": GetD(parts); break;
case "putd": PutD(parts); break;
```

#### 4.2 Expose sp Register
```csharp
// Add sp as register index 16
if (name == "sp") return 16;
Registers[16] = StackPointer;  // Keep synced
```

#### 4.3 Stack Visualization
Add UI to show:
- Current stack contents
- Stack pointer position
- High water mark

---

## Implementation Roadmap

### Phase 1: Quick Wins (Low effort, high value)
1. ✅ `PUSH`, `POP`, `PEEK` - Already done
2. Add `POKE address, value` statement
3. Add `SP` pseudo-variable for reading stack pointer

### Phase 2: Core Improvements
1. Add `STACKFREE()` function
2. Add `CLEAR STACK` statement
3. Implement `POKE` in simulator
4. Add stack visualization to simulator UI

### Phase 3: Advanced Features
1. Indexed `PEEK(address)` function
2. Stack-based local variables
3. Stack frame management for proper SUB scoping

### Phase 4: Optimization
1. Stack usage analysis in static analyzer
2. Warnings for potential stack overflow
3. Stack depth tracking at compile time

---

## Code Examples

### Current Usage
```basic
' Using stack for temporary storage
PUSH x
PUSH y
' ... do something with x and y registers ...
POP y
POP x

' Passing arguments to subroutine
CALL addNumbers(5, 10)

SUB addNumbers(a, b)
    RETURN a + b
END SUB
```

### Proposed Future Usage
```basic
' Direct stack manipulation
POKE 0, 42           ' Write 42 to stack[0]
value = PEEK(0)      ' Read from stack[0]

' Stack pointer access
depth = SP           ' Get current depth
SP = 0               ' Clear stack

' Stack-aware programming
IF STACKFREE() < 10 THEN
    PRINT "Warning: Low stack space"
ENDIF
```

---

## References

- IC10 MIPS Reference: Stationeers Wiki
- RegisterAllocator.cs: Spilling implementation
- MipsGenerator.cs: Code generation for stack ops
- IC10Simulator.cs: Runtime simulation

---

*Document created: December 2025*
*Basic-10 Version: 2.6.0*
