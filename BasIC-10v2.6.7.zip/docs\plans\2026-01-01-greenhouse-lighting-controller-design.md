# Greenhouse Lighting Controller Design

**Date:** 2026-01-01
**Status:** Ready for Implementation
**Related:** Greenhouse Atmosphere Controller System

---

## Overview

A dedicated lighting controller IC that manages grow lights and window shutters for optimal plant light management, independent of natural daylight.

**Core Behavior:**
- Grow lights cycle on/off based on configurable hours (0-24)
- Shutters close during daylight to block sun, open at night
- Full blackout mode for Mushroom preset (auto-detect) or manual override

---

## Logic Summary

| System | Normal Mode | Blackout Mode |
|--------|-------------|---------------|
| **Grow Lights** | Cycle based on "Light Hours" dial | OFF permanently |
| **Shutters** | Closed during daylight, open at night | CLOSED 24/7 |

**Blackout Triggers:**
- Automatic: Preset #15 (Mushroom) active
- Manual: "Blackout Mode" switch enabled

---

## Hardware Requirements

### Sensors & Controllers

| Device Type | Name | Purpose |
|-------------|------|---------|
| StructureDaylightSensor | "Greenhouse Daylight" | Detects when sun is up |
| StructureCompositeWindowShutterController | "Greenhouse Shutters" | Controls all window shutters |

### Grow Lights (batch controlled)

| Device Type | Name | Quantity |
|-------------|------|----------|
| StructureGrowLight | "Greenhouse Light" | Multiple (all same name) |

### Memory (Pin Wiring Required)

| Pin | Device | Purpose |
|-----|--------|---------|
| d0 | "System State" | Read active preset (address 1) |

---

## Controls

| Device Type | Name | Purpose |
|-------------|------|---------|
| ModularDeviceDial | "Light Hours" | Set hours of light per cycle (0-24) |
| ModularDeviceFlipCoverSwitch | "Blackout Mode" | Manual full blackout enable |
| ModularDeviceFlipCoverSwitch | "Shutter Override" | Enable manual shutter control |
| ModularDeviceFlipCoverSwitch | "Shutters Open" | When override on: open (1) or closed (0) |
| ModularDeviceFlipCoverSwitch | "Lights Override" | Enable manual grow light control |
| ModularDeviceFlipCoverSwitch | "Lights On" | When override on: on (1) or off (0) |

**Total: 1 dial + 5 flip cover switches**

---

## Indicators

### Status LEDs (ModularDeviceLabelDiode2)

| Name | Color | Code | Purpose |
|------|-------|------|---------|
| "LIGHTS ON" | Green | 2 | Grow lights currently active |
| "LIGHTS OFF" | Blue | 0 | Grow lights in dark period |
| "SHUTTERS OPEN" | White | 6 | Shutters currently open |
| "SHUTTERS CLOSED" | Yellow | 5 | Shutters currently closed |
| "BLACKOUT MODE" | Red | 4 | Full blackout active |
| "DAYLIGHT" | Orange | 3 | Sun is currently up |

### Displays (ModularDeviceLEDdisplay2)

| Name | Purpose |
|------|---------|
| "LIGHT HOURS" | Shows configured hours (0-24) |
| "CYCLE TIME" | Current position in cycle (hours) |

**Display Color Coding:**

CYCLE TIME colors:
| Cycle State | Color | Code |
|-------------|-------|------|
| Light period (first 75%) | Green | 2 |
| Light period (last 25%) | Yellow | 5 |
| Dark period | Blue | 0 |
| Blackout mode | Red | 4 |

LIGHT HOURS colors:
| Hours Set | Color | Code |
|-----------|-------|------|
| 0 | Red | 4 |
| 1-8 | Blue | 0 |
| 9-16 | Green | 2 |
| 17-24 | Yellow | 5 |

---

## Timing Constants

- 1 tick = 0.5 seconds
- 1 hour = 7200 ticks
- 24 hours = 172800 ticks (cycle reset point)

---

## Logic Flow

```
1. Read inputs:
   - Light Hours dial setting
   - Active preset from memory (d0, address 1)
   - Daylight sensor (is sun up?)
   - All override switches

2. Check blackout mode:
   - IF preset == 15 (Mushroom) OR "Blackout Mode" switch ON:
     - Set blackoutActive = true

3. Determine grow light state:
   - IF "Lights Override" ON:
     - Use "Lights On" switch state
   - ELSEIF blackoutActive:
     - Lights OFF
   - ELSE:
     - Calculate if within light hours of cycle
     - Lights ON if cyclePosition < (lightHours * 7200)

4. Determine shutter state:
   - IF "Shutter Override" ON:
     - Use "Shutters Open" switch state
   - ELSEIF blackoutActive:
     - Shutters CLOSED
   - ELSE:
     - Shutters CLOSED if daylight, OPEN if night

5. Apply outputs & update displays

6. Increment cycle counter (wrap at 172800)
```

---

## Color Reference

| Value | Color |
|-------|-------|
| 0 | Blue |
| 1 | Gray |
| 2 | Green |
| 3 | Orange |
| 4 | Red |
| 5 | Yellow |
| 6 | White |
| 7 | Black |
| 8 | Brown |
| 9 | Khaki |
| 10 | Pink |
| 11 | Purple |

---

## Setup Checklist

1. Place IC Housing, name "Lighting IC"
2. Wire "System State" memory to d0 pin
3. Place and name daylight sensor
4. Place and name shutter controller
5. Place and name all grow lights (same name)
6. Place control panel with dial and switches
7. Place indicator LEDs and displays
8. Load Greenhouse Lighting Controller script
9. Set "Light Hours" dial to desired value (e.g., 16)
10. Test cycle and overrides

---

*Design completed: 2026-01-01*
